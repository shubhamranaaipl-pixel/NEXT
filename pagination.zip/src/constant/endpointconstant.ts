export const UrlEndPoint={
    PAGE_NO:"page=",
    SEARCHBAR:"search=",
    SEARCH_PAGE:"&page=",
}

