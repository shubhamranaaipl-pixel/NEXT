export const ButtonConstant={
    PAGE_NO1:1,
    PAGE_NO2:2,
    PAGE_NO3:3,
    PAGE_NO4:4
}