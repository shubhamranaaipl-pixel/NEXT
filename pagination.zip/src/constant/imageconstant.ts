export const ImageConstant={
    CONTENT_IMAGE:"/images/rel.jpg",
    LOGO_IMAGE:"/images/logo.png",
    LEFT_ARROW:"/images/left.png",
    RIGHT_ARROW:"/images/right.png",

}