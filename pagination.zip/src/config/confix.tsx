interface IConfig{
    url:string;
}

export const config:IConfig={
    url:process.env.NEXT_PUBLIC_FETCH_URL||"",
}