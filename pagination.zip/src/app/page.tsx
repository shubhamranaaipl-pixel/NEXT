"use client";
import Content from "@/component/Content/content";
export default function Home() {
  return <Content />;
}
