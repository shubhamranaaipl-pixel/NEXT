import Header from "@/component/Header/header";
import Footer from "@/component/Footer/footer";
import "@/style/global.scss";
import { PersonProvider } from "@/context/context";
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <PersonProvider>
        <Header/>
        {children}
        <Footer/>
        </PersonProvider>
        </body>
    </html>
  );
}
