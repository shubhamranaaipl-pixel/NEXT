 export interface IResultData {
    name: string;
    birth_year: string;
    image?: string;
    height: number;
  }

export interface IGetDEtails{
  count:number,
  next?:string,
  previous?:string,
  results:IResultData[]
}