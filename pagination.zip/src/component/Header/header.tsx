"use client";

import Image from "next/image";
import { ImageConstant } from "@/constant/imageconstant";
import style from "@/component/Header/header.module.scss";
import { useState } from "react";
import { config } from "@/config/confix";
import { UrlEndPoint } from "@/constant/endpointconstant";
import { usePersonContext } from "@/context/context";
export default function Header() {
  const [searchBarData, setSetSerchBarData] = useState("");
  const { setApiDetails  } =
    usePersonContext();

  const searchPersonData = async () => {
    const res = await fetch(
      `${config.url}${UrlEndPoint.SEARCHBAR}${searchBarData}`
    );
    const data = await res.json();
    setApiDetails(data);
    setSetSerchBarData("");
  };

  return (
    <>
  
      <header className={style.header_container}>
        <Image
          className={style.header_container_image}
          src={ImageConstant.LOGO_IMAGE}
          alt="LogoImage"
          width={60}
          height={60}
        />

        <div className={style.header_container_searchbar}>
          <input
            type="text"
            name="searchbar"
            value={searchBarData}
            placeholder=" Search Item..."
            className={style.header_container_searchbar_input}
            onChange={(e) => setSetSerchBarData(e.target.value)}
          />
          <button
            onClick={() => searchPersonData()}
            className={style.header_container_searchbar_button}
          >
            Search
          </button>
        </div>
      </header>
    </>
  );
}
