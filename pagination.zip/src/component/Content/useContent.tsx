"use client";
import { config } from "@/config/confix";

import { UrlEndPoint } from "@/constant/endpointconstant";
import { usePersonContext } from "@/context/context";

export const useContent = () => {
  const {
    getApiDetails,
    setApiDetails,
    setCurrentPage,
    personDatalimiit,
    setpersonDatalimiit,
    visiblePages,
      currentPage,
    startPage,
  } = usePersonContext();


  const changeUiData = async (page: number) => {
    const res = await fetch(`${config.url}${UrlEndPoint.PAGE_NO}${page}`);
    const data = await res.json();
    setApiDetails(data);
  };


  const chageButons = async (item: number) => {
    setCurrentPage(item);
    const res = await fetch(`${config.url}${UrlEndPoint.PAGE_NO}${item}`);
    const data = await res.json();
    setApiDetails(data);
  };

  const movePages = async (url: string | undefined) => {
    const res = await fetch(url || "");
    const data = await res.json();
    setApiDetails(data);
  };
  return {
    getApiDetails,
    changeUiData,
    movePages,
    personDatalimiit,
    setpersonDatalimiit,
    setApiDetails,
    chageButons,
    visiblePages,
    currentPage,
    startPage,
  };
};
