"use client";

import Image from "next/image";
import { ImageConstant } from "@/constant/imageconstant";
import style from "@/component/Content/content.module.scss";
import { useContent } from "./useContent";
import { IResultData } from "@/modules/content/model/IResultData";

export default function Content() {
  const { getApiDetails,  chageButons, visiblePages,currentPage,startPage} = useContent();

  return (
    <div className={style.main_container}>
      <>
        {getApiDetails?.results.map((resultDataItem: IResultData, index) => (
          <div key={index} className={style.main_container_cards}>
            <Image
              className={style.main_container_cards_image}
              src={ImageConstant.CONTENT_IMAGE}
              alt={resultDataItem.name}
              height={200}
              width={200}
            />
            <h2 className={style.main_container_cards_heading}>
              {resultDataItem.name}
            </h2>
            <p className={style.main_container_cards_paragrpah}>
              {resultDataItem.birth_year}
            </p>
          </div>
        ))}

        <div className={style.main_container_footer}>
        
        {currentPage>1 && (  <button  
            className={style.main_container_footer_button}
            onClick={() => chageButons(startPage)}
          >
            <Image
              src={ImageConstant.LEFT_ARROW}
              alt="left arrow"
              width={20}
              height={20}
            />
          </button>)}
         
          {visiblePages.map((item, index) => (
            <button
              className={style.main_container_footer_button}
              onClick={() => chageButons(item)}
              key={index}
            >
              {item}
            </button>
          ))}
        {currentPage <8 &&(<button
            className={style.main_container_footer_button}
            onClick={() => chageButons(currentPage+1)}
          >
            <Image
              src={ImageConstant.RIGHT_ARROW}
              alt="left arrow"
              width={20}
              height={20}
            />
          </button>)}
          
        </div>
      </>
    </div>
  );
}
