"use client";
import Image from "next/image";
import { ImageConstant } from "@/constant/imageconstant";
import style from "@/component/Footer/footer.module.scss";

export default function Footer() {
  return (
    <footer className={style.footer_container}>
      <Image
        className={style.footer_container_image}
        src={ImageConstant.LOGO_IMAGE}
        alt="LogoImage"
        height={60}
        width={60}
      />
      <h2 className={style.footer_container_headinglg}> 
        Worldwide physical and digital distribution. From music lovers to music
        lovers.
      </h2>
      <h5 className={style.footer_container_headingsm}>
        Department Sixty Five, 65 Greenwich South Street, London, SE10 8NT +44
        20 8320 0988 info@primedirectdist.co.uk
      </h5>
      <p className={style.footer_container_paragraph}>
        Terms And Conditions Privacy Policy ©2025 Prime Direct Distribution Ltd.
        Website By Another Kind
      </p>
    </footer>
  );
}
