"use client";

import {
  createContext,
  useEffect,
  useState,
  useContext,
  Dispatch,
  SetStateAction,
} from "react";
import { UrlEndPoint } from "@/constant/endpointconstant";
import { config } from "@/config/confix";
import { IGetDEtails } from "@/modules/content/model/IResultData";

interface PersonContextType {
  getApiDetails: IGetDEtails | undefined;
  setApiDetails: Dispatch<SetStateAction<IGetDEtails | undefined>>;
  setCurrentPage: Dispatch<SetStateAction<number>>;
  personDatalimiit: number;
  setpersonDatalimiit: Dispatch<SetStateAction<number>>;
  visiblePages: number[];
  currentPage:number;
  startPage:number;


}

const PersonContext = createContext<PersonContextType | null>(null);

export const PersonProvider = ({ children }: { children: React.ReactNode }) => {
  const [getApiDetails, setApiDetails] = useState<IGetDEtails | undefined>();

  const [personDatalimiit, setpersonDatalimiit] = useState<number>(10);
  const totalPages = Math.ceil((getApiDetails?.count ?? 0) / personDatalimiit);
  const [currentPage, setCurrentPage] = useState(1);
  const maxVisibele = 5;

  const startPage = currentPage == 1 ? 1 : currentPage - 1;
  const endPage = Math.min(startPage + maxVisibele - 1, totalPages);
  const visiblePages = [];

  for (let i = startPage; i <= endPage; i++) {
    visiblePages.push(i);
  }

  useEffect(() => {
    const fetchPersonData = async () => {
      const res = await fetch(`${config.url}${UrlEndPoint.PAGE_NO}${1}`);
      const data = await res.json();

      setApiDetails(data);
    };

    fetchPersonData();
  }, []);

  return (
    <PersonContext.Provider
      value={{
        getApiDetails,
        setApiDetails,
        setCurrentPage,
        personDatalimiit,
        setpersonDatalimiit,
        visiblePages,
        currentPage,
        startPage
      }}
    >
      {children}
    </PersonContext.Provider>
  );
};

export const usePersonContext = () => {
  const context = useContext(PersonContext);
  if (!context) {
    throw new Error("The Data are Not Found");
  }

  return context;
};

export default PersonContext;
