(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_component_Content_content_module_scss_module_8cb20681.css",
  "static/chunks/src_692684f9._.js"
],
    source: "dynamic"
});
