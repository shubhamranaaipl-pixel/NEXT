(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/component/Content/content.module.scss [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "main_container": "content-module-scss-module__QW9ZtG__main_container",
  "main_container_cards_image": "content-module-scss-module__QW9ZtG__main_container_cards_image",
  "main_container_footer": "content-module-scss-module__QW9ZtG__main_container_footer",
  "main_container_footer_button": "content-module-scss-module__QW9ZtG__main_container_footer_button",
});
}),
"[project]/src/config/confix.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const config = {
    url: ("TURBOPACK compile-time value", "https://swapi.dev/api/people/?page=") || ""
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/constant/endpointconstant.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UrlEndPoint",
    ()=>UrlEndPoint
]);
const UrlEndPoint = {
    PAGE_NO1: 1
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/component/Content/useContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContent",
    ()=>useContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/confix.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/endpointconstant.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const useContent = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "74ef3a59e43b038dfd5616d532c766cac8a06a772a12fe5f9efaf799592dce94") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "74ef3a59e43b038dfd5616d532c766cac8a06a772a12fe5f9efaf799592dce94";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [resulltData, setresultData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ()=>{
            const fetchApiData = async ()=>{
                const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"].url}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UrlEndPoint"].PAGE_NO1}`);
                const data = await res.json();
                setresultData(data.results);
            };
            fetchApiData();
        };
        t2 = [];
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = async (page)=>{
            const res_0 = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"].url}${page}`);
            const data_0 = await res_0.json();
            setresultData(data_0.results);
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const changeUiData = t3;
    let t4;
    if ($[5] !== resulltData) {
        t4 = {
            resulltData,
            changeUiData
        };
        $[5] = resulltData;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    return t4;
};
_s(useContent, "CWBsjHNa2dl8CsAH9TiG1gH6eFs=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/component/Content/content.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Content
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/imageconstant.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/component/Content/content.module.scss [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/component/Content/useContent.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function Content() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "c1b60e3ca08eb52111f07abc43d9e95d6ce72291e2fc35aa80682260ba7f2f57") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c1b60e3ca08eb52111f07abc43d9e95d6ce72291e2fc35aa80682260ba7f2f57";
    }
    const { resulltData, changeUiData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContent"])();
    let t0;
    if ($[1] !== resulltData) {
        t0 = resulltData.map(_ContentResulltDataMap);
        $[1] = resulltData;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] !== changeUiData) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(1)
            }["Content[<button>.onClick]"],
            children: "1"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 31,
            columnNumber: 10
        }, this);
        $[3] = changeUiData;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== changeUiData) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(2)
            }["Content[<button>.onClick]"],
            children: "2"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 41,
            columnNumber: 10
        }, this);
        $[5] = changeUiData;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    let t3;
    if ($[7] !== changeUiData) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(3)
            }["Content[<button>.onClick]"],
            children: "3"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 51,
            columnNumber: 10
        }, this);
        $[7] = changeUiData;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== changeUiData) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(4)
            }["Content[<button>.onClick]"],
            children: "4"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 61,
            columnNumber: 10
        }, this);
        $[9] = changeUiData;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t1 || $[12] !== t2 || $[13] !== t3 || $[14] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer,
            children: [
                t1,
                t2,
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[11] = t1;
        $[12] = t2;
        $[13] = t3;
        $[14] = t4;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    let t6;
    if ($[16] !== t0 || $[17] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t0,
                    t5
                ]
            }, void 0, true)
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[16] = t0;
        $[17] = t5;
        $[18] = t6;
    } else {
        t6 = $[18];
    }
    return t6;
}
_s(Content, "xYYNSl2qlcbpuOuYWRtSfvKHnqA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContent"]
    ];
});
_c = Content;
function _ContentResulltDataMap(resultDataItem, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_image,
                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].CONTENT_IMAGE,
                alt: resultDataItem.name,
                height: 200,
                width: 200
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 92,
                columnNumber: 66
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_heading,
                children: resultDataItem.name
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 92,
                columnNumber: 205
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_paragrpah,
                children: resultDataItem.birth_year
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 92,
                columnNumber: 282
            }, this)
        ]
    }, index, true, {
        fileName: "[project]/src/component/Content/content.tsx",
        lineNumber: 92,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "Content");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/component/Content/content.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function Home() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "24ff0f5a9e6f3d303bb7201118eb197c7971c3a2fadb075c0d25a861c5407863") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "24ff0f5a9e6f3d303bb7201118eb197c7971c3a2fadb075c0d25a861c5407863";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 15,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_692684f9._.js.map