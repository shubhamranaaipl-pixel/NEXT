(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/component/Content/content.module.scss [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "main_container": "content-module-scss-module__QW9ZtG__main_container",
  "main_container_cards_image": "content-module-scss-module__QW9ZtG__main_container_cards_image",
  "main_container_footer": "content-module-scss-module__QW9ZtG__main_container_footer",
  "main_container_footer_button": "content-module-scss-module__QW9ZtG__main_container_footer_button",
});
}),
"[project]/src/component/Content/useContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContent",
    ()=>useContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/confix.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/endpointconstant.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/context.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const useContent = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "ec7a6f3cecab84ca78fe4458364870b5c7d442c246d8162c3f4458c29b75db21") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ec7a6f3cecab84ca78fe4458364870b5c7d442c246d8162c3f4458c29b75db21";
    }
    const { getApiDetails, setApiDetails, setCurrentPage, personDatalimiit, setpersonDatalimiit, visiblePages, currentPage, startPage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePersonContext"])();
    let t0;
    if ($[1] !== setApiDetails) {
        t0 = async (page)=>{
            const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"].url}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UrlEndPoint"].PAGE_NO}${page}`);
            const data = await res.json();
            setApiDetails(data);
        };
        $[1] = setApiDetails;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const changeUiData = t0;
    let t1;
    if ($[3] !== setApiDetails || $[4] !== setCurrentPage) {
        t1 = async (item)=>{
            setCurrentPage(item);
            const res_0 = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"].url}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UrlEndPoint"].PAGE_NO}${item}`);
            const data_0 = await res_0.json();
            setApiDetails(data_0);
        };
        $[3] = setApiDetails;
        $[4] = setCurrentPage;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const chageButons = t1;
    let t2;
    if ($[6] !== setApiDetails) {
        t2 = async (url)=>{
            const res_1 = await fetch(url || "");
            const data_1 = await res_1.json();
            setApiDetails(data_1);
        };
        $[6] = setApiDetails;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    const movePages = t2;
    let t3;
    if ($[8] !== chageButons || $[9] !== changeUiData || $[10] !== currentPage || $[11] !== getApiDetails || $[12] !== movePages || $[13] !== personDatalimiit || $[14] !== setApiDetails || $[15] !== setpersonDatalimiit || $[16] !== startPage || $[17] !== visiblePages) {
        t3 = {
            getApiDetails,
            changeUiData,
            movePages,
            personDatalimiit,
            setpersonDatalimiit,
            setApiDetails,
            chageButons,
            visiblePages,
            currentPage,
            startPage
        };
        $[8] = chageButons;
        $[9] = changeUiData;
        $[10] = currentPage;
        $[11] = getApiDetails;
        $[12] = movePages;
        $[13] = personDatalimiit;
        $[14] = setApiDetails;
        $[15] = setpersonDatalimiit;
        $[16] = startPage;
        $[17] = visiblePages;
        $[18] = t3;
    } else {
        t3 = $[18];
    }
    return t3;
};
_s(useContent, "LMgbzskoo1nEyAKzY9MCVMH7DcE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePersonContext"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/component/Content/content.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Content
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/imageconstant.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/component/Content/content.module.scss [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/component/Content/useContent.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function Content() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "a812111d4d70ab5cdd82b0b78db73a918fbee3db09befd9d93f89095e8243734") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a812111d4d70ab5cdd82b0b78db73a918fbee3db09befd9d93f89095e8243734";
    }
    const { getApiDetails, chageButons, visiblePages, currentPage, startPage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContent"])();
    let t0;
    if ($[1] !== getApiDetails?.results) {
        t0 = getApiDetails?.results.map(_ContentAnonymous);
        $[1] = getApiDetails?.results;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] !== chageButons || $[4] !== currentPage || $[5] !== startPage) {
        t1 = currentPage > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>chageButons(startPage)
            }["Content[<button>.onClick]"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].LEFT_ARROW,
                alt: "left arrow",
                width: 20,
                height: 20
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 36,
                columnNumber: 37
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 34,
            columnNumber: 29
        }, this);
        $[3] = chageButons;
        $[4] = currentPage;
        $[5] = startPage;
        $[6] = t1;
    } else {
        t1 = $[6];
    }
    let t2;
    if ($[7] !== chageButons || $[8] !== visiblePages) {
        let t3;
        if ($[10] !== chageButons) {
            t3 = ({
                "Content[visiblePages.map()]": (item, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
                        onClick: {
                            "Content[visiblePages.map() > <button>.onClick]": ()=>chageButons(item)
                        }["Content[visiblePages.map() > <button>.onClick]"],
                        children: item
                    }, index_0, false, {
                        fileName: "[project]/src/component/Content/content.tsx",
                        lineNumber: 49,
                        columnNumber: 59
                    }, this)
            })["Content[visiblePages.map()]"];
            $[10] = chageButons;
            $[11] = t3;
        } else {
            t3 = $[11];
        }
        t2 = visiblePages.map(t3);
        $[7] = chageButons;
        $[8] = visiblePages;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    let t3;
    if ($[12] !== chageButons || $[13] !== currentPage) {
        t3 = currentPage < 8 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>chageButons(currentPage + 1)
            }["Content[<button>.onClick]"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].RIGHT_ARROW,
                alt: "left arrow",
                width: 20,
                height: 20
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 69,
                columnNumber: 37
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 67,
            columnNumber: 29
        }, this);
        $[12] = chageButons;
        $[13] = currentPage;
        $[14] = t3;
    } else {
        t3 = $[14];
    }
    let t4;
    if ($[15] !== t1 || $[16] !== t2 || $[17] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer,
            children: [
                t1,
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[15] = t1;
        $[16] = t2;
        $[17] = t3;
        $[18] = t4;
    } else {
        t4 = $[18];
    }
    let t5;
    if ($[19] !== t0 || $[20] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t0,
                    t4
                ]
            }, void 0, true)
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[19] = t0;
        $[20] = t4;
        $[21] = t5;
    } else {
        t5 = $[21];
    }
    return t5;
}
_s(Content, "+hPf1RZRroQeZMKPPxEjIhY6CPM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContent"]
    ];
});
_c = Content;
function _ContentAnonymous(resultDataItem, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_image,
                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].CONTENT_IMAGE,
                alt: resultDataItem.name,
                height: 200,
                width: 200
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 98,
                columnNumber: 66
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_heading,
                children: resultDataItem.name
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 98,
                columnNumber: 205
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_paragrpah,
                children: resultDataItem.birth_year
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 98,
                columnNumber: 282
            }, this)
        ]
    }, index, true, {
        fileName: "[project]/src/component/Content/content.tsx",
        lineNumber: 98,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "Content");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/component/Content/content.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function Home() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "24ff0f5a9e6f3d303bb7201118eb197c7971c3a2fadb075c0d25a861c5407863") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "24ff0f5a9e6f3d303bb7201118eb197c7971c3a2fadb075c0d25a861c5407863";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 15,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_55d7cfc8._.js.map