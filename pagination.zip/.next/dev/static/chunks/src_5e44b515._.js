(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/component/Content/content.module.scss [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "main_container": "content-module-scss-module__QW9ZtG__main_container",
  "main_container_cards_image": "content-module-scss-module__QW9ZtG__main_container_cards_image",
  "main_container_footer": "content-module-scss-module__QW9ZtG__main_container_footer",
  "main_container_footer_button": "content-module-scss-module__QW9ZtG__main_container_footer_button",
});
}),
"[project]/src/component/Content/useContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContent",
    ()=>useContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/confix.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/endpointconstant.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/context.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const useContent = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "4e87f49f30f5f6c0b2f2267e075a699525c36544a4d43fe22a5a023f3af80ec3") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4e87f49f30f5f6c0b2f2267e075a699525c36544a4d43fe22a5a023f3af80ec3";
    }
    const { getApiDetails, setApiDetails } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePersonContext"])();
    const [personDatalimiit, setpersonDatalimiit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(10);
    let t0;
    if ($[1] !== setApiDetails) {
        t0 = async (page)=>{
            const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$confix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"].url}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$endpointconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UrlEndPoint"].PAGE_NO1}${page}`);
            const data = await res.json();
            setApiDetails(data);
        };
        $[1] = setApiDetails;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const changeUiData = t0;
    let t1;
    if ($[3] !== setApiDetails) {
        t1 = async (url)=>{
            const res_0 = await fetch(url);
            const data_0 = await res_0.json();
            setApiDetails(data_0);
        };
        $[3] = setApiDetails;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const movePages = t1;
    let t2;
    if ($[5] !== changeUiData || $[6] !== getApiDetails || $[7] !== movePages || $[8] !== personDatalimiit) {
        t2 = {
            getApiDetails,
            changeUiData,
            movePages,
            personDatalimiit,
            setpersonDatalimiit
        };
        $[5] = changeUiData;
        $[6] = getApiDetails;
        $[7] = movePages;
        $[8] = personDatalimiit;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    return t2;
};
_s(useContent, "3EcQVGJKJTlcu4L6ZTQVGbV6fgY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePersonContext"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/constant/buttonconstant.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ButtonConstant",
    ()=>ButtonConstant
]);
const ButtonConstant = {
    PAGE_NO1: 1,
    PAGE_NO2: 2,
    PAGE_NO3: 3,
    PAGE_NO4: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/component/Content/content.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Content
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/imageconstant.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/component/Content/content.module.scss [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/component/Content/useContent.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$buttonconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constant/buttonconstant.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function Content() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(40);
    if ($[0] !== "faffee7cd82228c8bebcf6a79e32f507288bf6379ae0b27f74ac353cc040aa00") {
        for(let $i = 0; $i < 40; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "faffee7cd82228c8bebcf6a79e32f507288bf6379ae0b27f74ac353cc040aa00";
    }
    const { getApiDetails, changeUiData, movePages, personDatalimiit } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContent"])();
    const totalPages = Math.ceil((getApiDetails?.count ?? 0) / personDatalimiit);
    const [currentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const startPage = Math.floor((currentPage - 1) / 5) * 5 + 1;
    console.log("StartPage is ", startPage);
    const endPage = Math.min(startPage + 5 - 1, totalPages);
    console.log("End Page is ", endPage);
    let visiblePages;
    if ($[1] !== endPage || $[2] !== startPage) {
        visiblePages = [];
        for(let i = startPage; i <= endPage; i++){
            visiblePages.push(i);
        }
        $[1] = endPage;
        $[2] = startPage;
        $[3] = visiblePages;
    } else {
        visiblePages = $[3];
    }
    console.log("the VisiblePages is ", visiblePages);
    let t0;
    if ($[4] !== getApiDetails?.results) {
        t0 = getApiDetails?.results.map(_ContentAnonymous);
        $[4] = getApiDetails?.results;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    const t1 = console.log("The Total Pages is ", totalPages);
    let t2;
    if ($[6] !== getApiDetails || $[7] !== movePages) {
        t2 = ({
            "Content[<button>.onClick]": ()=>getApiDetails?.previous && movePages(getApiDetails.previous)
        })["Content[<button>.onClick]"];
        $[6] = getApiDetails;
        $[7] = movePages;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    let t3;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].LEFT_ARROW,
            alt: "left arrow",
            width: 20,
            height: 20
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    let t4;
    if ($[10] !== t2) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t2,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[10] = t2;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    let t5;
    if ($[12] !== changeUiData) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$buttonconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonConstant"].PAGE_NO1)
            }["Content[<button>.onClick]"],
            children: "1"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[12] = changeUiData;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    let t6;
    if ($[14] !== changeUiData) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$buttonconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonConstant"].PAGE_NO2)
            }["Content[<button>.onClick]"],
            children: "2"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 91,
            columnNumber: 10
        }, this);
        $[14] = changeUiData;
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    let t7;
    if ($[16] !== changeUiData) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$buttonconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonConstant"].PAGE_NO3)
            }["Content[<button>.onClick]"],
            children: "3"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 101,
            columnNumber: 10
        }, this);
        $[16] = changeUiData;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[18] !== changeUiData) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            onClick: {
                "Content[<button>.onClick]": ()=>changeUiData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$buttonconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonConstant"].PAGE_NO4)
            }["Content[<button>.onClick]"],
            children: "4"
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 111,
            columnNumber: 10
        }, this);
        $[18] = changeUiData;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    let t9;
    if ($[20] !== getApiDetails || $[21] !== movePages) {
        t9 = ({
            "Content[<button>.onClick]": ()=>getApiDetails?.next && movePages(getApiDetails.next)
        })["Content[<button>.onClick]"];
        $[20] = getApiDetails;
        $[21] = movePages;
        $[22] = t9;
    } else {
        t9 = $[22];
    }
    let t10;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].RIGHT_ARROW,
            alt: "left arrow",
            width: 20,
            height: 20
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 132,
            columnNumber: 11
        }, this);
        $[23] = t10;
    } else {
        t10 = $[23];
    }
    let t11;
    if ($[24] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t9,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
            children: t10
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 139,
            columnNumber: 11
        }, this);
        $[24] = t9;
        $[25] = t11;
    } else {
        t11 = $[25];
    }
    let t12;
    if ($[26] !== t11 || $[27] !== t4 || $[28] !== t5 || $[29] !== t6 || $[30] !== t7 || $[31] !== t8) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer,
            children: [
                t4,
                t5,
                t6,
                t7,
                t8,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 147,
            columnNumber: 11
        }, this);
        $[26] = t11;
        $[27] = t4;
        $[28] = t5;
        $[29] = t6;
        $[30] = t7;
        $[31] = t8;
        $[32] = t12;
    } else {
        t12 = $[32];
    }
    let t13;
    if ($[33] !== visiblePages) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: visiblePages.map(_ContentVisiblePagesMap)
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[33] = visiblePages;
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    let t14;
    if ($[35] !== t0 || $[36] !== t1 || $[37] !== t12 || $[38] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t0,
                    t1,
                    t12,
                    t13
                ]
            }, void 0, true)
        }, void 0, false, {
            fileName: "[project]/src/component/Content/content.tsx",
            lineNumber: 168,
            columnNumber: 11
        }, this);
        $[35] = t0;
        $[36] = t1;
        $[37] = t12;
        $[38] = t13;
        $[39] = t14;
    } else {
        t14 = $[39];
    }
    return t14;
}
_s(Content, "OXIfQ0fMX1CunfonuUy6Rjw8Kaw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$useContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContent"]
    ];
});
_c = Content;
function _ContentVisiblePagesMap(item, index_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_footer_button,
        children: item
    }, index_0, false, {
        fileName: "[project]/src/component/Content/content.tsx",
        lineNumber: 180,
        columnNumber: 10
    }, this);
}
function _ContentAnonymous(resultDataItem, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_image,
                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constant$2f$imageconstant$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageConstant"].CONTENT_IMAGE,
                alt: resultDataItem.name,
                height: 200,
                width: 200
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 183,
                columnNumber: 66
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_heading,
                children: resultDataItem.name
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 183,
                columnNumber: 205
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main_container_cards_paragrpah,
                children: resultDataItem.birth_year
            }, void 0, false, {
                fileName: "[project]/src/component/Content/content.tsx",
                lineNumber: 183,
                columnNumber: 282
            }, this)
        ]
    }, index, true, {
        fileName: "[project]/src/component/Content/content.tsx",
        lineNumber: 183,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "Content");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/component/Content/content.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function Home() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "24ff0f5a9e6f3d303bb7201118eb197c7971c3a2fadb075c0d25a861c5407863") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "24ff0f5a9e6f3d303bb7201118eb197c7971c3a2fadb075c0d25a861c5407863";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Content$2f$content$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 15,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_5e44b515._.js.map