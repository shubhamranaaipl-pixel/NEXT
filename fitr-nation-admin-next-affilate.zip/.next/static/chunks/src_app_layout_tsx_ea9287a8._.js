(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__1115feba._.css",
  "static/chunks/src_dd81a835._.js",
  "static/chunks/node_modules_next_dist_compiled_crypto-browserify_index_07270ec0.js",
  "static/chunks/node_modules_next_dist_compiled_7885e16c._.js",
  "static/chunks/node_modules_next_dist_0eb804ea._.js",
  "static/chunks/node_modules_next_faaaf81d._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_@apollo_client_61a6c80e._.js",
  "static/chunks/node_modules_graphql_da3ade5a._.js",
  "static/chunks/node_modules_ffce4883._.js"
],
    source: "dynamic"
});
