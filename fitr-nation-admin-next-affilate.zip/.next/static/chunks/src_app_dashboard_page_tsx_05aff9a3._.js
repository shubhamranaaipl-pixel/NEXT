(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-apexcharts_dist_react-apexcharts_min_98900f28.js",
  "static/chunks/_33246f82._.js"
],
    source: "dynamic"
});
