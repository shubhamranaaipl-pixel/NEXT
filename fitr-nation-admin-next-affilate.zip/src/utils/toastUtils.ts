// toastUtils.ts
import { toast, ToastOptions } from "react-hot-toast";

// Define default toast options
const defaultOptions: ToastOptions = {
  position: "top-right", // react-hot-toast supports 'top-right' with custom styling
  duration: 12000,
};

// Function to show success toast
export const showSuccessToast = (message: string, options?: ToastOptions) => {
  toast.success(message, { ...defaultOptions, ...options });
};

// Function to show error toast
export const showErrorToast = (message: string, options?: ToastOptions) => {
  toast.error(message, { ...defaultOptions, ...options });
};

// Function to show info toast
export const showInfoToast = (message: string, options?: ToastOptions) => {
  toast(message, { ...defaultOptions, ...options, icon: "ℹ️" });
};

// Function to show warning toast
export const showWarningToast = (message: string, options?: ToastOptions) => {
  toast(message, { ...defaultOptions, ...options, icon: "⚠️" });
};
