type Environment = "development" | "staging" | "production";

interface Config {
  apiUrl: string;
  environment: Environment;
  graphQlUrl:string;
}

const environment: Environment =
  (process.env.NEXT_PUBLIC_ENV as Environment) || "development";

const config: Config = {
  graphQlUrl:(process.env.NEXT_PUBLIC_GRAPHQL_URL || "") + "/graphql",
  apiUrl: process.env.NEXT_PUBLIC_GRAPHQL_URL || "",
  environment
};

export default config;
