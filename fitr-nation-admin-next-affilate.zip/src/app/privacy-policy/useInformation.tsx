import { ROUTES } from "@/constants/routes.constants";
import { TRANSLATIONS } from "@/constants/translationConstants";
import { AdminGetResponseModel, InformationCreateRequestModel, InformationCreateResponseModel, InformationGetRequestModel, InformationUpdateRequestModel, InformationUpdateResponseModel } from "@/modules/information/models/informationModel";
import { informationApiProvider } from "@/modules/information/providers/informationApiProvider";
import { showSuccessToast } from "@/utils/toastUtils";
import { useApolloClient } from "@apollo/client";
import { useTranslations } from "next-intl";
import { usePathname } from "next/navigation";
import { useState, useEffect, useCallback } from "react";

export const useInformation = () => {
    const pathname = usePathname();
    const [isHtmlValue, setIsHtmlValue] = useState<string>('');
    const [id, setId] = useState<number | null>(null);
    const client = useApolloClient();
    const commonTranslations = useTranslations(TRANSLATIONS.COMMON);
    const getcurrentInformation = useCallback(() => {
        const variables: InformationGetRequestModel = {
            get_information_page_input: {
                slug: pathname.replace(/^\/+/, ''),
            }
        }
        informationApiProvider.apolloInstance.adminGetInformation(
            client,
            variables,
            (success) => {
                const response = (success.data as AdminGetResponseModel)?.adminGetInformationPage;
                if (response) {
                    setIsHtmlValue(response?.description ?? '');
                    setId(response?.id ?? null);
                }
            },
            () => { }
        )
    }, [client, pathname]);

    useEffect(() => {
        getcurrentInformation();
    }, [getcurrentInformation]);

    const getTitleFromPath = () => {
        switch (pathname) {
            case ROUTES.PRIVACY:
                return commonTranslations(TRANSLATIONS.PRIVACYPOLICY);
            case ROUTES.TERMS:
                return commonTranslations(TRANSLATIONS.TERMSANDCONDITIONS);
            default:
                return '';
        }
    };

    const handleCreateInformation = () => {
        const path = pathname.replace(/^\/+/, '');
        const informationValues = {
            description: isHtmlValue,
            sort_order: 1,
            status: 1,
            title: getTitleFromPath(),
            slug: path
        }

        if (id) {
            const variables: InformationUpdateRequestModel = {
                update_information_page_input: {
                    id,
                    ...informationValues
                }
            }
            informationApiProvider.apolloInstance.adminUpdateInformation(
                client,
                variables,
                (success) => {
                    const response = (success?.data as InformationUpdateResponseModel)?.adminUpdateInformationPage;
                    if (response?.success) {
                        showSuccessToast(response?.message ?? '');
                        getcurrentInformation();
                    }
                },
                () => { }
            )
        } else {
            const variables: InformationCreateRequestModel = {
                create_information_page_input: informationValues
            }
            informationApiProvider.apolloInstance.adminCreateInformation(
                client,
                variables,
                (success) => {
                    const response = (success?.data as InformationCreateResponseModel)?.adminCreateInformationPage;
                    if (response?.success) {
                        showSuccessToast(response?.message ?? '');
                        getcurrentInformation();
                    }
                },
                () => { }
            )
        }
    }

    const handleEditorContent = (value: string) => {
        setIsHtmlValue(value);
    }

    return {
        isHtmlValue,
        handleEditorContent,
        handleCreateInformation,
        commonTranslations,
        TRANSLATIONS
    };
}