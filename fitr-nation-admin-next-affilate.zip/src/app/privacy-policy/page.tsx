'use client';
import HtmlEditor from "@/components/ui/HtmlEditor/HtmlEditor";
import { Fragment } from "react";
import { useInformation } from "@/app/privacy-policy/useInformation";

const PrivacyPolicyPage = () => {
  const {
    isHtmlValue,
    handleEditorContent,
    handleCreateInformation,
    commonTranslations,
    TRANSLATIONS
  } = useInformation();

  return (
    <Fragment>
      <HtmlEditor isDefaultValue={isHtmlValue} onContentChange={handleEditorContent} />
      <div className="block h-fit items-center justify-end w-full mt-10 sm:flex">
        <button className="flex w-full sm:w-60 h-fit items-center justify-center rounded-[3px] p-[7px] bg-primary text-white" onClick={handleCreateInformation}>{commonTranslations(TRANSLATIONS.SUBMIT)}</button>
      </div>
    </Fragment>
  )
}


export default PrivacyPolicyPage;