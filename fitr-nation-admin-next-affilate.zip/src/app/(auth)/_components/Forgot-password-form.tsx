"use client";

import { Controller } from "react-hook-form";
import Input from "@/components/Input/Input";
import { useAuthState } from "@/app/(auth)/useAuthState";
import ButtonForm from "@/app/(auth)/_components/Button-form";

const ForgotPasswordFormPage = () => {
  const {
    isLoading,
    onForgotPasswordSubmit,
    forgotPasswordControl,
    handleForgotPasswordSubmit,
    forgotPasswordErrors,
    commonTranslation,
    TRANSLATIONS
  } = useAuthState();
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2 text-dark dark:text-white">
          {commonTranslation(TRANSLATIONS.FORGETPASSWORD)}?
        </h2>
        <p className="text-dark-6 dark:text-white">
        {commonTranslation(TRANSLATIONS.SENDOTPTEXT)}
        </p>
      </div>
      <form onSubmit={handleForgotPasswordSubmit(onForgotPasswordSubmit)}>
        <Controller
          name="email"
          control={forgotPasswordControl}
          defaultValue=""
          render={({ field }) => (
            <Input
              {...field}
              type="input"
              handleChange={field.onChange}
              onBlur={field.onBlur}
              label={commonTranslation(TRANSLATIONS.EMAIL)}
              className="mb-4 [&_input]:py-[15px]"
              placeholder={commonTranslation(TRANSLATIONS.ENTERYOUREMAILADDRESS)}
              error={forgotPasswordErrors.email ? forgotPasswordErrors.email.message : ''}
            />
          )}
        />
        <ButtonForm buttonText={commonTranslation(TRANSLATIONS.VERIFYANDPROCEED)} isLoading={isLoading} />
      </form>
    </div>
  );
};

export default ForgotPasswordFormPage;
