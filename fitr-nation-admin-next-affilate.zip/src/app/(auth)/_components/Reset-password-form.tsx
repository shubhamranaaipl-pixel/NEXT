"use client";

import Input from "@/components/Input/Input";
import { Controller } from "react-hook-form";
import { useAuthState } from "@/app/(auth)/useAuthState";
import ButtonForm from "@/app/(auth)/_components/Button-form";

const ResetPasswordFormPage = () => {
  const {
    isLoading,
    onResetPasswordSubmit,
    resetPasswordControl,
    handleResetPasswordSubmit,
    resetPasswordErrors,
    commonTranslation,
    TRANSLATIONS
  } = useAuthState();

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2 text-dark dark:text-white">
          {commonTranslation(TRANSLATIONS.RESETYOURPASSWORD)}
        </h2>
      </div>
      <form onSubmit={handleResetPasswordSubmit(onResetPasswordSubmit)}>
        <Controller
          name="password"
          control={resetPasswordControl}
          defaultValue=""
          render={({ field }) => (
            <Input
              {...field}
              type="password"
              handleChange={field.onChange}
              onBlur={field.onBlur}
              label={commonTranslation(TRANSLATIONS.PASSWORD)}
              className="mb-4 [&_input]:py-[15px]"
              placeholder={commonTranslation(TRANSLATIONS.ENTERYOURCONFIRMPASSWORD)}
              error={resetPasswordErrors.password ? resetPasswordErrors.password.message : ''}
            />
          )}
        />

        <Controller
          name="confirm_password"
          control={resetPasswordControl}
          defaultValue=""
          render={({ field }) => (
            <Input
              {...field}
              type="password"
              handleChange={field.onChange}
              onBlur={field.onBlur}
              label={commonTranslation(TRANSLATIONS.CONFIRMPASSWORD)}
              className="mb-4 [&_input]:py-[15px]"
              placeholder={commonTranslation(TRANSLATIONS.ENTERYOURCONFIRMPASSWORD)}
              error={resetPasswordErrors.confirm_password ? resetPasswordErrors.confirm_password.message : ''}
            />
          )}
        />
        <ButtonForm buttonText={commonTranslation(TRANSLATIONS.RESETPASSWORD)} isLoading={isLoading} />
      </form>
    </div>
  );
};

export default ResetPasswordFormPage;
