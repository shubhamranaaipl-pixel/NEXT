import ResetPasswordFormPage from "@/app/(auth)/_components/Reset-password-form";

const ResetPasswordPage = () => {
  return <ResetPasswordFormPage />;
};

export default ResetPasswordPage;