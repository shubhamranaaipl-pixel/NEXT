import { Metadata } from "next";
import mainLogo from "@/assets/logos/logo.png";
import Image from "next/image";
import LoginForm from "@/app/(auth)/_components/Login-form";
import { Fragment } from "react";

export const metadata: Metadata = {
  title: "Sign in page",
  description: "Sign in page",
};

export default async function Auth() {
  return (
    <Fragment>
      <div className="flex items-center justify-center">
      <Image src={mainLogo} alt="logo" priority unoptimized />
      </div>
      <LoginForm />
    </Fragment>
  );
}
