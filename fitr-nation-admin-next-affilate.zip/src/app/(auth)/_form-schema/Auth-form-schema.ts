import { TRANSLATIONS } from "@/constants/translationConstants";
import { z } from "zod";

// Define the Zod schema for reset password form validation
export const resetPasswordSchema = z
  .object({
    // Validate password: required and at least 6 characters
    password: z
      .string()
      .nonempty(TRANSLATIONS.PASSWORDREQUIRED)
      .min(6, TRANSLATIONS.PASSWORDMINLENGTH),
    // Validate confirm password: required and at least 6 characters
    confirm_password: z
      .string()
      .nonempty(TRANSLATIONS.CONFIRMPASSWORDREQUIRED)
      .min(6, TRANSLATIONS.CONFIRMPASSWORDMINLENGTH),
  })
  // Ensure password and confirm_password match
  .refine((data) => data.password === data.confirm_password, {
    path: ["confirm_password"], // Target confirm_password field for error message
    message: TRANSLATIONS.CONFIRMPASSWORDSDONOTMATCH, // Custom error message
  });

// Infer the TypeScript type from the schema for strong typing in the form
export type resetPasswordFormInputs = z.infer<typeof resetPasswordSchema>;


// Define the Zod schema for forgot password form validation
export const forgotPasswordSchema = z.object({
  // Validate email: required
  email: z
    .string()
    .nonempty(TRANSLATIONS.EMAILREQUIRED)
    .email(TRANSLATIONS.EMAILINVALID),
});

// Infer the TypeScript type from the schema for strong typing in the form
export type forgotPasswordFormInputs = z.infer<typeof forgotPasswordSchema>;

export const loginSchema = z.object({
  email: z.string()
    .nonempty(TRANSLATIONS.EMAILREQUIRED)
    .email(TRANSLATIONS.VALIDEMAIL),
  password: z.string()
    .nonempty(TRANSLATIONS.PASSWORDREQUIRED),
});
export type LoginFormInputs = z.infer<typeof loginSchema>;

// Define the Zod schema for forgot password form validation
export const otpSchema = z.object({
  // Validate all otp: required
  otp0: z.string().nonempty(TRANSLATIONS.OTPREQUIRED).min(1),
  otp1: z.string().nonempty(TRANSLATIONS.OTPREQUIRED).min(1),
  otp2: z.string().nonempty(TRANSLATIONS.OTPREQUIRED).min(1),
  otp3: z.string().nonempty(TRANSLATIONS.OTPREQUIRED).min(1),
});

// Infer the TypeScript type from the schema for strong typing in the form
export type otpFormInputs = z.infer<typeof otpSchema>;


// Define the Zod schema for change password form validation
export const changePasswordSchema = z
  .object({
    // Validate old password: required and at least 6 characters
    old_password: z
      .string()
      .nonempty(TRANSLATIONS.OLDPASSWORDREQUIRED)
      .min(6, TRANSLATIONS.OLDPASSWORDMINLENGTH),
    // Validate new password: required and at least 6 characters
    new_password: z
      .string()
      .nonempty(TRANSLATIONS.NEWPASSWORDREQUIRED)
      .min(6, TRANSLATIONS.NEWPASSWORDMINLENGTH),
    // Validate confirm password: required and at least 6 characters
    confirm_password: z
      .string()
      .nonempty(TRANSLATIONS.CONFIRMPASSWORDREQUIRED)
      .min(6, TRANSLATIONS.CONFIRMPASSWORDMINLENGTH),
  })
  // Ensure new_password and confirm_password match
  .refine((data) => data.new_password === data.confirm_password, {
    path: ["confirm_password"], // Target confirm_password field for error message
    message: TRANSLATIONS.CONFIRMPASSWORDSDONOTMATCH, // Custom error message
  });

// Infer the TypeScript type from the schema for strong typing in the form
export type changePasswordFormInputs = z.infer<typeof changePasswordSchema>;