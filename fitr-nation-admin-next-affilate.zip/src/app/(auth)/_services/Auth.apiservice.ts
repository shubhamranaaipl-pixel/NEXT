import {
  ApolloClient,
  ApolloError,
  FetchResult,
  OperationVariables,
} from "@apollo/client";
import { GraphQLError, GraphQLFormattedError } from "graphql";
import { ApolloService } from "@/graphql/ApolloService";
import { loginMutation, logoutMutation, resetPasswordMutation, adminSendOtpMutation, changePasswordMutation, adminVerifyOtpMutation } from "@/app/(auth)/_mutations/Auth.mutations";

export class AuthApiProvider extends ApolloService {
  static apolloInstance: AuthApiProvider = new AuthApiProvider();

  /**
   * Mutation for Login admin
   * @param client
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
  adminLogin(
    client: ApolloClient<object>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: FetchResult<unknown>) => void,
    errorcallback: (
      _response:
        | (GraphQLError | GraphQLFormattedError | ApolloError)
        | undefined
    ) => void
  ): void {
    this.mutateApollo(
      client,
      loginMutation,
      variables,
      async (success) => successCallBack(success),
      errorcallback
    );
  }


  adminLogout(
    client: ApolloClient<object>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: FetchResult<unknown>) => void,
    errorcallback: (
      _response:
        | (GraphQLError | GraphQLFormattedError | ApolloError)
        | undefined
    ) => void
  ): void {
    this.mutateApollo(
      client,
      logoutMutation,
      variables,
      async (success) => successCallBack(success),
      errorcallback
    );
  }

  /**
   * Mutation for admin reset password
   * @param client
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
  adminResetPassword(
    client: ApolloClient<object>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: FetchResult<unknown>) => void,
    errorcallback: (
      _response:
        | (GraphQLError | GraphQLFormattedError | ApolloError)
        | undefined
    ) => void
  ): void {
    this.mutateApollo(
      client,
      resetPasswordMutation,
      variables,
      async (success) => successCallBack(success),
      errorcallback
    );
  }

  /**
   * Mutation for admin send otp
   * @param client
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
  adminSendOtp(
    client: ApolloClient<object>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: FetchResult<unknown>) => void,
    errorcallback: (
      _response:
        | (GraphQLError | GraphQLFormattedError | ApolloError)
        | undefined
    ) => void
  ): void {
    this.mutateApollo(
      client,
      adminSendOtpMutation,
      variables,
      async (success) => successCallBack(success),
      errorcallback
    );
  }
  

  /**
   * Mutation for admin reset password
   * @param client
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
  changePassword(
    client: ApolloClient<object>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: FetchResult<unknown>) => void,
    errorcallback: (
      _response:
        | (GraphQLError | GraphQLFormattedError | ApolloError)
        | undefined
    ) => void
  ): void {
    this.mutateApollo(
      client,
      changePasswordMutation,
      variables,
      async (success) => successCallBack(success),
      errorcallback
    );
  }

    /**
   * Mutation for send otp
   * @param client
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
    verifyOtp(
      client: ApolloClient<object>,
      variables: OperationVariables | undefined,
      successCallBack: (_response: FetchResult<unknown>) => void,
      errorcallback: (
        _response:
          | (GraphQLError | GraphQLFormattedError | ApolloError)
          | undefined
      ) => void
    ): void {
      
      this.mutateApollo(
        client,
        adminVerifyOtpMutation,
        variables,
        async (success) => successCallBack(success),
        errorcallback
      );
    }
}
