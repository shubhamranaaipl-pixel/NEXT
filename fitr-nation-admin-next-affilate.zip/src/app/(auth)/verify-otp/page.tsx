import OTPInput from "@/app/(auth)/_components/Verify-otp-form";

const VerifyOtpPage = () => {
  return  <OTPInput />;
};

export default VerifyOtpPage;