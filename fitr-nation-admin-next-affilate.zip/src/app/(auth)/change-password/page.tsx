import ChangePasswordFormPage from "@/app/(auth)/_components/Change-password-form";

const ChangePasswordPage = () => {
  return <ChangePasswordFormPage />
};

export default ChangePasswordPage;