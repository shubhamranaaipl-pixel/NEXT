import gql from "graphql-tag";

export const loginMutation = gql`
  mutation adminLogin($admin_login_input: AdminLoginInput!) {
    adminLogin(admin_login_input: $admin_login_input) {
      id
      full_name
      profile_name
      mobile
      email
      role {
        id
        name
        permissions
      }
      access_token
      refresh_token
      provider
      created_at
    }
  }
`;

export const logoutMutation = gql`
  mutation adminLogout($admin_logout_input: AdminlogoutInput!) {
    adminLogout(admin_logout_input: $admin_logout_input) {
      success
      message
    }
  }
`;

export const forgetPasswordMutation = gql`
  mutation sendPasswordLink($send_password_link_input: SendPasswordLinkInput!) {
    sendPasswordLink(send_password_link_input: $send_password_link_input) {
      success
      message
    }
  }
`;

export const resetPasswordMutation = gql`
  mutation forgetPassword($forget_password_input: ForgetPasswordInput!) {
    forgetPassword(forget_password_input: $forget_password_input) {
      success
      message
    }
  }
`;

export const changePasswordMutation = gql`
  mutation changePassword($change_password_input: ChangePasswordInput!) {
    changePassword(change_password_input: $change_password_input) {
      success
      message
    }
  }
`;

export const adminSendOtpMutation = gql`
  mutation adminSendOtp($admin_send_otp_input: AdminSendOtpInput!) {
    adminSendOtp(admin_send_otp_input: $admin_send_otp_input) {
      success
      message
    }
  }
`;

export const adminVerifyOtpMutation = gql`
  mutation verifyOtp($verify_otp_input: VerifyOtpInput!) {
    verifyOtp(verify_otp_input: $verify_otp_input) {
      success
      message
    }
  }
`;
