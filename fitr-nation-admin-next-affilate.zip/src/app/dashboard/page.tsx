import { ConversionsCharts } from "@/components/Charts/conversions-chart";
import { WeeklySignups } from "@/components/Charts/weekly-signup-chart";
import { DashboardCardsGroup } from "./_components/dashboard-cards";
import { getOverviewData } from "./fetch";
import { getConversionData, getWeeklySignupsData } from "@/chart-service";



export default async function DashboardPage() {
  const overviewData = await getOverviewData();
  const ConversionsChartData = await getConversionData();
  const weeklySignupsData = await getWeeklySignupsData();

  return (
    <>
      <div>
        <div className="bg-primary text-white p-3 mb-2 w-full rounded-[10px]">
          Stripe is connected
        </div>
      
        <DashboardCardsGroup initialData={overviewData} />
      </div>
      <div className="flex mt-6 gap-8 w-full">
        <div className="w-1/2">
        
          <ConversionsCharts initialData={ConversionsChartData} />
        </div>
        <div className="w-1/2">
          <WeeklySignups initialData={weeklySignupsData} />
        </div>
      </div>
    </>
  );
}