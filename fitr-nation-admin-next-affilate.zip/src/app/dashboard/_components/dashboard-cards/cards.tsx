import { arrowdown, arrowup } from "@/assets/icons";
import { cn } from "@/utils/class-utils";
import Image from "next/image";

type PropsType = {
  label: string;
  data: {
    value: number | string;
    growthRate: number;
  };
  Icon: string;
};

export function DashboardCard({ label, data, Icon }: PropsType) {
  const isDecreasing = data.growthRate < 0;

  return (
    <div className="rounded-[10px] bg-white p-6 shadow-1 dark:bg-gray-dark">
      <Image
        src={Icon}
        alt="icon"
        width={50}
        height={50}
        priority
        unoptimized
      />
      <div className="mt-6 flex items-end justify-between">
        <dl>
          <dt className="mb-1.5 text-heading-6 font-bold text-dark dark:text-white">
            {data.value}
          </dt>

          <dd className="text-sm font-medium text-dark-6">{label}</dd>
        </dl>

        <dl
          className={cn(
            "text-sm font-medium",
            isDecreasing ? "text-red" : "text-green",
          )}
        >
          <dt className="flex items-center gap-1.5">
            {data.growthRate}%
            {isDecreasing ? (
              <Image
                src={arrowdown}
                alt="arrowup"
                width={10}
                height={10}
                priority
                unoptimized
                style={{
                  filter: 'brightness(0) saturate(100%) invert(39%) sepia(74%) saturate(6145%) hue-rotate(348deg) brightness(107%) contrast(90%)'
                }}
              />
            ) : (
              <Image
                src={arrowup}
                alt="arrowup"
                width={10}
                height={10}
                priority
                unoptimized
                style={{
                  filter: 'brightness(0) saturate(100%) invert(53%) sepia(27%) saturate(1102%) hue-rotate(92deg) brightness(97%) contrast(93%)'
                }}
              />
            )}
          </dt>

          <dd className="sr-only">
            {label} {isDecreasing ? "Decreased" : "Increased"} by{" "}
            {data.growthRate}%
          </dd>
        </dl>
      </div>
    </div>
  );
}
