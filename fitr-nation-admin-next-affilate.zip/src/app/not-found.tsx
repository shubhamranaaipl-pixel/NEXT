"use client";
import { ROUTES } from '@/constants/routes.constants';
import { useAuthContext } from '@/context/AuthContext';
import { useLoading } from '@/context/LoadingContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

const NotFoundPage: React.FC = () => {
  const router = useRouter();
  const { isAuthenticated } = useAuthContext();
  const { showLoader, hideLoader } = useLoading();

  useEffect(() => {
    showLoader();
    if (isAuthenticated) {
      router.replace(ROUTES.DASHBOARD);
    } else {
      router.replace(ROUTES.LOGIN);
    }
    return () => {
      hideLoader();
    };
  }, [router, isAuthenticated, showLoader, hideLoader]);

  return null;
};

export default NotFoundPage;
