import { SVGAttributes } from "react";

type PropsType = SVGAttributes<SVGSVGElement>;


export { default as search } from "./search.svg";
export { default as chevronup } from "./chevronup.svg";
export { default as chevronleft } from "./chevronleft.svg";
export { default as chevronright } from "./chevronright.svg";
export { default as arrowup } from "./arrowup.svg";
export { default as arrowdown } from "./arrowdown.svg";
export { default as arrowleft } from "./arrowleft.svg";
export { default as check } from "./check.svg";
export { default as cross } from "./cross.svg";
export { default as menu } from "./menu.svg";
export { default as password } from "./password.svg";
export { default as viewicon } from "./view.svg";
export { default as profileicon } from "./profile.svg";
export { default as producticon } from "./product.svg";
export { default as usersicon } from "./users.svg";
export { default as add } from "./add.svg";
export { default as remove } from "./delete.svg";

export { default as user } from "./user.svg";
export { default as inbox } from "./inbox.svg";
export { default as home } from "./home.svg";
export { default as calendar } from "./calendar.svg";
export { default as table } from "./table.svg";


export { default as delivery } from "./delivery.svg";
export { default as desigen } from "./desigen.svg";
export { default as equipment } from "./equipment.svg";
export { default as sport } from "./sport.svg";
export { default as level } from "./level.svg";
export { default as muscle } from "./muscle.svg";
export { default as exercise } from "./exercise.svg";
export { default as workout } from "./workout.svg";
export { default as score } from "./score.svg";
export { default as checked } from "./checked.svg";
export { default as clone } from "./clone.svg";

export { default as training } from "./training.svg";

export function ChevronUpIcon(props: PropsType) {
  return (
    <svg
      width={22}
      height={22}
      viewBox="0 0 22 22"
      fill="currentColor"
      {...props}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M10.551 7.728a.687.687 0 01.895 0l6.417 5.5a.687.687 0 11-.895 1.044l-5.97-5.117-5.969 5.117a.687.687 0 01-.894-1.044l6.416-5.5z"
      />
    </svg>
  );
}