import { ROUTES } from "./routes.constants";

export const KILOGRAM_TO_POUNDS = 2.20462;
export const POUNDS_TO_KILOGRAM = 0.453592;
export const KILOGRAM_TO_STONE = 0.157473;
export const STONE_TO_KILOGRAM = 6.35029;
export const POUNDS_TO_STONE = 1 / 14;
export const STONE_TO_POUNDS = 14;

export const CENTIMETERS_TO_FEET = 0.0328084;
export const FEET_TO_CENTIMETERS = 30.48;

export const CENTIMETERS_TO_METERS = 0.01;
export const METERS_TO_CENTIMETERS = 100;

export const METERS_TO_KILOMETERS = 0.001;
export const KILOMETERS_TO_METERS = 1000;

export const KILOMETERS_TO_CENTIMETERS = 100000;
export const CENTIMETERS_TO_KILOMETERS = 0.00001;

export const MILES_TO_METERS = 1609.34;
export const METERS_TO_MILES = 1 / MILES_TO_METERS;

export const MILES_TO_CENTIMETERS = 160934;
export const CENTIMETERS_TO_MILES = 1 / MILES_TO_CENTIMETERS;

export const MILES_TO_KILOMETERS = 1.60934;
export const KILOMETERS_TO_MILES = 1 / MILES_TO_KILOMETERS;

export const SECONDS_TO_MINUTES = 1 / 60;
export const MINUTES_TO_SECONDS = 60;

export const SECONDS_TO_HOURS = 1 / 3600;
export const HOURS_TO_SECONDS = 3600;

export const MINUTES_TO_HOURS = 1 / 60;
export const HOURS_TO_MINUTES = 60;

export const INTEGER_REGEX = /^[0-9]$/;
export const IGNORE_ROUTES: string[] = [
  ROUTES.ROOT,
  ROUTES.FORGOT_PASSWORD,
  ROUTES.RESET_PASSWORD,
  ROUTES.VERIFY_OTP,
];

export const IGNORE_CATEGORY: string[] = [];
