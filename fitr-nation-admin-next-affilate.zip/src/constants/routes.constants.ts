export const mainRoutes = {
  home: "/",
  auth: "/auth",
};

export const internalApiRoutes = {
  login: "/api/auth/login",
};

export const ROUTES = {
  ROOT: "/",
  DASHBOARD: "/dashboard",
  LOGIN: "/login",
  ADD: "/add",
  FORGOT_PASSWORD: "/forgot-password",
  RESET_PASSWORD: "/reset-password",
  VERIFY_OTP: "/verify-otp",
  CHANGE_PASSWORD: "/change-password",
  PRIVACY: "/privacy-policy",
  TERMS: "/terms-and-conditions",
};
