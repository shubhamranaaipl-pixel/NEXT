export enum LocalStorageKeysEnum {
  TOKEN_DATA = "TOKEN_DATA",
  USER_INFO = "USER_INFO",
  ROLE = "ROLE",
  DEVICE_ID = "DEVICE_ID",
  EMAIL = "EMAIL",
}

export enum ServerRoleEnum {
  SUPERADMIN = "SuperAdmin",
}

export enum RoleFilterEnum {
  SUPERADMIN = 1,
  TRAINER = 2,
  USER = 3,
  AFFILIATE = 4,
}

export enum UserSortBy {
  FULL_NAME = "FULL_NAME",
  EMAIL = "EMAIL",
  CREATED = "CREATED",
  GENDER = "GENDER",
}

export enum ListSortOrder {
  ASC = "ASC",
  DESC = "DESC",
}

export enum StatusEnum {
  ACTIVE = 1,
  INACTIVE = 2,
}

export enum WorkoutAccessTypeEnum {
  STANDARD = "STANDARD",
  FREEMIUM = "FREEMIUM"
}

export enum Action {
  EDIT = "EDIT",
  DELETE = "DELETE",
  DETAILS = "DETAILS",
}

export enum PlatformEnumModel {
  ANDROID = "ANDROID",
  IOS = "IOS",
  WEB = "WEB",
}

export enum WorkoutModuleEnum {
  DESIGNED = 'DESIGNED',
  DELIVERY_CAPACITY = 'DELIVERY_CAPACITY',
  FITNESS_SCORE_CATEGORY = 'FITNESS_SCORE_CATEGORY',
  WORKOUT_FORMAT = 'WORKOUT_FORMAT',
  EQUIPMENT = 'EQUIPMENT',
  WORKOUT_TYPES = 'WORKOUT_TYPES',
  WORKOUT_INTESNITY_LEVEL = 'WORKOUT_INTESNITY_LEVEL',
  SPORTS_SPECIFICITY = 'SPORTS_SPECIFICITY',
  MUSCLE_GROUP = 'MUSCLE_GROUP',
  SERIES_OVERVIEW = 'SERIES_OVERVIEW',
  TRAINING_SETTING = 'TRAINING_SETTING'
}

export enum CategoryModuleEnum {
  WORKOUT_TYPES = 'WORKOUT_TYPES',
  WORKOUT_INTESNITY_LEVEL = 'WORKOUT_INTESNITY_LEVEL',
  SPORTS_SPECIFICITY = 'SPORTS_SPECIFICITY',
  MUSCLE_GROUP = 'MUSCLE_GROUP',
  FITNESS_SCORE_CATEGORY = 'FITNESS_SCORE_CATEGORY',
}


// Weight Units
export enum WeightUnitsEnum {
  MILLIGRAM = "MILLIGRAM",
  GRAM = "GRAM",
  KILOGRAM = "KILOGRAM",
  OUNCE = "OUNCE",
  POUNDS = "POUNDS",
  STONE = "STONE_UNIT",
  TONNE = "TONNE",
  US_TON = "US_TON",
  IMPERIAL_TON = "IMPERIAL_TON"
}

// Height / Length Units
export enum HeightUnitsEnum {
  MILLIMETER = "MILLIMETER",
  CENTIMETER = "CENTIMETER",
  METER = "METER",
  INCH = "INCH",
  FEET = "FEET",
  YARD = "YARD"
}

// Time Units
export enum TimeUnitsEnum {
  MILLISECOND = "MILLISECOND",
  SECOND = "SECOND",
  MINUTE = "MINUTE",
  HOUR = "HOUR",
  DAY = "DAY",
  WEEK = "WEEK"
}

// Distance Units
export enum DistanceUnitsEnum {
  MILLIMETER = "MILLIMETER",
  CENTIMETER = "CENTIMETER",
  METER = "METER",
  KILOMETER = "KILOMETER",
  INCH = "INCH",
  FEET = "FEET",
  YARD = "YARD",
  MILE = "MILE",
  NAUTICAL_MILE = "NAUTICAL_MILE"
}


export enum DeleteEnum {
  SOFT = "SOFT",
  HARD = "HARD"
}