// Indicates that this file is a React component for the client-side
"use client";
import { UsersModel } from "@/app/(auth)/_types/Auth.types";
import { IGNORE_ROUTES } from "@/constants/appConstants";
import { LocalStorageKeysEnum } from "@/constants/enumConstants";
import { ROUTES } from "@/constants/routes.constants"; // Importing route constants
import { UNAUTH_EVENT } from "@/constants/serviceConstants";
import { eventBus } from "@/services/eventBus";

import { usePathname, useRouter } from "next/navigation"; // Hooks for Next.js routing
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react"; // React hooks and context utilities

// Define the shape of the authentication context
interface AuthContextType {
  isAuthenticated: boolean | null; // Indicates whether the user is authenticated
  checkAuth: () => void; // Function to check and update authentication status
  userInfo: UsersModel | undefined;
  userRole: string | undefined;
  setUserInfo: (userInfo: UsersModel | undefined) => void;
  setUserRole: (userRole: string | undefined) => void;
}

// Create the context for authentication
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Provider component to manage authentication context
export const AuthContextProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(true); // State to track authentication status
  const [userInfo, setUserInfo] = useState<UsersModel | undefined>(undefined);
  const [userRole, setUserRole] = useState<string | undefined>(undefined);
  const router = useRouter(); // Router instance for navigation
  const pathName = usePathname(); // Current pathname for route checking
  // Memoized function to check authentication status and handle redirection
  const checkAuth = useCallback(() => {
    const user = localStorage.getItem(LocalStorageKeysEnum.USER_INFO);
    const token = localStorage.getItem(LocalStorageKeysEnum.TOKEN_DATA); // Get the token from localStorage
    const role = localStorage.getItem(LocalStorageKeysEnum.ROLE); // Get the role from localStorage
    setIsAuthenticated(!!token); // Update authentication status based on token presence
    if (token && role && user) {
      setUserRole(role);
      setUserInfo(JSON.parse(user));
    }
    // Redirect user based on authentication status and current route
    if (!token && pathName !== ROUTES.LOGIN) {
      if (pathName && IGNORE_ROUTES.includes(pathName)) {
      } else {
        setUserRole(undefined);
        setUserInfo(undefined);
        router.replace(ROUTES.LOGIN); // Redirect to login page if not authenticated and not on login page
      }
    } else if (
      token &&
      pathName &&
      (pathName === ROUTES.LOGIN || IGNORE_ROUTES.includes(pathName))
    ) {
      router.replace(ROUTES.DASHBOARD); // Redirect to login page if not authenticated and not on login page
    }
  }, [pathName, router]); // Memoize based on router and pathName
  // useEffect(() => {
  //   const handleAuthEvent = (event: Event) => {
  //     if (event instanceof CustomEvent && event.type === UNAUTH_EVENT) {
  //       checkAuth(); // Refresh authentication status when event is triggered
  //     }
  //   };

  //   eventBus.addEventListener(UNAUTH_EVENT, handleAuthEvent as EventListener);

  //   return () => {
  //     eventBus.removeEventListener(
  //       UNAUTH_EVENT,
  //       handleAuthEvent as EventListener
  //     );
  //   };
  // }, [checkAuth]);
  // // Check authentication status when the component mounts or pathname/router/checkAuth changes
  // useEffect(() => {
  //   checkAuth();
  // }, [checkAuth]); // Include checkAuth in the dependency array

  // Provide the authentication context to children components
  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        checkAuth,
        userInfo,
        setUserInfo,
        setUserRole,
        userRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to access the authentication context
export const useAuthContext = (): AuthContextType => {
  const context = useContext(AuthContext); // Get context value
  if (!context) {
    throw new Error(
      "useAuthContext must be used within an AuthContextProvider"
    ); // Ensure the hook is used within a provider
  }
  return context; // Return the context value
};
