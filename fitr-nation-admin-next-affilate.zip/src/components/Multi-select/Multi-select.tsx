"use client";

import { cross } from "@/assets/icons";
import React, { useEffect, useRef, useState } from "react";
import { ChevronUp } from "../Icons/Icons";
import { cn } from "@/utils/class-utils";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";

export interface Option {
  id: string;
  title: string;
  description?: string;
}

interface DropdownProps {
  allOptions?: Option[];
  selectedOptions?: string[];
  label?: string;
  required?: boolean;
  onChange?: (selectedOptions: string[]) => void;
  error?: string;
  disabled?: boolean;
}

const MultiSelect: React.FC<DropdownProps> = ({
  allOptions,
  label,
  selectedOptions,
  onChange,
  error,
  required,
  disabled
}) => {
  const [show, setShow] = useState(false);
  const [searchQuery, setSearchQuery] = useState(""); // Track search input
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const trigger = useRef<HTMLDivElement | null>(null);
  const errorTranslation = useTranslations(TRANSLATIONS.ERRORSMESSAGE);

  const open = () => {
    if (disabled) return;
    setShow((prev) => !prev);
  };

  const isOpen = () => {
    return show === true;
  };

  const select = (id: string) => {
    if (selectedOptions?.includes(id)) {
      onChange?.(selectedOptions.filter((i) => i !== id));
    } else {
      onChange?.(selectedOptions ? [...selectedOptions, id] : [id]);
    }
  };

  const remove = (id: string) => {
    if (disabled) return;
    onChange?.(selectedOptions?.filter((i) => i !== id) as string[]);
  };

  // Filter options based on the search query
  const filteredOptions = allOptions?.filter((option) =>
    option.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    const clickHandler = (event: MouseEvent) => {
      const target = event.target as Node;
      if (!dropdownRef.current || !trigger.current) return;
      if (!show || dropdownRef.current.contains(target) || trigger.current.contains(target)) {
        return;
      }
      setShow(false);
    };

    document.addEventListener("click", clickHandler);
    return () => document.removeEventListener("click", clickHandler);
  }, [show]);

  return (
    <div
      className={cn("relative", {
        "z-10": isOpen(),
      })}
    >
      <label className="mb-3 block text-body-sm font-medium text-dark dark:text-white">
        {label}
        {required && <span className="ml-1 select-none text-red">*</span>}
      </label>
      <div>
        <div className="flex flex-col items-center">
          <div className="relative z-9 inline-block w-full">
            <div className="flex gap-2 mb-2 flex-wrap">
              {selectedOptions?.map((id, index) => (
                <div
                  key={index}
                  className="flex items-center justify-center rounded-[5px] border-[.5px] border-stroke bg-gray-2 px-2.5 py-[3px] text-body-sm font-medium dark:border-dark-3 dark:bg-dark"
                >
                  <div className="max-w-full flex-initial">
                    {
                      allOptions?.find((option) => option.id === id)
                        ?.title
                    }
                  </div>
                  {
                    !disabled && (
                      <div className="flex flex-auto flex-row-reverse">
                        <button
                          type="button"
                          onClick={() => remove(id)}
                          className="pl-1 hover:text-red"
                        >
                          <Image
                            src={cross}
                            alt="check"
                            width={10}
                            height={10}
                            priority
                            className="dark:invert-icon"
                            unoptimized />
                        </button>
                      </div>
                    )
                  }
                </div>
              ))}
            </div>
            <div className="relative flex flex-col items-center">
              <div ref={trigger} onClick={open} className="w-full">
                <div className="flex rounded-[7px] border-[1.5px] border-stroke py-[9px] pl-3 pr-3 outline-none transition focus:border-primary active:border-primary dark:border-dark-3 dark:bg-dark-2">
                  <div className="flex flex-auto flex-wrap gap-3">
                    <div className="flex-1">
                      <input
                        readOnly={disabled}
                        placeholder="Select an option"
                        value={searchQuery} // Set the input value to the search query
                        onChange={(e) => setSearchQuery(e.target.value)} // Update the search query
                        className="h-full w-full appearance-none bg-transparent p-1 px-2 text-dark-5 outline-none dark:text-dark-6"
                      />
                    </div>
                  </div>
                  {
                    !disabled && (
                      <div className="flex items-center py-1 pl-1 pr-1">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            open();
                          }}
                          className={`text-dark-4 transition outline-none focus:outline-none dark:text-dark-6 ${show ? "rotate-180" : ""}`}
                        >
                          <ChevronUp />
                        </button>
                      </div>
                    )
                  }
                </div>
              </div>
              <div className="w-full px-4">
                <div
                  className={`max-h-select absolute left-0 top-full z-40 w-full overflow-y-auto rounded bg-white shadow-1 dark:bg-dark-2 dark:shadow-card ${isOpen() ? "" : "hidden"
                    }`}
                  ref={dropdownRef}
                  onFocus={() => setShow(true)}
                  onBlur={() => setShow(false)}
                >
                  <div className="flex w-full flex-col h-full max-h-[110px] sm:max-h-[200px]">
                    {/* Use filtered options to show only the ones matching the search query */}
                    {filteredOptions?.map((option, index) => (
                      <div key={index}>
                        <div
                          className="w-full border-l-[1px] border-r-[1px] border-b-[1px] border-[#0000003b] cursor-pointer border-stroke md:hover:bg-primary md:hover:text-white dark:border-dark-3"
                          onClick={() => select(option.id)}
                        >
                          <div
                            className={`relative flex w-full items-center border-transparent p-2 pl-2 ${selectedOptions && selectedOptions.length > 0 && selectedOptions?.includes(option.id)
                              ? "bg-primary text-white"
                              : ""
                              }`}
                          >
                            <div className="flex w-full items-center">
                              <div className="mx-2 leading-6">
                                {option.title}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
            {error && <span className="mt-2 text-sm text-red">{errorTranslation(error)}</span>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MultiSelect;
