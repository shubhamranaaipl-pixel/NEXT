'use client';
import { useEffect, useState } from 'react';
import Editor, { ContentEditableEvent } from 'react-simple-wysiwyg';

type HtmlEditorProps = {
  onContentChange?: (value: string) => void; // callback to parent
  isDefaultValue?: string;
};

const HtmlEditor = ({ onContentChange,isDefaultValue }: HtmlEditorProps) => {
  const [value, setValue] = useState('');

  useEffect(() => {
    if(isDefaultValue){
      setValue(isDefaultValue);
    }
  },[isDefaultValue]);

  function onChange(e: ContentEditableEvent) {
    const newValue = e.target.value;
    setValue(newValue);
    if (onContentChange) {
      onContentChange(newValue); // notify parent
    }
  }

  return <Editor value={value} onChange={onChange} />;
};

export default HtmlEditor;
