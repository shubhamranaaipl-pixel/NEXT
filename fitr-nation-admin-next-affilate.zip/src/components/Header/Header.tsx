"use client";

import React, { Fragment, useEffect, useState } from "react";
import { ThemeToggleSwitch } from "./theme-toggle";
import { UserInfo } from "./user-info";
import { useSidebarContext } from "../sidebar/sidebar-context";
import { menu } from "@/assets/icons";
import { useAuthContext } from "@/context/AuthContext";
import { usePathname, useRouter } from "next/navigation";
import Image from "next/image";

const Header: React.FC = () => {
  const pathname = usePathname();
  const [path, setPath] = useState<string>('');
  const { toggleSidebar } = useSidebarContext();
  const { isAuthenticated } = useAuthContext();
  const [breadcrum, setBreadcrum] = useState<string[]>([]);
  const router = useRouter();
  useEffect(() => {
    setPath(pathname.split("/")[1].replaceAll("-", " "));
    setBreadcrum(pathname.split("/").filter((option) => option));
  }, [pathname])

  if (!isAuthenticated) {
    return null;
  }

  const handleBreadcrum = (segment: string, index: number) => {
    const targetPath = '/' + breadcrum.slice(0, index + 1).join('/');
    router.replace(targetPath);
  };
  return (
    <Fragment>
      <header className="sticky top-0 z-30 ">
        <div className="flex items-center justify-between border-b border-stroke bg-white px-4 py-5 dark:border-stroke-dark dark:bg-gray-dark md:px-5 2xl:px-10">
          <button
            onClick={toggleSidebar}
            className="rounded-lg border px-1.5 py-1 dark:border-stroke-dark dark:bg-[#020D1A] hover:dark:bg-[#FFFFFF1A] lg:hidden"
          >
            <Image
              src={menu}
              alt="menu"
              className="w-5 h-auto dark:invert-icon"
              priority
              unoptimized
            />
            <span className="sr-only">Toggle Sidebar</span>
          </button>

          <div className="max-xl:hidden">
            <div className="mb-0.5 capitalize text-heading-5 font-bold text-dark dark:text-white">
              {path}
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2 min-[375px]:gap-4">
            <ThemeToggleSwitch />
            {/* <Notification /> */}
            <UserInfo />
          </div>
        </div>
        <div className="dark:border-stroke-dark  dark:bg-gray-dark bg-white px-10 py-4 text-black border-b border-stroke flex gap-1 text-sm font-medium">
          {breadcrum && breadcrum.length > 0 ? (
            breadcrum.map((segment, index) => {
              const isLast = index === breadcrum.length - 1;
              const displayName = segment
                .replace(/-/g, ' ')
                .replace(/\b\w/g, (char) => char.toUpperCase());

              return (
                <Fragment key={index}>
                  <span
                    onClick={() => handleBreadcrum(segment, index)}
                    className={`cursor-pointer hover:underline ${isLast ? "text-gray-500" : "text-primary"}`}
                  >
                    {displayName}
                  </span>
                  {!isLast && <span className="text-gray-400">/</span>}
                </Fragment>
              );
            })
          ) : (
            <span className="text-gray-500">Home</span>
          )}
        </div>
      </header>

    </Fragment>
  );
};
export default Header;
