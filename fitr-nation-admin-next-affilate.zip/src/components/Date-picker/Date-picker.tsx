"use client";

import { Calendar } from "@/components/Icons/Icons";
import flatpickr from "flatpickr";
import { useEffect, useRef } from "react";

interface DatePickerProps {
  label: string;
  value?: Date;
  minDate?: Date;
  maxDate?: Date;
  onChange?: (selectedDate: Date | null) => void;
  error?: string;
  placeholder?: string
  required?: boolean;
}

const DatePicker = ({
  label,
  value,
  minDate,
  maxDate,
  onChange,
  error,
  placeholder,
  required
}: DatePickerProps) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const currentDate = new Date(); 
  useEffect(() => {
    if (!inputRef.current) return;

    flatpickr(inputRef.current, {
      mode: "single",
      static: true,
      monthSelectorType: "static",
      dateFormat: "M j, Y",
      defaultDate: value,
      minDate,
      maxDate: maxDate || currentDate,
      onChange: (selectedDates) => {
        if (onChange) {
          onChange(selectedDates[0] || null);
        }
      },
    });
  }, [value, minDate, maxDate, onChange]);

  return (
    <div>
      <label className="mb-3 block text-body-sm font-medium text-dark dark:text-white">
        {label}
        {required && <span className="ml-1 select-none text-red">*</span>}
      </label>
      <div className="relative">
        <input
          ref={inputRef}
          className="form-datepicker w-full rounded-[7px] border-[1.5px] border-stroke bg-transparent px-5 py-3 font-normal outline-none transition focus:border-primary active:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary"
          placeholder={placeholder}
          data-class="flatpickr-right"
        />
        <div className="pointer-events-none absolute inset-0 left-auto right-5 flex items-center">
          <Calendar className="size-5 text-[#9CA3AF]" />
        </div>
      </div>
      {error && <span className="mt-2 text-sm text-red">{error}</span>}
    </div>
  );
};

export default DatePicker;
