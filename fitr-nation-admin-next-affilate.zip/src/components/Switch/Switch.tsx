import { check, cross } from "@/assets/icons";
import { cn } from "@/utils/class-utils";
import Image from "next/image";
import { useId } from "react";

type PropsType = {
  withIcon?: boolean;
  background?: "dark" | "light";
  backgroundSize?: "sm" | "default";
  name?: string;
  labelOne?: string;
  labelTwo?: string;
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
};

export function Switch({
  background,
  withIcon,
  backgroundSize,
  name,
  labelOne,
  labelTwo,
  checked,
  onChange
}: PropsType) {
  const id = useId();

  return (
    <div className="flex items-center gap-2">
      {labelOne && (
        <label className="text-body-sm font-medium text-dark dark:text-white">
          {labelOne}
        </label>
      )}
      <label
        htmlFor={id}
        className="flex max-w-fit cursor-pointer select-none items-center"
      >
        <div className="relative">
          <input checked={checked} onChange={onChange} type="checkbox" name={name} id={id} className="peer sr-only" />
          <div
            className={cn("h-8 w-14 rounded-full bg-gray-3 dark:bg-[#5A616B]", {
              "h-5": backgroundSize === "sm",
              "bg-[#212B36] dark:bg-primary": background === "dark",
            })}
          />

          <div
            className={cn(
              "absolute left-1 top-1 flex size-6 items-center justify-center rounded-full bg-white shadow-switch-1 transition peer-checked:right-1 peer-checked:translate-x-full peer-checked:[&_.check-icon]:block peer-checked:[&_.x-icon]:hidden",
              {
                "-top-1 left-0 size-7 shadow-switch-2": backgroundSize === "sm",
                "peer-checked:bg-primary peer-checked:dark:bg-white":
                  background !== "dark",
              }
            )}
          >
            {withIcon && (
              <>
                <Image
                  src={check}
                  alt="check"
                  width={10}
                  height={10}
                  priority
                  unoptimized
                  className="check-icon hidden fill-white dark:fill-dark"
                />
                <Image
                  src={cross}
                  alt="check"
                  width={10}
                  height={10}
                  priority
                  unoptimized
                  className="x-icon" />
              </>
            )}
          </div>
        </div>
      </label>
      {labelTwo && (
        <label className="text-body-sm font-medium text-dark dark:text-white">
          {labelTwo}
        </label>
      )}
    </div>
  );
}
