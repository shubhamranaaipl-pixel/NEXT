"use client";
import { getConversionData } from "@/chart-service";
import { cn, standardFormat } from "@/utils/class-utils";
import { ConversionsChart } from "./chart";
import { useEffect, useState } from "react";
import { TRANSLATIONS } from "@/constants/translationConstants";
import { useTranslations } from "next-intl";
import { formatCurrency } from "@/utils/appUtils";
import { PeriodPicker } from "@/components/period-picker";


type PropsTypes = {
  selectedFilter?: string;
  className?: string;
  initialData?: Awaited<ReturnType<typeof getConversionData>>
};

export  function ConversionsCharts({
  selectedFilter = "monthly",
  className,
  initialData
}: PropsTypes) {
  const [data, setData] = useState(initialData);
  const dashboardTranslation=useTranslations(TRANSLATIONS.DASHBOARD);


  useEffect(() => { // Calling this method, if data is changed
    const getData = async () => {
      const fetchedData = await getConversionData(selectedFilter);
      setData(fetchedData);
     
    };
    getData();
  }, [selectedFilter]);

  if (!data) return null;
  return (
    <div
      className={cn(
        "grid gap-2 rounded-[10px] bg-white px-7.5 pb-6 pt-7.5 shadow-1 dark:bg-gray-dark dark:shadow-card",
        className,
      )}
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-body-2xlg font-bold text-dark dark:text-white">
          {dashboardTranslation(TRANSLATIONS.CONVERSIONS)}
        </h2>

        <PeriodPicker defaultValue={selectedFilter} sectionKey="payments_overview" />
          
      </div>

      <ConversionsChart data={data} />

      <dl className="grid divide-stroke text-center dark:divide-dark-3 sm:grid-cols-2 sm:divide-x [&>div]:flex [&>div]:flex-col-reverse [&>div]:gap-1">
        <div className="dark:border-dark-3 max-sm:mb-3 max-sm:border-b max-sm:pb-3">
          <dt className="text-xl font-bold text-dark dark:text-white">
           {formatCurrency(+standardFormat(data.received.reduce((acc, { y }) => acc + y, 0)))}
          </dt>
          <dd className="font-medium dark:text-dark-6">{dashboardTranslation(TRANSLATIONS.RECEIVEDAMOUNT)}</dd>
        </div>

        <div>
          <dt className="text-xl font-bold text-dark dark:text-white">
         {formatCurrency(+standardFormat(data.due.reduce((acc, { y }) => acc + y, 0)))}
          </dt>
          <dd className="font-medium dark:text-dark-6">{dashboardTranslation(TRANSLATIONS.DUEAMOUNT)}</dd>
        </div>
      </dl>
    </div>
  );
}
