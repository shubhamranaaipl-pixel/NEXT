"use client";

import React, { useEffect, useRef, useState } from "react";
import { ChevronUp } from "../Icons/Icons";
import { cn } from "@/utils/class-utils";
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";

export interface SingleOption {
  id: string;
  title: string;
  description?: string;
}

interface SingleSelectProps {
  allOptions?: SingleOption[];
  selectedOption?: SingleOption;
  label?: string;
  required?: boolean;
  onChange: (selectedOption: string | undefined) => void;
  onSearchChange?: (search: string) => void;
  error?: string;
  disabled?: boolean;
  placeholder?: string;
}

const SingleSelect: React.FC<SingleSelectProps> = ({
  allOptions = [],
  selectedOption,
  onChange,
  onSearchChange,
  label,
  required,
  error,
  disabled,
  placeholder
}) => {
  const [show, setShow] = useState(false);
  const [filterOptions, setFilterOptions] = useState<SingleOption[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const trigger = useRef<HTMLDivElement | null>(null);
  const errorTranslation = useTranslations(TRANSLATIONS.ERRORSMESSAGE);

  useEffect(() => {
    if (allOptions && allOptions?.length > 0) {
      setFilterOptions(allOptions);
    } else {
      setFilterOptions([]);
    }
  }, [allOptions]);

  const open = () => {
    if (disabled) return;
    setShow((prev) => !prev);
  };


  const select = (id: string) => {
    onChange(id);
    setShow(false);
  };


  useEffect(() => {
    const clickHandler = (event: MouseEvent) => {
      const target = event.target as Node;
      if (!dropdownRef.current || !trigger.current) return;
      if (!show || dropdownRef.current.contains(target) || trigger.current.contains(target)) return;
      setShow(false);
    };

    document.addEventListener("click", clickHandler);
    return () => document.removeEventListener("click", clickHandler);
  }, [show]);

  // Debounced search effect
  useEffect(() => {
    const timeout = setTimeout(() => {
      onSearchChange?.(searchTerm);
    }, 300); // debounce delay in ms

    return () => clearTimeout(timeout);
  }, [searchTerm, onSearchChange]);

  return (
    <div className={cn("relative", { "z-50": show })}>
      <label className="mb-3 block text-body-sm font-medium text-dark dark:text-white">
        {label}
        {required && <span className="ml-1 select-none text-red">*</span>}
      </label>
      <div className="flex flex-col items-center">
        <div className="relative z-20 inline-block w-full">
          <div className="relative flex flex-col items-center">
            <div ref={trigger} onClick={open} className="w-full">
              <div className="flex rounded-[7px] border-[1.5px] border-stroke py-[9px] pl-3 pr-3 outline-none transition focus:border-primary active:border-primary dark:border-dark-3 dark:bg-dark-2">
                <div className="flex flex-auto flex-wrap gap-3 items-center w-full">
                  <input
                    type="text"
                    placeholder={placeholder}
                    value={searchTerm}
                    onFocus={() => setShow(true)}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    disabled={disabled}
                    className="h-full w-full bg-transparent p-1 px-2 text-dark-5 outline-none dark:text-dark-6"
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
                <div className="flex items-center py-1 pl-1 pr-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      open();
                    }}
                    className={`text-dark-4 transition outline-none focus:outline-none dark:text-dark-6 ${show ? "rotate-180" : ""}`}
                  >
                    <ChevronUp />
                  </button>
                </div>
              </div>
            </div>
            {selectedOption && selectedOption?.id && (
              <div className="flex items-center justify-between w-full">
                <span className="text-body-sm font-medium dark:text-white">
                  Selected: {selectedOption?.title}
                </span>
              </div>
            )}
            <div className="w-full px-4">
              <div
                className={`absolute left-0 bottom-full z-40 w-full overflow-y-auto rounded bg-white shadow-1 dark:bg-dark-2 dark:shadow-card ${show ? "" : "hidden"
                  }`}
                ref={dropdownRef}
              >
                <div className="flex w-full flex-col max-h-[200px]">
                  {filterOptions.map((option, index) => (
                    <div
                      key={index}
                      className="cursor-pointer border border-stroke dark:border-dark-3 hover:bg-primary hover:text-white"
                      onClick={() => select(option.id)}
                    >
                      <div
                        className={`relative flex w-full items-center p-2 pl-2 ${selectedOption?.id === option.id ? "bg-primary text-white" : ""
                          }`}
                      >
                        <div className="mx-2 leading-6">{option.title}</div>
                      </div>
                    </div>
                  ))}
                  {filterOptions.length === 0 && (
                    <div className="p-2 text-sm text-dark-5 dark:text-dark-6">No options found</div>
                  )}
                </div>
              </div>
            </div>
          </div>
          {error && <span className="mt-2 text-sm text-red">{errorTranslation(error)}</span>}
        </div>
      </div>
    </div>
  );
};

export default SingleSelect;
