'use client';

import { useClickOutside } from '@/hooks/use-click-outside';
import React from 'react';

interface ConfirmationModalProps {
    isOpen: boolean;
    message: string;
    onConfirm: () => void;
    onCancel: () => void;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
    isOpen,
    message,
    onConfirm,
    onCancel,
}) => {

    const modalRef = useClickOutside<HTMLDivElement>(() => {
        onCancel();
    });

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm transition-opacity duration-300">
            <div ref={modalRef} className="w-full max-w-md rounded-2xl bg-white dark:bg-gray-900 p-6 shadow-xl transition-all duration-300 animate-fade-in-up">
                {/* Header */}
                <div className="mb-4">
                    <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
                        Are you sure?
                    </h2>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                        {message}
                    </p>
                </div>

                {/* Actions */}
                <div className="mt-6 flex justify-end gap-3">
                    <button
                        onClick={onCancel}
                        className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 dark:text-white dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={onConfirm}
                        className="px-4 py-2 rounded-lg bg-primary text-white transition"
                    >
                        Confirm
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationModal;
