"use client";
// experimental-nextjs-app-support
import { ApolloLink, HttpLink, Observable } from "@apollo/client";
import { onError } from "@apollo/client/link/error";
import {
  ApolloNextAppProvider,
  ApolloClient,
  InMemoryCache,
} from "@apollo/client-integration-nextjs";
import config from "@/config/config";
import Authorization from "./Authoriser";
import { useMemo, useCallback } from "react";
import { useLoading } from "@/context/LoadingContext";

// Custom hook to create an Apollo Link for handling authentication
const useAuthLink = () => {
  // const router = useRouter(); // Get the Next.js router instance
  const { addRequest, cancelRequest, removeRequest } = useLoading();

  return useMemo(() => {
    return new ApolloLink((operation, forward) => {
      const requestId = operation.operationName;
      if(requestId !== 'adminListUserByRoles') addRequest(requestId);

      const abortController = new AbortController();
      const { signal } = abortController;

      return new Observable((observer) => {
        (async () => {
          try {
            const authToken = await Authorization();
            if(authToken){
              operation.setContext({
                headers: {
                  Authorization: `Bearer ${authToken}`,
                },
                fetchOptions: {
                  signal,
                },
              });
            }

            const observable = forward(operation);

            observable.subscribe({
              next: observer.next.bind(observer),
              error: ()=>{
                observer.error.bind(observer);
                setTimeout(() => {
                  removeRequest(requestId);
                },400)
              },
              complete: () => {
                observer.complete();
                setTimeout(() => {
                  removeRequest(requestId);
                },400)
              },
            });
          } catch (error) {
            console.error(error);
            observer.complete();
            setTimeout(() => {
              removeRequest(requestId);
            },400)
          }
        })();

        return () => {
          abortController.abort();
          cancelRequest(requestId);
        };
      });
    });
  }, [addRequest, cancelRequest, removeRequest]);
};

// ApolloWrapper component to provide Apollo Client to the app
export function ApolloWrapper({ children }: React.PropsWithChildren) {
  const authLink = useAuthLink(); // Use the custom hook to get the auth link

  const makeClient = useCallback(() => {
    const httpLink = new HttpLink({
      uri: config.graphQlUrl,
    });

    const errorLink = onError(({ networkError }) => {
      if (networkError) {
        // Handle network errors
      }
    });

    return new ApolloClient({
      link: ApolloLink.from([authLink, errorLink, httpLink]),
      cache: new InMemoryCache(),
      defaultOptions: {
        query: {
          fetchPolicy: "no-cache",
          errorPolicy: "all",
        },
      },
    });
  }, [authLink]);

  return (
    <ApolloNextAppProvider makeClient={makeClient}>
      {children}
    </ApolloNextAppProvider>
  );
}
