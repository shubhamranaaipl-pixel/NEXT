import {
  CategoryModuleEnum,
  ListSortOrder,
  RoleFilterEnum,
  StatusEnum,
  UserSortBy,
  WorkoutModuleEnum,
} from "@/constants/enumConstants";

export interface MessageResponse {
  success: boolean;
  message: string;
}

export interface AdditionalImageModel {
  id?: number;
  image_id: number;
  sort_order: number;
}

export interface ImageModel {
  id: number;
  url: string;
  name: string;
}

export interface AdminFilterUserInput {
  role: RoleFilterEnum;
  status?: number;
}

export interface CommonFilterModel {
  skip: number;
  take: number;
  pagination: boolean;
  search?: string;
  sort_by?: UserSortBy;
  sort_order?: ListSortOrder;
  filter?: AdminFilterUserInput;
  type?: WorkoutModuleEnum;
  category_type?: CategoryModuleEnum;
  role?: number[];
  status?: StatusEnum
}

export interface Status {
  id: number;
  name: string;
}


export interface Category {
  id: number;
  title: string;
}

export interface Media {
  id: number;
  url: string;
  name: string;
  type?: string;
}

export interface Role {
  id: number;
  name: string;
}

export interface CommonListing {
  id: number;
  title: string;
  description: string;
  sort_order?: number;
  status?: Status;
}

export interface CategoryAdditionalImage {
  id: number;
  image: Media;
  sort_order: number;
  created_at: string | null;
}

// Interface defining pagination-related properties used in the table component
export interface PaginationModel {
  pageSize: number;           // Number of items to show per page
  pageIndex: number;          // Current page index (zero-based)
  totalCount: number | undefined; // Total number of items available (can be undefined initially)
}