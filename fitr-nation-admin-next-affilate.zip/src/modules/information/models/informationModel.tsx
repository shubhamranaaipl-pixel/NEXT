export interface InformationModel {
    id?: number;
    title: string;
    description: string;
    slug?: string;
    status: number;
    sort_order: number;
}

export interface InformationUpdateRequestModel {
    update_information_page_input: InformationModel
}

export interface InformationCreateRequestModel {
    create_information_page_input: InformationModel
}

export interface InformationCreateResponseModel {
    adminCreateInformationPage: InformationMessageModel;
}

export interface InformationGetRequestModel {
    get_information_page_input: {
        id?: number;
        slug?: string;
    };
}

export interface InformationUpdateResponseModel {
    adminUpdateInformationPage: InformationMessageModel;
}

export interface InformationMessageModel {
    success: boolean;
    message: string;
}

export interface AdminGetResponseModel {
    adminGetInformationPage: AdminGetInformationModel;
}

export interface AdminGetInformationModel {
    id: number;
    title: string;
    description: string;
    slug: string;
    status: StatusModel;
    sort_order: number;
}

export interface StatusModel {
    id: number;
    name: string;
}