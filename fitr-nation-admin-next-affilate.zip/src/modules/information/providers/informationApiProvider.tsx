import { ApolloService } from "@/graphql/ApolloService";
import { ApolloClient, OperationVariables, FetchResult, ApolloError } from "@apollo/client";
import { GraphQLError, GraphQLFormattedError } from "graphql";
import { adminCreateInformation, adminUpdateInformation } from "@/modules/information/mutations/informationMutations";
import { adminGetInformation } from "@/modules/information/queries/informationQueries";

export class informationApiProvider extends ApolloService {
    static apolloInstance: informationApiProvider = new informationApiProvider();

    adminCreateInformation(
        client: ApolloClient<object>,
        variables: OperationVariables | undefined,
        successCallBack: (_response: FetchResult<unknown>) => void,
        errorcallback: (
            _response:
                | (GraphQLError | GraphQLFormattedError | ApolloError)
                | undefined
        ) => void
    ): void {
        this.mutateApollo(
            client,
            adminCreateInformation,
            variables,
            async (success) => successCallBack(success),
            errorcallback
        );
    }


    adminUpdateInformation(
        client: ApolloClient<object>,
        variables: OperationVariables | undefined,
        successCallBack: (_response: FetchResult<unknown>) => void,
        errorcallback: (
            _response:
                | (GraphQLError | GraphQLFormattedError | ApolloError)
                | undefined
        ) => void
    ): void {
        this.mutateApollo(
            client,
            adminUpdateInformation,
            variables,
            async (success) => successCallBack(success),
            errorcallback
        );
    }


    adminGetInformation(
        client: ApolloClient<object>,
        variables: OperationVariables | undefined,
        successCallBack: (_response: FetchResult<unknown>) => void,
        errorcallback: (
            _response:
                | (GraphQLError | GraphQLFormattedError | ApolloError)
                | undefined
        ) => void
    ): void {
        this.queryApolloWithVariables(
            client,
            adminGetInformation,
            variables,
            async (success) => successCallBack(success),
            errorcallback
        );
    }

}
