interface IConfig{
    apiurl:string;
}

const config:IConfig={
    apiurl:process.env.NEXT_PUBLIC_API_DATA_BASEURL||"",

}
export default config;