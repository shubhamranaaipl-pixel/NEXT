import apiClient from "./apiClient";


export class AxiosService {
  get<T>(url: string, params?: any) {
    return apiClient.get<T>(url, { params });
  }
}
