import axios from "axios";
import config from "@/config/config";

const apiClient = axios.create({
  baseURL: config.apiurl,
});

apiClient.interceptors.request.use((config) => {
  return config;
});

apiClient.interceptors.response.use((response) => {
  return response;
});
export default apiClient;
