export const Post={
    GET_POST:"/posts"
}