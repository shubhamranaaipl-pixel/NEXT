import { AxiosService } from "@/lib/AxiosService";
import { Post } from "@/constant/endpoints";
import { Post as PostModel } from "@/models/post";

export class PostApiProvider extends AxiosService {
  static instance = new PostApiProvider();

  getPosts(success: (data: PostModel[]) => void, error: (err: Error) => void) {
    this.get<PostModel[]>(Post.GET_POST)
      .then((res) => success(res.data))
      .catch(error);
  }
}
