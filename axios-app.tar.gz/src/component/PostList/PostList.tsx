"use client";

import { useState,useEffect } from "react";
import { PostApiProvider } from "@/services/post/postApiProvider";
import {Post} from "@/models/post";

export default function PostList(){
    const [posts,setPosts]=useState<Post[]>([]);
     useEffect(()=>{
      PostApiProvider.instance.getPosts(
        (data)=>setPosts(data), 
        (err)=>console.error(err)
      )
     },[])
 return(
  <div>
    <h2>Posts</h2>
    {posts.map((post)=>(
        <div key={post.id}>
            <h4>{post.title}</h4>
            <p>{post.body}</p>
        </div>
    ))}
  </div>
 )
}