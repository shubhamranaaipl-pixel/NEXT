import PostList from "@/component/PostList/PostList";

export default function Home() {
  return (
    <>
     <h1>Axios Website</h1>
    <PostList/>
    </>
  );
}
