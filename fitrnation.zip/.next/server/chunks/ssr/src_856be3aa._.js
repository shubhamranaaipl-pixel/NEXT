module.exports = {

"[project]/src/modules/common/providers/ImageApiProvider.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ImageApiProvider": (()=>ImageApiProvider),
    "VideoApiProvider": (()=>VideoApiProvider),
    "WorkoutCSVApiProvider": (()=>WorkoutCSVApiProvider)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/config.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/serviceConstants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/graphql/Authoriser.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/eventBus.tsx [app-ssr] (ecmascript)");
;
;
;
;
const ImageApiProvider = async (file)=>{
    try {
        const formData = new FormData();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_SHOW"], {});
        formData.append('file', file);
        const authToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
        const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].apiUrl + "/image", {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        const result = await response.json();
        return result;
    } catch (error) {
        console.error(error);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        return null;
    }
};
const VideoApiProvider = async (file)=>{
    try {
        const formData = new FormData();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_SHOW"], {});
        formData.append('file', file);
        const authToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
        const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].apiUrl + "/video-upload/videoUpload", {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        const result = await response.json();
        return result;
    } catch (error) {
        console.error(error);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        return null;
    }
};
const WorkoutCSVApiProvider = async (file)=>{
    try {
        const formData = new FormData();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_SHOW"], {});
        formData.append('file', file);
        const authToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
        const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].apiUrl + "/upload/workout", {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        const result = await response.json();
        return result;
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        return error;
    }
};
}}),
"[project]/src/components/Input/Input.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "FileAcceptType": (()=>FileAcceptType),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/translationConstants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$modules$2f$common$2f$providers$2f$ImageApiProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/modules/common/providers/ImageApiProvider.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$class$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/class-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/toastUtils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
var FileAcceptType = /*#__PURE__*/ function(FileAcceptType) {
    FileAcceptType["IMAGE"] = "image/*";
    FileAcceptType["VIDEO"] = "video/*";
    FileAcceptType["IMAGE_AND_VIDEO"] = "image/*,video/*";
    FileAcceptType["CSV"] = ".xlsx, .csv, text/csv";
    return FileAcceptType;
}({});
const Input = ({ // id,
className, label, type, placeholder, required, disabled, active, handleChange, icon, error, onBlur, onUploadSuccess, accept, ...props })=>{
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useId"])();
    const errorTranslation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].ERRORSMESSAGE);
    const handleInputChange = async (e)=>{
        if (type === "file" && e.target.files?.[0]) {
            const file = e.target.files?.[0];
            if (file) {
                switch(accept){
                    case "image/*":
                        const image = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$modules$2f$common$2f$providers$2f$ImageApiProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ImageApiProvider"])(file);
                        if (image?.success) {
                            const obj = {
                                id: image?.id,
                                url: image?.url,
                                name: ""
                            };
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showSuccessToast"])(image?.message ?? '');
                            onUploadSuccess?.(obj);
                        } else {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showErrorToast"])(image?.message ?? '');
                        }
                        break;
                    case "video/*":
                        const video = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$modules$2f$common$2f$providers$2f$ImageApiProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["VideoApiProvider"])(file);
                        if (video?.success) {
                            const obj = {
                                id: video?.id,
                                url: video?.url,
                                name: ""
                            };
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showSuccessToast"])(video?.message ?? '');
                            onUploadSuccess?.(obj);
                        } else {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showErrorToast"])(video?.message ?? '');
                        }
                        break;
                }
            }
        }
        handleChange?.(e);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: "text-body-sm font-medium text-dark dark:text-white",
                children: [
                    label,
                    required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-1 select-none text-red",
                        children: "*"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Input/Input.tsx",
                        lineNumber: 114,
                        columnNumber: 22
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$class$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("relative mt-3 [&_svg]:absolute [&_svg]:right-4.5 [&_svg]:top-1/2 [&_svg]:-translate-y-1/2", {
                    "flex gap-2": icon
                }),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        // autoComplete="off"
                        id: id,
                        type: type,
                        name: props.name,
                        placeholder: placeholder,
                        onChange: handleInputChange,
                        onBlur: onBlur,
                        value: type !== "file" ? props.value ?? "" : undefined,
                        accept: type === "file" ? accept : undefined,
                        className: "w-full rounded-lg border-[1.5px] border-stroke bg-transparent outline-none transition focus:border-primary disabled:cursor-default disabled:bg-gray-2 data-[active=true]:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary dark:disabled:bg-dark dark:data-[active=true]:border-primary" + (type === "file" ? ` ${getFileStyles(props.fileStyleVariant || "style1")}` : " px-5.5 py-3 text-dark placeholder:text-dark-6 dark:text-white"),
                        required: props.mediaValue ? false : required,
                        disabled: disabled,
                        "data-active": active
                    }, void 0, false, {
                        fileName: "[project]/src/components/Input/Input.tsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, this),
                    icon
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            type === "file" && props.mediaValue && props.mediaValue?.url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 text-body-xs text-dark-5 dark:text-white",
                children: [
                    "Selected file: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        className: "text-primary",
                        href: props.mediaValue.url,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: props.mediaValue.name || 'View'
                    }, void 0, false, {
                        fileName: "[project]/src/components/Input/Input.tsx",
                        lineNumber: 150,
                        columnNumber: 26
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 149,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mt-2 text-sm text-red",
                children: errorTranslation(error)
            }, void 0, false, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 153,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Input/Input.tsx",
        lineNumber: 108,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Input;
function getFileStyles(variant) {
    switch(variant){
        case "style1":
            return `file:mr-5 file:border-collapse file:cursor-pointer file:border-0 file:border-r file:border-solid file:border-stroke file:bg-[#E2E8F0] file:px-6.5 file:py-[13px] file:text-body-sm file:font-medium file:text-dark-5 file:hover:bg-primary file:hover:bg-opacity-10 dark:file:border-dark-3 dark:file:bg-white/30 dark:file:text-white`;
        default:
            return `file:mr-4 file:rounded file:border-[0.5px] file:border-stroke file:bg-stroke file:px-2.5 file:py-1 file:text-body-xs file:font-medium file:text-dark-5 file:focus:border-primary dark:file:border-dark-3 dark:file:bg-white/30 dark:file:text-white px-3 py-[9px]`;
    }
}
}}),
"[project]/src/app/(auth)/_form-schema/Auth-form-schema.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "changePasswordSchema": (()=>changePasswordSchema),
    "forgotPasswordSchema": (()=>forgotPasswordSchema),
    "loginSchema": (()=>loginSchema),
    "otpSchema": (()=>otpSchema),
    "resetPasswordSchema": (()=>resetPasswordSchema)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/translationConstants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/lib/index.mjs [app-ssr] (ecmascript)");
;
;
const resetPasswordSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    // Validate password: required and at least 6 characters
    password: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].PASSWORDREQUIRED).min(6, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].PASSWORDMINLENGTH),
    // Validate confirm password: required and at least 6 characters
    confirm_password: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].CONFIRMPASSWORDREQUIRED).min(6, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].CONFIRMPASSWORDMINLENGTH)
})// Ensure password and confirm_password match
.refine((data)=>data.password === data.confirm_password, {
    path: [
        "confirm_password"
    ],
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].CONFIRMPASSWORDSDONOTMATCH
});
const forgotPasswordSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    // Validate email: required
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].EMAILREQUIRED).email(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].EMAILINVALID)
});
const loginSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].EMAILREQUIRED).email(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].VALIDEMAIL),
    password: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].PASSWORDREQUIRED)
});
const otpSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    // Validate all otp: required
    otp0: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].OTPREQUIRED).min(1),
    otp1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].OTPREQUIRED).min(1),
    otp2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].OTPREQUIRED).min(1),
    otp3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].OTPREQUIRED).min(1)
});
const changePasswordSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].object({
    // Validate old password: required and at least 6 characters
    old_password: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].OLDPASSWORDREQUIRED).min(6, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].OLDPASSWORDMINLENGTH),
    // Validate new password: required and at least 6 characters
    new_password: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].NEWPASSWORDREQUIRED).min(6, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].NEWPASSWORDMINLENGTH),
    // Validate confirm password: required and at least 6 characters
    confirm_password: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"].string().nonempty(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].CONFIRMPASSWORDREQUIRED).min(6, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].CONFIRMPASSWORDMINLENGTH)
})// Ensure new_password and confirm_password match
.refine((data)=>data.new_password === data.confirm_password, {
    path: [
        "confirm_password"
    ],
    message: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].CONFIRMPASSWORDSDONOTMATCH
});
}}),
"[project]/src/app/(auth)/useAuthState.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "useAuthState": (()=>useAuthState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/enumConstants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/routes.constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LoadingContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LoadingContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/encryption-decryption.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/toastUtils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useApolloClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useApolloClient.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_form$2d$schema$2f$Auth$2d$form$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(auth)/_form-schema/Auth-form-schema.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hookform/resolvers/zod/dist/zod.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_services$2f$Auth$2e$apiservice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(auth)/_services/Auth.apiservice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$appConstants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/appConstants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/uuid/dist/esm/v4.js [app-ssr] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/translationConstants.tsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useAuthState = ()=>{
    const inputRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]);
    const inputBoxes = [
        0,
        1,
        2,
        3
    ];
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useApolloClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useApolloClient"])();
    const route = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const { isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LoadingContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLoading"])();
    const commonTranslation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"].COMMON);
    // Change Password Form
    const { control: changePasswordControl, handleSubmit: handleChangePasswordSubmit, formState: { errors: changePasswordErrors } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])({
        resolver: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zodResolver"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_form$2d$schema$2f$Auth$2d$form$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["changePasswordSchema"]),
        mode: "all"
    });
    // Forgot Password Form
    const { control: forgotPasswordControl, handleSubmit: handleForgotPasswordSubmit, formState: { errors: forgotPasswordErrors } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])({
        resolver: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zodResolver"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_form$2d$schema$2f$Auth$2d$form$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forgotPasswordSchema"]),
        mode: "all"
    });
    // Login Form
    const { control: loginControl, handleSubmit: handleLoginSubmit, formState: { errors: loginErrors } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])({
        resolver: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zodResolver"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_form$2d$schema$2f$Auth$2d$form$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginSchema"]),
        mode: "all"
    });
    // Reset Password Form
    const { control: resetPasswordControl, handleSubmit: handleResetPasswordSubmit, formState: { errors: resetPasswordErrors } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])({
        resolver: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zodResolver"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_form$2d$schema$2f$Auth$2d$form$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resetPasswordSchema"]),
        mode: "all"
    });
    const { control: otpControl, handleSubmit: handleOtpSubmit, setValue: setOtpValue, formState: { errors: otpErrors }, setError: setOtpError, clearErrors: clearOtpErrors } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])({
        resolver: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hookform$2f$resolvers$2f$zod$2f$dist$2f$zod$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zodResolver"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_form$2d$schema$2f$Auth$2d$form$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["otpSchema"]),
        mode: "all"
    });
    const onResetPasswordSubmit = (data)=>{
        // Destructure password from submitted form data
        const { password } = data;
        // Retrieve the user's email from localStorage
        const email = localStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].EMAIL);
        if (!email) return; // Handle missing email
        // Prepare GraphQL variables with encrypted email and password
        const variables = {
            forget_password_input: {
                email: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(email),
                password: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(password)
            }
        };
        // Call the admin reset password mutation using Apollo client
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_services$2f$Auth$2e$apiservice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthApiProvider"].apolloInstance.adminResetPassword(client, variables, (success)=>{
            // Success callback
            // Show success toast message
            const response = success.data.forgetPassword;
            if (response?.success) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showSuccessToast"])(response?.message ?? '');
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showErrorToast"])(response?.message ?? '');
            }
            // Redirect user to the root route after successful password reset
            route.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ROUTES"].DASHBOARD);
            // Remove the stored email from localStorage
            localStorage.removeItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].EMAIL);
        }, ()=>{
        // Empty error callback — can be extended to handle errors
        });
    };
    const onLoginSubmit = (data)=>{
        let { email, password } = data;
        let deviceId = sessionStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].DEVICE_ID);
        if (!deviceId) {
            deviceId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
            sessionStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].DEVICE_ID, deviceId);
        }
        if (email) {
            email = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(email);
        }
        if (password) {
            password = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(password);
        }
        const variables = {
            admin_login_input: {
                email: email,
                password: password,
                device_id: deviceId,
                time_zone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                platform: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PlatformEnumModel"].WEB
            }
        };
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_services$2f$Auth$2e$apiservice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthApiProvider"].apolloInstance.adminLogin(client, variables, (success)=>{
            const response = success?.data?.adminLogin;
            localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].TOKEN_DATA, JSON.stringify({
                accessToken: response?.access_token,
                refreshToken: response?.refresh_token
            }));
            localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].ROLE, JSON.stringify(response?.role[0]?.name));
            localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].USER_INFO, JSON.stringify(response));
            route.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ROUTES"].DASHBOARD);
        }, ()=>{});
    };
    const onForgotPasswordSubmit = (data)=>{
        // Destructure email from submitted form data
        const { email } = data;
        localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].EMAIL, email);
        const variables = {
            // Encrypt email before sending it to the API
            admin_send_otp_input: {
                email: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(email)
            }
        };
        // Call the adminSendOtp mutation using the Apollo client
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_services$2f$Auth$2e$apiservice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthApiProvider"].apolloInstance.adminSendOtp(client, variables, async (success)=>{
            const response = success.data.adminSendOtp;
            if (response?.success) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showSuccessToast"])(response?.message ?? '');
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showErrorToast"])(response?.message ?? '');
            }
            route.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ROUTES"].VERIFY_OTP); // Navigate to verify otp route
        }, ()=>{} // Handle error callback (currently empty)
        );
    };
    const onChangePasswordSubmit = (data)=>{
        // Destructure old and new passwords from submitted form data
        const { old_password, new_password } = data;
        // Encrypt passwords before sending them to the API
        const variables = {
            change_password_input: {
                old_password: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(old_password),
                new_password: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(new_password)
            }
        };
        // Call the changePassword mutation using the Apollo client
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_services$2f$Auth$2e$apiservice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthApiProvider"].apolloInstance.changePassword(client, variables, (success)=>{
            // On success, show toast message and redirect user
            const response = success.data.changePassword;
            if (response?.success) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showSuccessToast"])(response?.message ?? '');
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showErrorToast"])(response?.message ?? '');
            }
            route.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ROUTES"].DASHBOARD);
        }, ()=>{} // Handle error callback (currently empty)
        );
    };
    const onVerifyOtpSubmit = (data)=>{
        // Join individual OTP digits into a single string
        const otp = Object.values(data).join("");
        const email = localStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalStorageKeysEnum"].EMAIL);
        if (!email) {
            return; // or handle error accordingly
        }
        // Prepare variables to send in the API call, with encrypted email and numeric OTP
        const variable = {
            verify_otp_input: {
                email: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2d$decryption$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["processEncryption"])(email),
                code: Number(otp)
            }
        };
        // Call the Apollo API to verify the OTP
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_services$2f$Auth$2e$apiservice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthApiProvider"].apolloInstance.verifyOtp(client, variable, async (success)=>{
            // Show success toast on valid OTP
            const response = (success?.data).verifyOtp;
            if (response?.success) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showSuccessToast"])(response?.message ?? '');
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showErrorToast"])(response?.message ?? '');
            }
            // Redirect to reset password page
            route.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ROUTES"].RESET_PASSWORD);
        }, ()=>{
        // Optional: handle failure (currently empty)
        });
    };
    const handleNavigation = (url)=>{
        route.push(url);
    };
    const handleInput = (e, index)=>{
        const value = e.target.value;
        // Check if the input value is a valid integer (only digits)
        if (value) {
            if (value && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$appConstants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INTEGER_REGEX"].test(value)) {
                //  Clear any existing validation error for this OTP input
                clearOtpErrors(`otp${index}`);
            } else {
                //  Set a manual validation error if the value is not a digit
                setOtpError(`otp${index}`, {
                    type: "manual",
                    message: "Only digits allowed"
                });
            }
        }
        // If input is a valid digit (0–9), update the value and move focus to the next box
        if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$appConstants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INTEGER_REGEX"].test(value)) {
            setOtpValue(`otp${index}`, value);
            // Move focus to the next input box, if it exists
            if (inputRefs.current[index + 1]) {
                inputRefs.current[index + 1]?.focus();
            }
        } else if (value === "") {
            setOtpValue(`otp${index}`, "");
        }
    };
    const focusAndMoveCaretToEnd = (input)=>{
        if (input) {
            input.focus();
            const length = input.value.length;
            input.setSelectionRange(length, length); // move caret to the end
        }
    };
    const handleKeyDown = (e, index)=>{
        // Handle Backspace: if current input is empty, move focus to previous box
        if (e.key === "Backspace") {
            const currentValue = e.currentTarget.value;
            if (!currentValue && index > 0) {
                setTimeout(()=>{
                    focusAndMoveCaretToEnd(inputRefs.current[index - 1]);
                }, 0);
            }
        }
        // Navigate left with ArrowLeft
        if (e.key === "ArrowLeft" && index > 0) {
            setTimeout(()=>{
                focusAndMoveCaretToEnd(inputRefs.current[index - 1]);
            }, 0);
        }
        // Navigate right with ArrowRight
        if (e.key === "ArrowRight" && index < inputRefs.current.length - 1) {
            setTimeout(()=>{
                focusAndMoveCaretToEnd(inputRefs.current[index + 1]);
            }, 0);
        }
    };
    return {
        client,
        route,
        isLoading,
        onResetPasswordSubmit,
        onLoginSubmit,
        onForgotPasswordSubmit,
        onChangePasswordSubmit,
        changePasswordControl,
        handleChangePasswordSubmit,
        changePasswordErrors,
        resetPasswordControl,
        handleResetPasswordSubmit,
        resetPasswordErrors,
        forgotPasswordControl,
        handleForgotPasswordSubmit,
        forgotPasswordErrors,
        loginControl,
        handleLoginSubmit,
        loginErrors,
        handleNavigation,
        onVerifyOtpSubmit,
        otpControl,
        handleOtpSubmit,
        setOtpValue,
        otpErrors,
        setOtpError,
        clearOtpErrors,
        handleInput,
        focusAndMoveCaretToEnd,
        handleKeyDown,
        inputRefs,
        inputBoxes,
        commonTranslation,
        TRANSLATIONS: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRANSLATIONS"]
    };
};
}}),
"[project]/src/app/(auth)/_components/Button-form.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const ButtonForm = ({ isLoading, buttonText })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-4.5",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            disabled: isLoading,
            type: "submit",
            className: `flex w-full items-center justify-center gap-2 rounded-lg p-4 font-medium text-white transition hover:bg-opacity-90 ${isLoading ? "bg-secondary" : "bg-primary"}`,
            children: buttonText
        }, void 0, false, {
            fileName: "[project]/src/app/(auth)/_components/Button-form.tsx",
            lineNumber: 11,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/(auth)/_components/Button-form.tsx",
        lineNumber: 10,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = ButtonForm;
}}),
"[project]/src/app/(auth)/_components/Login-form.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Input$2f$Input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Input/Input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$useAuthState$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(auth)/useAuthState.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_components$2f$Button$2d$form$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(auth)/_components/Button-form.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const LoginForm = ()=>{
    const { isLoading, onLoginSubmit, loginControl, handleLoginSubmit, loginErrors, handleNavigation, commonTranslation, TRANSLATIONS } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$useAuthState$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuthState"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleLoginSubmit(onLoginSubmit),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Controller"], {
                name: "email",
                control: loginControl,
                defaultValue: "",
                render: ({ field })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Input$2f$Input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        ...field,
                        type: "input",
                        handleChange: field.onChange,
                        onBlur: field.onBlur,
                        label: commonTranslation(TRANSLATIONS.EMAIL),
                        className: "mb-4 [&_input]:py-[15px]",
                        placeholder: commonTranslation(TRANSLATIONS.ENTERYOUREMAILADDRESS),
                        error: loginErrors.email ? loginErrors.email.message : ''
                    }, void 0, false, {
                        fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                        lineNumber: 26,
                        columnNumber: 11
                    }, void 0)
            }, void 0, false, {
                fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Controller"], {
                name: "password",
                control: loginControl,
                defaultValue: "",
                render: ({ field })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Input$2f$Input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        ...field,
                        type: "password",
                        label: commonTranslation(TRANSLATIONS.PASSWORD),
                        handleChange: field.onChange,
                        onBlur: field.onBlur,
                        className: "mb-5 [&_input]:py-[15px]",
                        placeholder: commonTranslation(TRANSLATIONS.ENTERYOURPASSWORD),
                        error: loginErrors.password ? loginErrors.password.message : ''
                    }, void 0, false, {
                        fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                        lineNumber: 43,
                        columnNumber: 11
                    }, void 0)
            }, void 0, false, {
                fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 flex justify-end gap-2 py-2 font-medium",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    onClick: ()=>handleNavigation("/forgot-password"),
                    className: "hover:text-primary dark:text-white dark:hover:text-primary cursor-pointer",
                    children: [
                        commonTranslation(TRANSLATIONS.FORGETPASSWORD),
                        "?"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$auth$292f$_components$2f$Button$2d$form$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                buttonText: commonTranslation(TRANSLATIONS.SIGNIN),
                isLoading: isLoading
            }, void 0, false, {
                fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(auth)/_components/Login-form.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = LoginForm;
}}),

};

//# sourceMappingURL=src_856be3aa._.js.map