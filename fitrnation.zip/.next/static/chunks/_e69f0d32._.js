(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c20f642f._.js",
  "static/chunks/node_modules_next_dist_compiled_2ce9398a._.js",
  "static/chunks/node_modules_next_dist_client_8f19e6fb._.js",
  "static/chunks/node_modules_next_dist_2ecbf5fa._.js",
  "static/chunks/ed0b0_@swc_helpers_cjs_d9e50ee1._.js"
],
    source: "entry"
});
