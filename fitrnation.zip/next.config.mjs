import createNextIntlPlugin from 'next-intl/plugin';
import { config } from 'dotenv';
import path from 'path';

// Load environment variables from `.env` files
const envFilePath = path.resolve(process.cwd(), `.env.${process.env.APP_ENV || 'development'}`);
config({ path: envFilePath });

const withNextIntl = createNextIntlPlugin();

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false,
  env: {
    GRAPHQL_URL: process.env.NEXT_PUBLIC_GRAPHQL_URL,
  },
  experimental: {},
  images: {
    remotePatterns: []
  },
};

export default withNextIntl(nextConfig);