export const apiEndpoints = {
    login: '/auth/login',
    register: '/auth/register',
    page:"page="
}