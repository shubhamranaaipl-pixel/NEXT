'use client';

import { TRANSLATIONS } from "@/constants/translationConstants";
import { useTranslations } from "next-intl";

export default function ErrorPage() {
  const commonTranslations=useTranslations(TRANSLATIONS.COMMON);

  return <p>{commonTranslations(TRANSLATIONS.SOMETHINGWENTWRONG)}</p>;
}