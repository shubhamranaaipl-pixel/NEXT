"use cliennt";

import { useState, useEffect } from "react";
import config from "@/config/config";
import { apiEndpoints } from "@/constants/api-endpoints.constants";


export interface IUser {
  name: string;
  height: number;
  gender: string;
  birth_year: string;
}

export const useUser = () => {
  const [userData, setUserData] = useState<IUser[]>([]);

   
  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch(`${config.userApi}${apiEndpoints.page}1`);
      const data = await response.json();
      setUserData(data.results.map((user:IUser)=>({
        name:user.name,
        height:user.height,
        gender:user.gender,
        birth_year:user.birth_year,
      })));
    };
    fetchData();
  }, []);
 



  return {userData };
};
