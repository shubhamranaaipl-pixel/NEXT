"use client";
import DynamicTable from "@/components/Table/Table";
import { useUser } from "./useUser";
export default function UserPage() {
  const {userData } = useUser();

  return (
    <>
      <DynamicTable
        data={userData}
        paginationOptions={{ pageIndex: 0, pageSize: 10, totalCount: 2 }}
        onPageChange={() => {}}
        searchValue=""
        onGlobalFilterChange={() => {}}
        onPageSizeChange={() => {}}
        handleKeyDown={() => {}}
        onActionEvent={() => {}}
        onNavigation={() => {}}
        onPagination={() => {}}
      />
    </>
  );
}
