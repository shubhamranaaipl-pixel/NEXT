export default function AuthLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <section className="text-gray-600 body-font">
            <div className="container px-5 py-24 mx-auto">
                <div className="rounded-[10px] bg-white shadow-1 dark:bg-gray-dark dark:shadow-card">
                    <div className="flex flex-wrap items-center">
                        <div className="w-full xl:w-[50%] xl:mx-auto">
                            <div className="w-full p-4 sm:p-12.5 xl:p-15">
                                {children}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};
