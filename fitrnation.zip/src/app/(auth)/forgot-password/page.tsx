import ForgotPasswordFormPage from "@/app/(auth)/_components/Forgot-password-form";
import Image from "next/image";
import { Fragment } from "react";
import mainLogo from "@/assets/logos/logo.png";

const ForgotPasswordPage = () => {
  return <Fragment>
  <div className="flex items-center justify-center mb-10">
    <Image src={mainLogo} alt="logo" priority unoptimized />
  </div>
  <ForgotPasswordFormPage />
  </Fragment>
};

export default ForgotPasswordPage;
