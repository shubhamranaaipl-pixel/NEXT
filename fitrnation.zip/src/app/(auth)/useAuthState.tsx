import { LocalStorageKeysEnum, PlatformEnumModel } from "@/constants/enumConstants";
import { ROUTES } from "@/constants/routes.constants";
import { useLoading } from "@/context/LoadingContext";
import { processEncryption } from "@/utils/encryption-decryption";
import { showErrorToast, showSuccessToast } from "@/utils/toastUtils";
import { useApolloClient } from "@apollo/client";
import { useRouter } from "next/navigation";
import { changePasswordFormInputs, changePasswordSchema, forgotPasswordFormInputs, forgotPasswordSchema, LoginFormInputs, loginSchema, otpFormInputs, otpSchema, resetPasswordFormInputs, resetPasswordSchema } from "@/app/(auth)/_form-schema/Auth-form-schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AuthApiProvider } from "@/app/(auth)/_services/Auth.apiservice";
import { AdminForgetPasswordResponseModel, AdminLoginModel, AdminSendOtpResponseModel, AdminChangePasswordResponseModel, verifyOtpResponseModelEntity } from "@/app/(auth)/_types/Auth.types";
import { useRef } from "react";
import { INTEGER_REGEX } from "@/constants/appConstants";
import { v4 as uuidv4 } from 'uuid';
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";

export const useAuthState = () => {
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const inputBoxes = [0, 1, 2, 3];
  const client = useApolloClient();
  const route = useRouter();
  const { isLoading } = useLoading();
  const commonTranslation=useTranslations(TRANSLATIONS.COMMON);

  // Change Password Form
  const {
    control: changePasswordControl,
    handleSubmit: handleChangePasswordSubmit,
    formState: { errors: changePasswordErrors },
  } = useForm<changePasswordFormInputs>({
    resolver: zodResolver(changePasswordSchema),
    mode: "all",
  });

  // Forgot Password Form
  const {
    control: forgotPasswordControl,
    handleSubmit: handleForgotPasswordSubmit,
    formState: { errors: forgotPasswordErrors },
  } = useForm<forgotPasswordFormInputs>({
    resolver: zodResolver(forgotPasswordSchema),
    mode: "all",
  });
  // Login Form
  const {
    control: loginControl,
    handleSubmit: handleLoginSubmit,
    formState: { errors: loginErrors },
  } = useForm<LoginFormInputs>({
    resolver: zodResolver(loginSchema),
    mode: "all",
  });

  // Reset Password Form
  const {
    control: resetPasswordControl,
    handleSubmit: handleResetPasswordSubmit,
    formState: { errors: resetPasswordErrors },
  } = useForm<resetPasswordFormInputs>({
    resolver: zodResolver(resetPasswordSchema),
    mode: "all",
  });

  const {
    control: otpControl, // Controls the OTP form inputs
    handleSubmit: handleOtpSubmit, // Handles OTP form submission
    setValue: setOtpValue,
    formState: { errors: otpErrors }, // Contains OTP form validation errors
    setError: setOtpError,
    clearErrors: clearOtpErrors,
  } = useForm<otpFormInputs>({
    resolver: zodResolver(otpSchema),
    mode: "all",
  });

  const onResetPasswordSubmit = (data: resetPasswordFormInputs): void => {
    // Destructure password from submitted form data
    const { password } = data;

    // Retrieve the user's email from localStorage
    const email = localStorage.getItem(LocalStorageKeysEnum.EMAIL);

    if (!email) return; // Handle missing email

    // Prepare GraphQL variables with encrypted email and password
    const variables = {
      forget_password_input: {
        email: processEncryption(email), // Encrypt email
        password: processEncryption(password), // Encrypt new password
      },
    };

    // Call the admin reset password mutation using Apollo client
    AuthApiProvider.apolloInstance.adminResetPassword(
      client, // Apollo client instance
      variables, // Mutation variables
      (success) => {
        // Success callback
        // Show success toast message
        const response = (success.data as AdminForgetPasswordResponseModel).forgetPassword;
        if (response?.success) {
          showSuccessToast(response?.message ?? '');
        } else {
          showErrorToast(response?.message ?? '');
        }
        // Redirect user to the root route after successful password reset
        route.replace(ROUTES.DASHBOARD);
        // Remove the stored email from localStorage
        localStorage.removeItem(LocalStorageKeysEnum.EMAIL);
      },
      () => {
        // Empty error callback — can be extended to handle errors
      }
    );
  };

  const onLoginSubmit = (data: LoginFormInputs): void => {
    let { email, password } = data;
    let deviceId = sessionStorage.getItem(LocalStorageKeysEnum.DEVICE_ID);
    if (!deviceId) {
      deviceId = uuidv4();
      sessionStorage.setItem(LocalStorageKeysEnum.DEVICE_ID, deviceId);
    }
    if (email) {
      email = processEncryption(email)
    }
    if (password) {
      password = processEncryption(password)  
    }
    const variables = {
      admin_login_input: {
        email: email,
        password: password,
        device_id: deviceId,
        time_zone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        platform: PlatformEnumModel.WEB
      },
    };
    AuthApiProvider.apolloInstance.adminLogin(
      client,
      variables,
      (success) => {
        const response = (success?.data as AdminLoginModel)?.adminLogin;
        localStorage.setItem(LocalStorageKeysEnum.TOKEN_DATA, JSON.stringify({
          accessToken: response?.access_token,
          refreshToken: response?.refresh_token,
        }));
        localStorage.setItem(LocalStorageKeysEnum.ROLE, JSON.stringify(response?.role[0]?.name));
        localStorage.setItem(LocalStorageKeysEnum.USER_INFO, JSON.stringify(response));
        route.replace(ROUTES.DASHBOARD);
      },
      () => { }
    );
  };


  const onForgotPasswordSubmit = (data: forgotPasswordFormInputs): void => {
    // Destructure email from submitted form data
    const { email } = data;
    localStorage.setItem(LocalStorageKeysEnum.EMAIL, email);
    const variables = {
      // Encrypt email before sending it to the API
      admin_send_otp_input: {
        email: processEncryption(email),
      },
    };
    // Call the adminSendOtp mutation using the Apollo client
    AuthApiProvider.apolloInstance.adminSendOtp(
      client, // Apollo client instance
      variables, // Encrypted input variables
      async (success) => {
        const response = (success.data as AdminSendOtpResponseModel).adminSendOtp;
        if (response?.success) {
          showSuccessToast(response?.message ?? '');
        } else {
          showErrorToast(response?.message ?? '')
        }
        route.replace(ROUTES.VERIFY_OTP); // Navigate to verify otp route
      },
      () => { } // Handle error callback (currently empty)
    );
  };

  const onChangePasswordSubmit = (data: changePasswordFormInputs): void => {
    // Destructure old and new passwords from submitted form data
    const { old_password, new_password } = data;
    // Encrypt passwords before sending them to the API
    const variables = {
      change_password_input: {
        old_password: processEncryption(old_password),
        new_password: processEncryption(new_password),
      },
    };
    // Call the changePassword mutation using the Apollo client
    AuthApiProvider.apolloInstance.changePassword(
      client, // Apollo client instance
      variables, // Encrypted input variables
      (success) => {
        // On success, show toast message and redirect user
        const response = (success.data as AdminChangePasswordResponseModel).changePassword;
        if (response?.success) {
          showSuccessToast(response?.message ?? '');
        } else {
          showErrorToast(response?.message ?? '')
        }
        route.replace(ROUTES.DASHBOARD);
      },
      () => { } // Handle error callback (currently empty)
    );
  };


  const onVerifyOtpSubmit = (data: otpFormInputs) => {
    // Join individual OTP digits into a single string
    const otp = Object.values(data).join("");

    const email = localStorage.getItem(LocalStorageKeysEnum.EMAIL);

    if (!email) {
      return; // or handle error accordingly
    }
    // Prepare variables to send in the API call, with encrypted email and numeric OTP
    const variable = {
      verify_otp_input: {
        email: processEncryption(email), // Encrypt the email before sending
        code: Number(otp), // Convert OTP to number
      },
    };

    // Call the Apollo API to verify the OTP
    AuthApiProvider.apolloInstance.verifyOtp(
      client,
      variable,
      async (success) => {
        // Show success toast on valid OTP
        const response = (success?.data as verifyOtpResponseModelEntity).verifyOtp;
        if (response?.success) {
          showSuccessToast(response?.message ?? '');
        } else {
          showErrorToast(response?.message ?? '')
        }
        // Redirect to reset password page
        route.replace(ROUTES.RESET_PASSWORD);
      },
      () => {
        // Optional: handle failure (currently empty)
      }
    );
  };

  const handleNavigation = (url: string): void => {
    route.push(url);
  }


  const handleInput = (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number
  ) => {
    const value = e.target.value;

    // Check if the input value is a valid integer (only digits)
    if (value) {
      if (value && INTEGER_REGEX.test(value)) {
        //  Clear any existing validation error for this OTP input
        clearOtpErrors(`otp${index}` as keyof otpFormInputs);
      } else {
        //  Set a manual validation error if the value is not a digit
        setOtpError(`otp${index}` as keyof otpFormInputs, {
          type: "manual",
          message: "Only digits allowed",
        });
      }
    }

    // If input is a valid digit (0–9), update the value and move focus to the next box
    if (INTEGER_REGEX.test(value)) {
      setOtpValue(`otp${index}` as keyof otpFormInputs, value);

      // Move focus to the next input box, if it exists
      if (inputRefs.current[index + 1]) {
        inputRefs.current[index + 1]?.focus();
      }
    }
    // If input is empty (e.g., cleared with Backspace), clear the value
    else if (value === "") {
      setOtpValue(`otp${index}` as keyof otpFormInputs, "");
    }
  };

  const focusAndMoveCaretToEnd = (input: HTMLInputElement | null) => {
    if (input) {
      input.focus();
      const length = input.value.length;
      input.setSelectionRange(length, length); // move caret to the end
    }
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    index: number
  ) => {
    // Handle Backspace: if current input is empty, move focus to previous box
    if (e.key === "Backspace") {
      const currentValue = e.currentTarget.value;
      if (!currentValue && index > 0) {
        setTimeout(() => {
          focusAndMoveCaretToEnd(inputRefs.current[index - 1]);
        }, 0);
      }
    }

    // Navigate left with ArrowLeft
    if (e.key === "ArrowLeft" && index > 0) {
      setTimeout(() => {
        focusAndMoveCaretToEnd(inputRefs.current[index - 1]);
      }, 0);
    }

    // Navigate right with ArrowRight
    if (e.key === "ArrowRight" && index < inputRefs.current.length - 1) {
      setTimeout(() => {
        focusAndMoveCaretToEnd(inputRefs.current[index + 1]);
      }, 0);
    }
  };

  return {
    client,
    route,
    isLoading,
    onResetPasswordSubmit,
    onLoginSubmit,
    onForgotPasswordSubmit,
    onChangePasswordSubmit,
    changePasswordControl,
    handleChangePasswordSubmit,
    changePasswordErrors,
    resetPasswordControl,
    handleResetPasswordSubmit,
    resetPasswordErrors,
    forgotPasswordControl,
    handleForgotPasswordSubmit,
    forgotPasswordErrors,
    loginControl,
    handleLoginSubmit,
    loginErrors,
    handleNavigation,
    onVerifyOtpSubmit,
    otpControl,
    handleOtpSubmit,
    setOtpValue,
    otpErrors,
    setOtpError,
    clearOtpErrors,
    handleInput,
    focusAndMoveCaretToEnd,
    handleKeyDown,
    inputRefs,
    inputBoxes,
    commonTranslation,
    TRANSLATIONS
  };
}