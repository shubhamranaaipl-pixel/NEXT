"use client";

import type { ApexOptions } from "apexcharts";
import dynamic from "next/dynamic";

type PropsType = {
  data: {
    received: { x: string | number; y: number }[];
    due: { x: string | number; y: number }[];
  };
};

const Chart = dynamic(() => import("react-apexcharts"), {
  ssr: false,
});

export function WeeklySignupsChart({ data }: PropsType) {

  const normalizedData = {
    received: data.received.map((d) => ({
      x: String(d.x),
      y: Number(d.y),
    })),
    due: data.due.map((d) => ({
      x: String(d.x),
      y: Number(d.y),
    })),
  };

  const options: ApexOptions = {
    colors: ["#5750F1", "#0ABEF9"],
    chart: {
      type: "bar",
      stacked: true,
      toolbar: {
        show: false,
      },
      zoom: {
        enabled: false,
      },
    },
    responsive: [
      {
        breakpoint: 1536,
        options: {
          plotOptions: {
            bar: {
              borderRadius: 3,
              columnWidth: "25%",
            },
          },
        },
      },
    ],
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 3,
        columnWidth: "25%",
        borderRadiusApplication: "end",
        borderRadiusWhenStacked: "last",
      },
    },
    dataLabels: { enabled: false },
    grid: {
      strokeDashArray: 5,
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } },
    },
    xaxis: {
      type: "category", 
      categories: normalizedData.received.map((d) => d.x),
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    legend: {
      show: false,
      position: "top",
      horizontalAlign: "left",
      fontFamily: "inherit",
      fontWeight: 500,
      fontSize: "14px",
      markers: { strokeWidth: 10, size: 16 },
    },
    fill: { opacity: 1 },
  };

  return (
    <div className="-ml-3.5 mt-3">
      <Chart
        options={options}
        series={[
          { name: "Received", data: normalizedData.received },
          { name: "Due", data: normalizedData.due },
        ]}
        type="bar"
        height={370}
      />
    </div>
  );
}
