"use client";
import { getWeeklySignupsData } from "@/chart-service";
import { WeeklySignupsChart } from "./chart";
import { cn } from "@/utils/class-utils";
import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";
import { PeriodPicker } from "@/components/period-picker";


type PropsType = {
  timeFrame?: string;
  className?: string;
  initialData?: Awaited<ReturnType<typeof getWeeklySignupsData>>;

};

export  function WeeklySignups({className, timeFrame="monthly",initialData }: PropsType) {
   const [timeFrameState,setTimeFrameState]=useState<string>(timeFrame);
  const [data, setData] = useState(initialData);
  const dashboardTranslation=useTranslations(TRANSLATIONS.DASHBOARD);
  
  useEffect(() => {
    const getData = async () => {  // Calling this method, if data is changed
      const fetchedData = await getWeeklySignupsData(timeFrameState);
      setData(fetchedData);
    };
    getData();
  }, [timeFrameState]);

  if (!data) return null;

  return (
    <div
      className={cn(
        "rounded-[10px] bg-white px-7.5 pt-7.5 shadow-1 dark:bg-gray-dark dark:shadow-card",
        className,
      )}
    >
        
      <div className="flex flex-wrap items-center justify-between gap-4">
    
        <h2 className="text-body-2xlg font-bold text-dark dark:text-white">
          {dashboardTranslation(TRANSLATIONS.WEEKLYSIGNUPS)} 
        </h2>
             <PeriodPicker
          value={timeFrameState}
          defaultValue={timeFrame}
          sectionKey="weeks_profit"
          onChange={(value)=>setTimeFrameState(value)}
       
        />
       
      </div>

      <WeeklySignupsChart data={data} />
    </div>
  );
}
