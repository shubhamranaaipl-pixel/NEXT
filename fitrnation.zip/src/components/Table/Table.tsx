"use client";
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import React, { ChangeEvent, useCallback, useEffect, useState } from "react";
import ColumnFilter from "@/components/Table/ColumnFilter";
import { chevronleft, chevronright, search } from "@/assets/icons";
import { RowActions } from "@/components/Table/row.actions";
import { Action } from "@/constants/enumConstants";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";
import { FileAcceptType } from "@/components/Input/Input";
import { PaginationModel } from "@/modules/common/models/commonModels";
function toHeaderFormat(key: string): string {
  return key
    .replace(/([A-Z])/g, " $1")
    .replace(/_/g, " ")
    .replace(/^./, (str) => str.toUpperCase())
    .trim();
}
// Generate columns dynamically from any data array passed in

function generateColumns<T extends Record<string, any>>(
  data: T[]
): ColumnDef<T>[] {
  if (!data || data.length === 0) {
    return [];
  }
  return Object.keys(data[0]).map((key) => ({
    id: key,
    header: toHeaderFormat(key),
    accessorKey: key,
  }));
}

export const DynamicTable = <T extends Record<string, any>>({
  data,
  showActions,
  paginationOptions,
  onPageChange,
  searchValue,
  onGlobalFilterChange,
  handleKeyDown,
  onPageSizeChange,
  onActionEvent,
  onNavigation,
  onPagination,
  onFileUpload,
  isImport,
}: {
  data: T[];
  showActions?: boolean;
  paginationOptions: PaginationModel;
  onPageChange: (index: number, pageSize: number) => void;
  searchValue: string;
  onGlobalFilterChange: (value: string) => void;
  onPageSizeChange: (pageSize: number) => void;
  handleKeyDown: (
    event:
      | React.KeyboardEvent<HTMLInputElement>
      | React.MouseEvent<HTMLButtonElement>
  ) => void;
  onActionEvent: (action: Action, id: number) => void;
  onNavigation: () => void;
  onPagination: (pagination: boolean) => void;
  onFileUpload?: (e: ChangeEvent<HTMLInputElement>) => void;
  isImport?: boolean;
}) => {
  // const [globalFilter, setGlobalFilter] = useState("");
  // const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const columns = generateColumns(data);

  const table = useReactTable({
    data: data,
    columns:
      showActions && data && data.length > 0
        ? [
            ...columns,
            {
              id: "action",
              header: "Action",
            },
          ]
        : columns,
    // manualPagination: true,
    // onGlobalFilterChange: setGlobalFilter,
    // onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    // Custom filter UI for each column
    meta: {
      filterComponent: (props: any) => <ColumnFilter column={props.column} />,
    },
  });
  const totalPages = Math.ceil(
    (paginationOptions.totalCount ?? 0) / paginationOptions.pageSize
  );
  const [pagination, setPagination] = useState<(string | number)[]>([]);

  const handlePagination = useCallback(() => {
    const totalCount = totalPages;
    const pageLimit = 5;
    const currentPage = paginationOptions.pageIndex + 1;
    const pages = [];
    const startPage = Math.max(currentPage - Math.floor(pageLimit / 2), 1);
    const endPage = Math.min(
      currentPage + Math.floor(pageLimit / 2),
      totalCount
    );

    if (startPage > 1) {
      pages.push(1);
      if (startPage > 2) pages.push("...");
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    if (endPage < totalCount - 1) {
      pages.push("...");
    }

    if (endPage < totalCount) {
      pages.push(totalCount);
    }

    setPagination(pages);
  }, [paginationOptions?.pageIndex, totalPages]);

  useEffect(() => {
    handlePagination();
  }, [handlePagination]);

  const commonTranslations = useTranslations(TRANSLATIONS.COMMON);

  return (
    <section className="data-table-common rounded-[10px] bg-white shadow-1 dark:bg-gray-dark dark:shadow-card">
      <div className="flex justify-between px-7.5 py-4.5">
        <div className="relative z-20 w-full max-w-[414px]">
          <input
            name="search"
            type="text"
            value={searchValue}
            onChange={(e) => onGlobalFilterChange(e.target.value)}
            onKeyDown={(e) => handleKeyDown(e)}
            className="w-full rounded-lg border border-stroke bg-transparent px-5 py-2.5 outline-none focus:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary"
            placeholder="Search here..."
          />

          <button
            type="button"
            onClick={handleKeyDown}
            disabled={searchValue.trim() === ""}
            className={`absolute right-0 top-0 flex h-11.5 w-11.5 items-center justify-center rounded-r-md text-white 
            ${
              searchValue.trim() === ""
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-primary"
            }`}
          >
            <Image
              src={search}
              alt="search"
              height={20}
              width={20}
              priority
              unoptimized
              className="invert dark:invert-0"
            />
          </button>
        </div>
        <div className="flex gap-[10px] items-center">
          {table && table.getRowModel().rows.length > 0 && (
            <div className="flex items-center font-medium">
              <p className="pl-2 font-medium text-dark dark:text-current">
                {commonTranslations(TRANSLATIONS.PERPAGE)}
              </p>
              <select
                name="page-filter"
                id="page-filter"
                value={table.getState().pagination.pageSize}
                onChange={(e) => {
                  const newSize = Number(e.target.value);
                  table.setPageSize(newSize); // still update internal table if needed
                  onPageSizeChange(newSize); // ✅ inform parent
                }}
                className="bg-transparent pl-2.5"
              >
                {[5, 10, 20, 50].map((pageSize) => (
                  <option key={pageSize} value={pageSize}>
                    {pageSize}
                  </option>
                ))}
              </select>
            </div>
          )}
          <button
            className="flex h-fit w-[70px] items-center justify-center rounded-[3px] p-[7px] bg-primary text-white"
            onClick={onNavigation}
          >
            {commonTranslations(TRANSLATIONS.ADD)}
          </button>
          {isImport && (
            <label className="flex h-fit w-[70px] items-center justify-center rounded-[3px] p-[7px] bg-primary text-white cursor-pointer">
              {commonTranslations(TRANSLATIONS.IMPORT)}
              <input
                type="file"
                accept={FileAcceptType.CSV}
                onChange={onFileUpload}
                className="hidden"
              />
            </label>
          )}
        </div>
      </div>
      <div className="grid grid-cols-1 overflow-x-visible">
        <table className="datatable-table datatable-one !border-collapse px-4 md:px-8">
          <thead className="border-separate px-4">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr
                className="border-t border-stroke dark:border-dark-3"
                key={headerGroup.id}
              >
                {headerGroup.headers.map((header) => (
                  <th key={header.id} className="whitespace-nowrap">
                    <div>
                      <div
                        className="flex cursor-pointer items-center"
                        onClick={header.column.getToggleSortingHandler()}
                      >
                        <span
                          className={header.column.id == "action" ? "" : ""}
                        >
                          {flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                        </span>
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            ))}
          </thead>

          <tbody>
            {table.getRowModel().rows.length === 0 && (
              <tr>
                <td colSpan={columns.length} className="py-12 text-center">
                  {commonTranslations(TRANSLATIONS.NODATAFOUND)}
                </td>
              </tr>
            )}

            {table.getRowModel().rows.map((row) => (
              <>
                <tr
                  key={row.id}
                  className="border-t border-stroke dark:border-dark-3"
                >
                  {row
                    .getVisibleCells()
                    .filter(
                      (cell) => showActions || cell.column.id !== "action"
                    )
                    .map((cell) => (
                      <td
                        key={cell.id}
                        className={`pr-5 lg:pr-7.5 2xl:pr-11 ${
                          cell.column.id !== "action"
                            ? "max-w-[200px] truncate whitespace-nowrap overflow-hidden text-ellipsis"
                            : ""
                        }`}
                      >
                        {cell.column.id === "action" ? (
                          <RowActions
                            onActionEvent={onActionEvent}
                            id={row.original.id}
                          />
                        ) : (
                          (flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          ) as React.ReactNode)
                        )}
                      </td>
                    ))}
                    {/* View Button */}
                  <button className="inline-flex items-center gap-2.5 rounded-lg bg-primary px-4 py-[7px] font-medium text-white hover:bg-opacity-90">
                    View
                  </button>

                </tr>
              </>
            ))}
          </tbody>
        </table>
      </div>
      {table && table.getRowModel().rows.length > 0 && (
        <div className="flex justify-between items-center px-7.5 py-7">
          <div className="flex items-center">
            <button
              onClick={() => onPagination(false)}
              className="disabled:pointer-events-none group flex items-center justify-center rounded-[3px] p-[7px] hover:bg-primary"
              disabled={paginationOptions.pageIndex < 1}
            >
              <Image
                src={chevronleft}
                alt="search"
                height={18}
                width={18}
                priority
                unoptimized
                className="invert-icon group-hover:invert"
              />
            </button>
            {pagination &&
              pagination.length > 0 &&
              pagination?.map((option, index) => {
                if (typeof option === "number") {
                  return (
                    <button
                      key={option}
                      onClick={() =>
                        onPageChange(option - 1, paginationOptions.pageSize)
                      }
                      className={`${
                        paginationOptions.pageIndex === option - 1
                          ? "bg-primary text-white"
                          : ""
                      } mx-1 rounded px-4 py-2 hover:bg-primary hover:text-white`}
                    >
                      {option}
                    </button>
                  );
                } else {
                  return (
                    <div
                      className="flex item-center"
                      key={`${option}__${index}`}
                    >
                      <div>.</div>
                      <div>.</div>
                      <div>.</div>
                      <div>.</div>
                      <div>.</div>
                    </div>
                  );
                }
              })}
            {/* {Array.from({ length: totalPages }, (_, pageIndex) => (
              <button
                key={pageIndex}
                onClick={() => onPageChange(pageIndex, paginationOptions.pageSize)}
                className={`${paginationOptions.pageIndex === pageIndex
                  ? "bg-primary text-white"
                  : ""
                  } mx-1 rounded px-4 py-2 hover:bg-primary hover:text-white`}
              >
                {pageIndex + 1}
              </button>
            ))} */}

            <button
              onClick={() => onPagination(true)}
              className="disabled:pointer-events-none group flex items-center justify-center rounded-[3px] p-[7px] hover:bg-primary"
              disabled={
                paginationOptions.pageIndex + 1 ===
                Math.ceil(
                  (paginationOptions.totalCount ?? 0) /
                    paginationOptions.pageSize
                )
              }
            >
              <Image
                src={chevronright}
                alt="chevron right"
                height={18}
                width={18}
                priority
                unoptimized
                className="invert-icon group-hover:invert"
              />
            </button>
          </div>

          <p className="font-medium">
            {`Showing ${paginationOptions.pageIndex + 1} of ${Math.ceil(
              (paginationOptions.totalCount ?? 0) / paginationOptions.pageSize
            )} pages`}
          </p>
        </div>
      )}
    </section>
  );
};

export default DynamicTable;
