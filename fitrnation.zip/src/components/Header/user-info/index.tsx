"use client";

import { chevronup, password } from "@/assets/icons";
import {
  Dropdown,
  DropdownContent,
  DropdownTrigger,
} from "@/components/ui/dropdown";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { LogOutIcon } from "./icons";
import { cn } from "@/utils/class-utils";
import { LocalStorageKeysEnum, PlatformEnumModel } from "@/constants/enumConstants";
import { useApolloClient } from "@apollo/client";
import { useAuthContext } from "@/context/AuthContext";
import { showSuccessToast } from "@/utils/toastUtils";
import { processEncryption } from "@/utils/encryption-decryption";
import { AuthApiProvider } from "@/app/(auth)/_services/Auth.apiservice";
import { AdminLogoutModel } from "@/app/(auth)/_types/Auth.types";
import logo from "@/assets/logos/logo.png";
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";

export function UserInfo() {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const client = useApolloClient();
  const { checkAuth, userInfo } = useAuthContext();
  const commonTranslation=useTranslations(TRANSLATIONS.COMMON)
  const handleLogout = () => {
    const device_id = sessionStorage.getItem(LocalStorageKeysEnum.DEVICE_ID);
    if (device_id) {
      const variable = {
        admin_logout_input: {
          device_id: device_id,
          platform: PlatformEnumModel.WEB,
        }
      }
      setIsOpen(false);
      AuthApiProvider.apolloInstance.adminLogout(
        client,
        variable,
        (success) => {
          const response = (success?.data as AdminLogoutModel)?.adminLogout;
          if (response?.success) {
            showSuccessToast(response?.message ?? '');
            localStorage.removeItem(LocalStorageKeysEnum.ROLE);
            localStorage.removeItem(LocalStorageKeysEnum.USER_INFO);
            localStorage.removeItem(LocalStorageKeysEnum.TOKEN_DATA);
            checkAuth();
          }
        },
        () => { }
      )
    }
  }


  return (
    <Dropdown isOpen={isOpen} setIsOpen={setIsOpen}>
      <DropdownTrigger className="rounded align-middle outline-none ring-primary ring-offset-2 focus-visible:ring-1 dark:ring-offset-gray-dark">
        <span className="sr-only">My Account</span>

        <figure className="flex items-center gap-3">
          <Image
            src={logo}
            alt={"Avatar for John Smith"}
            width={50}
            height={30}
            className="object-cover"
            role="presentation"
          />
          <figcaption className="flex items-center gap-1 font-medium text-dark dark:text-dark-6 max-[1024px]:sr-only">
            <span>{processEncryption(userInfo?.full_name ?? '', true)}</span>
            <Image
              src={chevronup}
              alt="chevronup"
              height={20}
              width={20}
              priority
              unoptimized
              className={cn(
                "rotate-180 transition-transform dark:invert",
                isOpen && "rotate-0",
              )}
            />
          </figcaption>
        </figure>
      </DropdownTrigger>

      <DropdownContent
        className="border border-stroke bg-white shadow-md dark:border-dark-3 dark:bg-gray-dark min-[230px]:min-w-[17.5rem]"
        align="end"
      >
        <h2 className="sr-only">User information</h2>

        <figure className="flex items-center gap-2.5 px-5 py-3.5">
          <Image
            src={logo}
            className="size-12 rounded-full"
            alt={`Avatar for ${'John Smith'}`}
            role="presentation"
            width={200}
            height={200}
          />

          <figcaption className="space-y-1 text-base font-medium">
            <div className="mb-2 leading-none text-dark dark:text-white">
              {processEncryption(userInfo?.full_name ?? '', true)}
            </div>

            <div className="line-clamp-1 break-all leading-none text-gray-6">
              {processEncryption(userInfo?.email ?? '', true)}
            </div>
          </figcaption>
        </figure>

        <hr className="border-[#E8E8E8] dark:border-dark-3" />

        <div className="p-2 text-base text-[#4B5563] dark:text-dark-6 [&>*]:cursor-pointer">
          <Link
            href={"/change-password"}
            onClick={() => setIsOpen(false)}
            className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-[9px] hover:bg-gray-2 hover:text-dark dark:hover:bg-dark-3 dark:hover:text-white"
          >
            <Image
              src={password}
              alt="menu"
              width={20}
              height={20}
              priority
              unoptimized />

            <span className="mr-auto text-base font-medium">
              {commonTranslation(TRANSLATIONS.CHANGEPASSWORD)}
            </span>
          </Link>
        </div>

        <hr className="border-[#E8E8E8] dark:border-dark-3" />

        <div className="p-2 text-base text-[#4B5563] dark:text-dark-6">
          <button
            className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-[9px] hover:bg-gray-2 hover:text-dark dark:hover:bg-dark-3 dark:hover:text-white"
            onClick={handleLogout}
          >
            <LogOutIcon />

            <span className="text-base font-medium">{commonTranslation(TRANSLATIONS.LOGOUT)}
            </span>
          </button>
        </div>
      </DropdownContent>
    </Dropdown>
  );
}
