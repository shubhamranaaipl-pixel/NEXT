"use client";;
import { IGNORE_ROUTES } from "@/constants/appConstants";
import { ROUTES } from "@/constants/routes.constants";
import { useAuthContext } from "@/context/AuthContext";
import { usePathname } from "next/navigation";
// src/components/Layout.tsx
import React, { useEffect, useState } from "react";
import Loading from "../Loading";



interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { isAuthenticated } = useAuthContext();
  const usePathName = usePathname();
  const [showAppLogo, setShowAppLogo] = useState<boolean>(true);

  useEffect(() => {
    if (usePathName === ROUTES.LOGIN || IGNORE_ROUTES.includes(usePathName)) {
      if (isAuthenticated == null || isAuthenticated) {
        setShowAppLogo(true);
      } else {
        setShowAppLogo(false);
      }
    } else {
      if (isAuthenticated == null || !isAuthenticated) {
        setShowAppLogo(true);
      } else {
        setShowAppLogo(false);
      }
    }
  }, [isAuthenticated, usePathName]);
  if (showAppLogo) {
    return (
      <Loading />
    );
  }
  return <>{children}</>;
};

export default Layout;
