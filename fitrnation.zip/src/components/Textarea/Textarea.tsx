import { TRANSLATIONS } from "@/constants/translationConstants";
import { cn } from "@/utils/class-utils";
import { useTranslations } from "next-intl";
import { useId } from "react";

type TextareaProps = {
  className?: string;
  label: string;
  placeholder: string;
  required?: boolean;
  disabled?: boolean;
  active?: boolean;
  handleChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  onBlur?: (e: React.FocusEvent<HTMLTextAreaElement>) => void;
  value?: string;
  name?: string;
  icon?: React.ReactNode;
  error?: string;
  rows?: number;
};

const Textarea: React.FC<TextareaProps> = ({
  className,
  label,
  placeholder,
  required,
  disabled,
  active,
  handleChange,
  icon,
  error,
  onBlur,
  rows = 4,
  ...props
}) => {
  const id = useId();
  const errorTranslation = useTranslations(TRANSLATIONS.ERRORSMESSAGE);

  return (
    <div className={className}>
      <label
        htmlFor={id}
        className="text-body-sm font-medium text-dark dark:text-white"
      >
        {label}
        {required && <span className="ml-1 select-none text-red">*</span>}
      </label>

      <div
        className={cn(
          "relative mt-3 [&_svg]:absolute [&_svg]:right-4.5 [&_svg]:top-1/2 [&_svg]:-translate-y-1/2",
          { "flex gap-2": icon }
        )}
      >
        <textarea
          autoComplete="off"
          id={id}
          name={props.name}
          placeholder={placeholder}
          onChange={handleChange}
          onBlur={onBlur}
          value={props.value ?? ''}
          rows={rows}
          className={cn(
            "w-full resize-y rounded-lg border-[1.5px] border-stroke bg-transparent px-5.5 py-3 text-dark placeholder:text-dark-6 outline-none transition focus:border-primary disabled:cursor-default disabled:bg-gray-2 data-[active=true]:border-primary dark:border-dark-3 dark:bg-dark-2 dark:text-white dark:placeholder:text-white/60 dark:focus:border-primary dark:disabled:bg-dark dark:data-[active=true]:border-primary"
          )}
          // required={required}
          disabled={disabled}
          data-active={active}
        />
        {icon}
      </div>

      {error && <span className="mt-2 text-sm text-red">{errorTranslation(error)}</span>}
    </div>
  );
};

export default Textarea;
