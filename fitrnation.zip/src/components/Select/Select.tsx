import { chevronup } from "@/assets/icons";
import { TRANSLATIONS } from "@/constants/translationConstants";
import { cn } from "@/utils/class-utils";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useState, useRef, useEffect } from "react";

export type SelectOption = { value: string | number; label: string };

type PropsType = {
  label: string;
  items: SelectOption[];
  selectedItem?: SelectOption;
  value?: string | number;
  onChange?: (value: string | number) => void;
  prefixIcon?: React.ReactNode;
  className?: string;
  placeholder?: string;
  required?: boolean;
  error?: string;
};

export function Select({
  items,
  label,
  value,
  onChange,
  placeholder,
  prefixIcon,
  className,
  selectedItem,
  required,
  error,
}: PropsType) {
  const errorTranslation = useTranslations(TRANSLATIONS.ERRORSMESSAGE);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedValue = value ?? selectedItem?.value ?? "";
  const selected = items.find((item) => item.value === selectedValue);

  const toggleDropdown = () => setIsOpen((prev) => !prev);

  const handleSelect = (item: SelectOption) => {
    onChange?.(item.value);
    setIsOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className={cn("space-y-3", className)} ref={dropdownRef}>
      <label
        className="block text-body-sm font-medium text-dark dark:text-white"
      >
        {label}
        {required && <span className="ml-1 select-none text-red">*</span>}
      </label>

      <div className="relative">
        <button
          type="button"
          onClick={toggleDropdown}
          className={cn(
            "w-full text-left rounded-lg border border-stroke bg-transparent px-5.5 py-3 outline-none transition focus:border-primary active:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary",
            prefixIcon && "pl-11.5"
          )}
        >
          <div className="flex items-center space-x-2">
            {prefixIcon && (
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                {prefixIcon}
              </div>
            )}
            <span className="truncate text-dark dark:text-white">
              {selected?.label || placeholder || "Select..."}
            </span>
          </div>
        </button>

        <Image
          src={chevronup}
          alt="toggle"
          height={20}
          width={20}
          priority
          unoptimized
          className={cn(
            "pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 transition-transform",
            isOpen && "rotate-180",
            "dark:invert"
          )}
        />

        {isOpen && (
          <ul className="absolute z-[99999] mt-1 max-h-60 w-full overflow-auto rounded-lg border border-stroke bg-white dark:bg-dark-2 shadow-lg">
            {items.map((item, index) => (
              <li
                key={`${item.value}__${index}`}
                onClick={() => handleSelect(item)}
                className="cursor-pointer px-5.5 py-2 text-dark hover:bg-primary hover:text-white dark:text-white dark:hover:bg-primary"
              >
                {item.label}
              </li>
            ))}
          </ul>
        )}
      </div>

      {error && (
        <span className="mt-2 text-sm text-red">{errorTranslation(error)}</span>
      )}
    </div>
  );
}
