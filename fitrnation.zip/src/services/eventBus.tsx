// eventBus.ts


// Create a new EventTarget instance
export const eventBus = new EventTarget();

// Dispatch a custom event with `any` as the type for detail
export const dispatchCustomEvent = (eventName: string, detail: any) => {
  const event = new CustomEvent<any>(eventName, { detail });
  eventBus.dispatchEvent(event);
};
