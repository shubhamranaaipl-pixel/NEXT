export class OriginalError {
  message?: string;

  statusCode?: number;
}
export class Extensions {
  code?: string;

  response?: OriginalError;
}

export class Location {
  line?: number;

  column?: number;
}

export class Error {
  message?: string;

  locations?: Location[];

  path?: string[];

  extensions?: Extensions;
}

export class ErrorsModel {
  errors?: Error[];
}
