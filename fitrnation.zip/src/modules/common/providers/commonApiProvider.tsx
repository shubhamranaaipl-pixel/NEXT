import { ApolloService } from "@/graphql/ApolloService";

export class CommonApiProvider extends ApolloService {
    static apolloInstance: CommonApiProvider = new CommonApiProvider();


}
