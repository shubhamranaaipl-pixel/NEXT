import config from "@/config/config";
import { MANUAL_LOADING_HIDE, MANUAL_LOADING_SHOW } from "@/constants/serviceConstants";
import Authorization from "@/graphql/Authoriser";
import { dispatchCustomEvent } from "@/services/eventBus";

// Using fetch API
export const ImageApiProvider = async (file: File) => {
  try {
    const formData = new FormData();
    dispatchCustomEvent(MANUAL_LOADING_SHOW, {});
    formData.append('file', file);
    const authToken = await Authorization();
    const response = await fetch((config.apiUrl) + "/image", {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    dispatchCustomEvent(MANUAL_LOADING_HIDE, {});
    const result = await response.json();
    return result;
  } catch (error) {
    console.error(error);
    dispatchCustomEvent(MANUAL_LOADING_HIDE, {});
    return null;
  }
};

export const VideoApiProvider = async (file: File) => {
  try {
    const formData = new FormData();
    dispatchCustomEvent(MANUAL_LOADING_SHOW, {});
    formData.append('file', file);
    const authToken = await Authorization();
    const response = await fetch((config.apiUrl) + "/video-upload/videoUpload", {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    dispatchCustomEvent(MANUAL_LOADING_HIDE, {});
    const result = await response.json();
    return result;
  } catch (error) {
    console.error(error);
    dispatchCustomEvent(MANUAL_LOADING_HIDE, {});
    return null;
  }
};


export const WorkoutCSVApiProvider = async (file: File) => {
  try {
    const formData = new FormData();
    dispatchCustomEvent(MANUAL_LOADING_SHOW, {});
    formData.append('file', file);
    const authToken = await Authorization();
    const response = await fetch((config.apiUrl) + "/upload/workout", {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
      },
      body: formData,
    });

    dispatchCustomEvent(MANUAL_LOADING_HIDE, {});
    const result = await response.json();
    return result;
  } catch (error) {
    dispatchCustomEvent(MANUAL_LOADING_HIDE, {});
    return error;
  }
};