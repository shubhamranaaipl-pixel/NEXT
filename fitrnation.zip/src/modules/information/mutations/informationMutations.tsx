import gql from "graphql-tag";

export const adminCreateInformation = gql`
  mutation adminCreateInformationPage($create_information_page_input: InformationPageInput!) {
    adminCreateInformationPage(create_information_page_input: $create_information_page_input) {
      success
      message
    }
  }
`;



export const adminUpdateInformation = gql`
  mutation adminUpdateInformationPage($update_information_page_input: UpdateInformationPageInput!) {
    adminUpdateInformationPage(update_information_page_input: $update_information_page_input) {
      success
      message
    }
  }
`;
