export interface IConfig{
    trending_url:string;
    image_url:string;
    toprated_url:string;
    upcoming_url:string;
    search_url:string;
}


export const config:IConfig={
    trending_url:process.env.NEXT_PUBLIC_TREANDING_MOVIE||"",
    image_url:process.env.NEXT_PUBLIC_IMAGE_URL ||"",
    toprated_url:process.env.NEXT_PUBLIC_TOP_RATED_MOVIE||"",
    upcoming_url:process.env.NEXT_PUBLIC_UPCOMING_MOVIE||"",
    search_url:process.env.NEXT_PUBLIC_SEARCH_URL||"",
}