"use client";
import { imageConstant } from "@/constants/imageconstant";
import { useHeader } from "./useHeader";
import Image from "next/image";

export default function Header() {
  const { inputData, handleData,searchData } = useHeader();
 
  return (
    <>
      <Image
        src={imageConstant.mainlogo}
        alt="Logo Image Not Found"
        width={60}
        height={60}
      />
      <ul>
        <li>Movies</li>
        <li>Tv Shows</li>
        <li>More</li>
      </ul>
      <input
        type="text"
        placeholder="Search"
        value={inputData}
        onChange={(e) => handleData(e)}
      />
       <button onClick={searchData}>Search</button>
    </>
  );
}
