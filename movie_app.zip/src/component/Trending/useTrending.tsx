"use client";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { useState, useEffect } from "react";
import { IMovie } from "@/modules/movies/models/IMovie";

export const useTrending = () => {
  const [trendingMovie, setTrendingMovie] = useState<IMovie[]>([]);

  const trendingMovieData = async () => {
    const response = await fetch(`${config.trending_url}${ApiKey.API_KEY}`);
    const movieData = await response.json();
    setTrendingMovie(movieData.results);
  };

  useEffect(() => {
    const callFetchFunction = () => {
      trendingMovieData();
    };
    callFetchFunction();
  }, []);

  return {
    trendingMovie,
  };
};
