"use client";
import { useUpComing } from "./useUpComing";
import Image from "next/image";
import { config } from "@/config/config";
export default function UpComing() {
  const { upComingMovie } = useUpComing();
  return (
    <>
      {upComingMovie.map((movieItem) => {
        <div key={movieItem.id}>
          <Image
            src={`${config.image_url}${movieItem.poster_path}`}
            alt=" Movie Image  Not Found"
            width={150}
            height={150}
          />
          <h1>{movieItem.title}</h1>
          <p>Media Types:{movieItem.media_type}</p>
          <h1>Language:{movieItem.original_language}</h1>
        </div>;
      })}
    </>
  );
}
