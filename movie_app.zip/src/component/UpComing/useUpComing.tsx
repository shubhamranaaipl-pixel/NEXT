"use client";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { useState, useEffect } from "react";
import { IMovie } from "@/modules/movies/models/IMovie";

export const useUpComing = () => {
  const [upComingMovie, setUpComingMovie] = useState<IMovie[]>([]);

  const upComingMovieData = async () => {
    const response = await fetch(`${config.upcoming_url}${ApiKey.API_KEY}`);
    const movieData = await response.json();
    setUpComingMovie(movieData.results);
  };

  useEffect(() => {
    const callFetchFunction = () => {
      upComingMovieData();
    };
    callFetchFunction();
  }, []);
  return {
    upComingMovie,
  };
};
