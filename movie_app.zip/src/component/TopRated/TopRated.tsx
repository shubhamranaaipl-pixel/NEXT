"use client";


import Image from "next/image";
import { config } from "@/config/config";

import { useTopRated } from "./useTopRated";
export default function TopRatedMovie(){
 const {topRatedMovie}=useTopRated();


    return (
        <>
       <h1>Top Rated Movies</h1>
       {topRatedMovie.map((movieItem)=>
    
        <div key={movieItem.id}>
           
            <Image
             src={`${config.image_url}${movieItem.poster_path}`}
             alt=" Movie Image  Not Found"
             width={150}
             height={150}
            />  
            <h1>{movieItem.title}</h1>
            <p>Media Types:{movieItem.media_type}</p>
            <h1>Language:{movieItem.original_language}</h1>
          
        </div>
    )}
        </>
    )
}