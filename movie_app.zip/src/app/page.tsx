import TreandingMovie from "@/component/Trending/Trending";
import TopRatedMovie from "@/component/TopRated/TopRated";
import UpComing from "@/component/UpComing/UpComing";

export default function Home() {
  return (
    <>
    <TreandingMovie/>
    <TopRatedMovie/>
    <UpComing/>
    </>
  );
}
