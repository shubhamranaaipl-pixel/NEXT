export const imageConstant={
    mainlogo:"/images/logo.jpg"
}