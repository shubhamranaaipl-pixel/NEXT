export const ApiEndPoints={
    SEARCH_DATA:"&query=",
}