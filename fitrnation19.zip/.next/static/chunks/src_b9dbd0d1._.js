(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/Table/ColumnFilter.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const ColumnFilter = ({ column })=>{
    const { filterValue, setFilter } = column;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: "text",
        value: filterValue || "",
        onChange: (e)=>setFilter(e.target.value),
        onClick: (e)=>e.stopPropagation(),
        className: "mt-2.5 w-full rounded-md border border-stroke px-3 py-1 outline-none focus:border-primary"
    }, void 0, false, {
        fileName: "[project]/src/components/Table/ColumnFilter.tsx",
        lineNumber: 12,
        columnNumber: 7
    }, this);
};
_c = ColumnFilter;
const __TURBOPACK__default__export__ = ColumnFilter;
var _c;
__turbopack_context__.k.register(_c, "ColumnFilter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/icons/chevronleft.svg.mjs { IMAGE => \"[project]/src/assets/icons/chevronleft.svg (static in ecmascript)\" } [app-client] (structured image object, ecmascript) <export default as chevronleft>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "chevronleft": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/icons/chevronleft.svg.mjs { IMAGE => "[project]/src/assets/icons/chevronleft.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
}}),
"[project]/src/assets/icons/chevronright.svg.mjs { IMAGE => \"[project]/src/assets/icons/chevronright.svg (static in ecmascript)\" } [app-client] (structured image object, ecmascript) <export default as chevronright>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "chevronright": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/icons/chevronright.svg.mjs { IMAGE => "[project]/src/assets/icons/chevronright.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
}}),
"[project]/src/assets/icons/search.svg.mjs { IMAGE => \"[project]/src/assets/icons/search.svg (static in ecmascript)\" } [app-client] (structured image object, ecmascript) <export default as search>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "search": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/icons/search.svg.mjs { IMAGE => "[project]/src/assets/icons/search.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
}}),
"[project]/src/components/Dropdown/Dropdown.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Dropdown": (()=>Dropdown),
    "DropdownContent": (()=>DropdownContent),
    "DropdownTrigger": (()=>DropdownTrigger),
    "abc": (()=>abc)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$click$2d$outside$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-click-outside.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$class$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/class-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
"use client";
;
;
;
const DropdownContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useDropdownContext() {
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DropdownContext);
    if (!context) {
        throw new Error("useDropdownContext must be used within a Dropdown");
    }
    return context;
}
_s(useDropdownContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function Dropdown({ children, isOpen, setIsOpen }) {
    _s1();
    const triggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleKeyDown = (event)=>{
        if (event.key === "Escape") {
            handleClose();
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Dropdown.useEffect": ()=>{
            if (isOpen) {
                triggerRef.current = document.activeElement;
                document.body.style.pointerEvents = "none";
            } else {
                document.body.style.removeProperty("pointer-events");
                setTimeout({
                    "Dropdown.useEffect": ()=>{
                        triggerRef.current?.focus();
                    }
                }["Dropdown.useEffect"], 0);
            }
        }
    }["Dropdown.useEffect"], [
        isOpen
    ]);
    function handleClose() {
        setIsOpen(false);
    }
    function handleOpen() {
        setIsOpen(true);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DropdownContext.Provider, {
        value: {
            isOpen,
            handleOpen,
            handleClose
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            onKeyDown: handleKeyDown,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Dropdown/Dropdown.tsx",
            lineNumber: 63,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Dropdown/Dropdown.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
_s1(Dropdown, "QXxX+v+MynEkxRTPkX3LP3X7NSA=");
_c = Dropdown;
function abc() {
    console.log("abc");
}
function DropdownContent({ children, align = "center", className }) {
    _s2();
    const { isOpen, handleClose } = useDropdownContext();
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$click$2d$outside$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClickOutside"])({
        "DropdownContent.useClickOutside[contentRef]": ()=>{
            if (isOpen) handleClose();
        }
    }["DropdownContent.useClickOutside[contentRef]"]);
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: contentRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$class$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("pointer-events-auto rounded absolute z-99 mt-1 min-w-[8rem] max-h-[300px] overflow-auto", {
            "right-0": align === "end",
            "left-0": align === "start",
            "left-1/2 -translate-x-1/2": align === "center"
        }, className),
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/Dropdown/Dropdown.tsx",
        lineNumber: 94,
        columnNumber: 5
    }, this);
}
_s2(DropdownContent, "lF8FAQo2tCxZBcEmAIbzADhx13g=", false, function() {
    return [
        useDropdownContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$click$2d$outside$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClickOutside"]
    ];
});
_c1 = DropdownContent;
function DropdownTrigger({ children, className }) {
    _s3();
    const { handleOpen, isOpen } = useDropdownContext();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: className,
        onClick: handleOpen,
        "aria-expanded": isOpen,
        "aria-haspopup": "menu",
        "data-state": isOpen ? "open" : "closed",
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/Dropdown/Dropdown.tsx",
        lineNumber: 119,
        columnNumber: 5
    }, this);
}
_s3(DropdownTrigger, "qltlfvpVmj1NFtnJ1aP5zRyFQv0=", false, function() {
    return [
        useDropdownContext
    ];
});
_c2 = DropdownTrigger;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Dropdown");
__turbopack_context__.k.register(_c1, "DropdownContent");
__turbopack_context__.k.register(_c2, "DropdownTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Table/row.actions.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "RowActions": (()=>RowActions)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Dropdown$2f$Dropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Dropdown/Dropdown.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/enumConstants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/assets/icons/index.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronup$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronup$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__chevronup$3e$__ = __turbopack_context__.i('[project]/src/assets/icons/chevronup.svg.mjs { IMAGE => "[project]/src/assets/icons/chevronup.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript) <export default as chevronup>');
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function RowActions({ id, onActionEvent }) {
    _s();
    const actionList = [
        {
            name: "Edit",
            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].EDIT
        },
        {
            name: "Delete",
            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].DELETE
        }
    ];
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    function handleActionClick(action, id) {
        onActionEvent(action, id);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Dropdown$2f$Dropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dropdown"], {
        isOpen: isOpen,
        setIsOpen: setIsOpen,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Dropdown$2f$Dropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownTrigger"], {
                className: "group flex items-center gap-1 rounded-md px-3 py-[5px] text-[14px] font-medium text-dark shadow-[0px_1px_3px_0px_rgba(166,175,195,0.40)] hover:text-accent data-[state=open]:text-accent dark:border dark:border-dark-3 dark:shadow-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "dark:text-white",
                        children: "Action"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Table/row.actions.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronup$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronup$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__chevronup$3e$__["chevronup"],
                        alt: "search",
                        height: 20,
                        width: 20,
                        priority: true,
                        unoptimized: true,
                        className: "size-4 translate-y-[5%] rotate-180 transition-transform group-data-[state=open]:rotate-0 dark:text-white dark:invert"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Table/row.actions.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Table/row.actions.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Dropdown$2f$Dropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownContent"], {
                className: "border border-stroke bg-white shadow-md dark:border-dark-3 dark:bg-gray-dark",
                align: "end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    className: "w-40 overflow-clip rounded-[5px] p-0 text-sm font-medium text-current shadow-[0px_0.5px_3px_0px_rgba(0,0,0,0.18)]",
                    children: actionList.map((action, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setIsOpen(false);
                                    handleActionClick(action.type, id);
                                },
                                className: "block w-full px-[15px] py-2.5 text-left hover:bg-[#F5F7FD] hover:text-accent focus:bg-[#F5F7FD] focus:text-accent",
                                children: action.name
                            }, void 0, false, {
                                fileName: "[project]/src/components/Table/row.actions.tsx",
                                lineNumber: 42,
                                columnNumber: 15
                            }, this)
                        }, `${index}__${action?.name}`, false, {
                            fileName: "[project]/src/components/Table/row.actions.tsx",
                            lineNumber: 41,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/Table/row.actions.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Table/row.actions.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Table/row.actions.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_s(RowActions, "+sus0Lb0ewKHdwiUhiTAJFoFyQ0=");
_c = RowActions;
var _c;
__turbopack_context__.k.register(_c, "RowActions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/modules/common/providers/ImageApiProvider.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ImageApiProvider": (()=>ImageApiProvider),
    "VideoApiProvider": (()=>VideoApiProvider),
    "WorkoutCSVApiProvider": (()=>WorkoutCSVApiProvider)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/config.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/serviceConstants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/graphql/Authoriser.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/eventBus.tsx [app-client] (ecmascript)");
;
;
;
;
const ImageApiProvider = async (file)=>{
    try {
        const formData = new FormData();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_SHOW"], {});
        formData.append('file', file);
        const authToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
        const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].apiUrl + "/image", {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        const result = await response.json();
        return result;
    } catch (error) {
        console.error(error);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        return null;
    }
};
_c = ImageApiProvider;
const VideoApiProvider = async (file)=>{
    try {
        const formData = new FormData();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_SHOW"], {});
        formData.append('file', file);
        const authToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
        const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].apiUrl + "/video-upload/videoUpload", {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        const result = await response.json();
        return result;
    } catch (error) {
        console.error(error);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        return null;
    }
};
_c1 = VideoApiProvider;
const WorkoutCSVApiProvider = async (file)=>{
    try {
        const formData = new FormData();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_SHOW"], {});
        formData.append('file', file);
        const authToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$graphql$2f$Authoriser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
        const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].apiUrl + "/upload/workout", {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        const result = await response.json();
        return result;
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$eventBus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchCustomEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$serviceConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANUAL_LOADING_HIDE"], {});
        return error;
    }
};
_c2 = WorkoutCSVApiProvider;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ImageApiProvider");
__turbopack_context__.k.register(_c1, "VideoApiProvider");
__turbopack_context__.k.register(_c2, "WorkoutCSVApiProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Input/Input.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "FileAcceptType": (()=>FileAcceptType),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/translationConstants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$modules$2f$common$2f$providers$2f$ImageApiProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/modules/common/providers/ImageApiProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$class$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/class-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/toastUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
var FileAcceptType = /*#__PURE__*/ function(FileAcceptType) {
    FileAcceptType["IMAGE"] = "image/*";
    FileAcceptType["VIDEO"] = "video/*";
    FileAcceptType["IMAGE_AND_VIDEO"] = "image/*,video/*";
    FileAcceptType["CSV"] = ".xlsx, .csv, text/csv";
    return FileAcceptType;
}({});
const Input = ({ // id,
className, label, type, placeholder, required, disabled, active, handleChange, icon, error, onBlur, onUploadSuccess, accept, ...props })=>{
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const errorTranslation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSLATIONS"].ERRORSMESSAGE);
    const handleInputChange = async (e)=>{
        if (type === "file" && e.target.files?.[0]) {
            const file = e.target.files?.[0];
            if (file) {
                switch(accept){
                    case "image/*":
                        const image = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$modules$2f$common$2f$providers$2f$ImageApiProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageApiProvider"])(file);
                        if (image?.success) {
                            const obj = {
                                id: image?.id,
                                url: image?.url,
                                name: ""
                            };
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["showSuccessToast"])(image?.message ?? '');
                            onUploadSuccess?.(obj);
                        } else {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["showErrorToast"])(image?.message ?? '');
                        }
                        break;
                    case "video/*":
                        const video = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$modules$2f$common$2f$providers$2f$ImageApiProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VideoApiProvider"])(file);
                        if (video?.success) {
                            const obj = {
                                id: video?.id,
                                url: video?.url,
                                name: ""
                            };
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["showSuccessToast"])(video?.message ?? '');
                            onUploadSuccess?.(obj);
                        } else {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toastUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["showErrorToast"])(video?.message ?? '');
                        }
                        break;
                }
            }
        }
        handleChange?.(e);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: "text-body-sm font-medium text-dark dark:text-white",
                children: [
                    label,
                    required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-1 select-none text-red",
                        children: "*"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Input/Input.tsx",
                        lineNumber: 114,
                        columnNumber: 22
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$class$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative mt-3 [&_svg]:absolute [&_svg]:right-4.5 [&_svg]:top-1/2 [&_svg]:-translate-y-1/2", {
                    "flex gap-2": icon
                }),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        // autoComplete="off"
                        id: id,
                        type: type,
                        name: props.name,
                        placeholder: placeholder,
                        onChange: handleInputChange,
                        onBlur: onBlur,
                        value: type !== "file" ? props.value ?? "" : undefined,
                        accept: type === "file" ? accept : undefined,
                        className: "w-full rounded-lg border-[1.5px] border-stroke bg-transparent outline-none transition focus:border-primary disabled:cursor-default disabled:bg-gray-2 data-[active=true]:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary dark:disabled:bg-dark dark:data-[active=true]:border-primary" + (type === "file" ? ` ${getFileStyles(props.fileStyleVariant || "style1")}` : " px-5.5 py-3 text-dark placeholder:text-dark-6 dark:text-white"),
                        required: props.mediaValue ? false : required,
                        disabled: disabled,
                        "data-active": active
                    }, void 0, false, {
                        fileName: "[project]/src/components/Input/Input.tsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, this),
                    icon
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            type === "file" && props.mediaValue && props.mediaValue?.url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 text-body-xs text-dark-5 dark:text-white",
                children: [
                    "Selected file: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: "text-primary",
                        href: props.mediaValue.url,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: props.mediaValue.name || 'View'
                    }, void 0, false, {
                        fileName: "[project]/src/components/Input/Input.tsx",
                        lineNumber: 150,
                        columnNumber: 26
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 149,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mt-2 text-sm text-red",
                children: errorTranslation(error)
            }, void 0, false, {
                fileName: "[project]/src/components/Input/Input.tsx",
                lineNumber: 153,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Input/Input.tsx",
        lineNumber: 108,
        columnNumber: 5
    }, this);
};
_s(Input, "0y5L52NGQBpEBlVhRC806uIitxY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = Input;
const __TURBOPACK__default__export__ = Input;
function getFileStyles(variant) {
    switch(variant){
        case "style1":
            return `file:mr-5 file:border-collapse file:cursor-pointer file:border-0 file:border-r file:border-solid file:border-stroke file:bg-[#E2E8F0] file:px-6.5 file:py-[13px] file:text-body-sm file:font-medium file:text-dark-5 file:hover:bg-primary file:hover:bg-opacity-10 dark:file:border-dark-3 dark:file:bg-white/30 dark:file:text-white`;
        default:
            return `file:mr-4 file:rounded file:border-[0.5px] file:border-stroke file:bg-stroke file:px-2.5 file:py-1 file:text-body-xs file:font-medium file:text-dark-5 file:focus:border-primary dark:file:border-dark-3 dark:file:bg-white/30 dark:file:text-white px-3 py-[9px]`;
    }
}
var _c;
__turbopack_context__.k.register(_c, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Table/Table.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "DynamicTable": (()=>DynamicTable),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-table/build/lib/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/table-core/build/lib/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Table$2f$ColumnFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Table/ColumnFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/assets/icons/index.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__chevronleft$3e$__ = __turbopack_context__.i('[project]/src/assets/icons/chevronleft.svg.mjs { IMAGE => "[project]/src/assets/icons/chevronleft.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript) <export default as chevronleft>');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__chevronright$3e$__ = __turbopack_context__.i('[project]/src/assets/icons/chevronright.svg.mjs { IMAGE => "[project]/src/assets/icons/chevronright.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript) <export default as chevronright>');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__search$3e$__ = __turbopack_context__.i('[project]/src/assets/icons/search.svg.mjs { IMAGE => "[project]/src/assets/icons/search.svg (static in ecmascript)" } [app-client] (structured image object, ecmascript) <export default as search>');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Table$2f$row$2e$actions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Table/row.actions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/translationConstants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Input/Input.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function toHeaderFormat(key) {
    return key.replace(/([A-Z])/g, " $1").replace(/_/g, " ").replace(/^./, (str)=>str.toUpperCase()).trim();
}
// Generate columns dynamically from any data array passed in
function generateColumns(data) {
    if (!data || data.length === 0) {
        return [];
    }
    return Object.keys(data[0]).map((key)=>({
            id: key,
            header: toHeaderFormat(key),
            accessorKey: key
        }));
}
const DynamicTable = ({ data, showActions, paginationOptions, onPageChange, searchValue, onGlobalFilterChange, handleKeyDown, onPageSizeChange, onActionEvent, onNavigation, onPagination, onFileUpload, isImport })=>{
    _s();
    // const [globalFilter, setGlobalFilter] = useState("");
    // const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
    const columns = generateColumns(data);
    const table = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactTable"])({
        data: data,
        columns: showActions && data && data.length > 0 ? [
            ...columns,
            {
                id: "action",
                header: "Action"
            }
        ] : columns,
        // manualPagination: true,
        // onGlobalFilterChange: setGlobalFilter,
        // onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCoreRowModel"])(),
        getFilteredRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilteredRowModel"])(),
        getSortedRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSortedRowModel"])(),
        getPaginationRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPaginationRowModel"])(),
        // Custom filter UI for each column
        meta: {
            filterComponent: {
                "DynamicTable.useReactTable[table]": (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Table$2f$ColumnFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        column: props.column
                    }, void 0, false, {
                        fileName: "[project]/src/components/Table/Table.tsx",
                        lineNumber: 102,
                        columnNumber: 40
                    }, this)
            }["DynamicTable.useReactTable[table]"]
        }
    });
    const totalPages = Math.ceil((paginationOptions.totalCount ?? 0) / paginationOptions.pageSize);
    const [pagination, setPagination] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const handlePagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DynamicTable.useCallback[handlePagination]": ()=>{
            const totalCount = totalPages;
            const pageLimit = 5;
            const currentPage = paginationOptions.pageIndex + 1;
            const pages = [];
            const startPage = Math.max(currentPage - Math.floor(pageLimit / 2), 1);
            const endPage = Math.min(currentPage + Math.floor(pageLimit / 2), totalCount);
            if (startPage > 1) {
                pages.push(1);
                if (startPage > 2) pages.push("...");
            }
            for(let i = startPage; i <= endPage; i++){
                pages.push(i);
            }
            if (endPage < totalCount - 1) {
                pages.push("...");
            }
            if (endPage < totalCount) {
                pages.push(totalCount);
            }
            setPagination(pages);
        }
    }["DynamicTable.useCallback[handlePagination]"], [
        paginationOptions?.pageIndex,
        totalPages
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DynamicTable.useEffect": ()=>{
            handlePagination();
        }
    }["DynamicTable.useEffect"], [
        handlePagination
    ]);
    const commonTranslations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSLATIONS"].COMMON);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "data-table-common rounded-[10px] bg-white shadow-1 dark:bg-gray-dark dark:shadow-card",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between flex-wrap  gap-4 px-7.5 py-4.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-20 w-full max-w-[414px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                name: "search",
                                type: "text",
                                value: searchValue,
                                onChange: (e)=>onGlobalFilterChange(e.target.value),
                                onKeyDown: (e)=>handleKeyDown(e),
                                className: "w-full rounded-lg border border-stroke bg-transparent px-5 py-2.5 outline-none focus:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary",
                                placeholder: "Search here..."
                            }, void 0, false, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 151,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: handleKeyDown,
                                disabled: searchValue.trim() === "",
                                className: `absolute right-0 top-0 flex h-11.5 w-11.5 items-center justify-center rounded-r-md text-white 
            ${searchValue.trim() === "" ? "bg-gray-400 cursor-not-allowed" : "bg-primary"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$search$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__search$3e$__["search"],
                                    alt: "search",
                                    height: 20,
                                    width: 20,
                                    priority: true,
                                    unoptimized: true,
                                    className: "invert dark:invert-0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Table/Table.tsx",
                                    lineNumber: 172,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 161,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Table/Table.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-[10px] items-center",
                        children: [
                            table && table.getRowModel().rows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center font-medium",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "pl-2 font-medium text-dark dark:text-current",
                                        children: commonTranslations(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSLATIONS"].PERPAGE)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 186,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        name: "page-filter",
                                        id: "page-filter",
                                        value: table.getState().pagination.pageSize,
                                        onChange: (e)=>{
                                            const newSize = Number(e.target.value);
                                            table.setPageSize(newSize); // still update internal table if needed
                                            onPageSizeChange(newSize); // ✅ inform parent
                                        },
                                        className: "bg-transparent pl-2.5",
                                        children: [
                                            5,
                                            10,
                                            20,
                                            50
                                        ].map((pageSize)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: pageSize,
                                                children: pageSize
                                            }, pageSize, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 202,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 189,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 185,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "flex h-fit w-[70px] items-center justify-center rounded-[3px] p-[7px] bg-primary text-white",
                                onClick: onNavigation,
                                children: commonTranslations(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSLATIONS"].ADD)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 209,
                                columnNumber: 11
                            }, this),
                            isImport && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex h-fit w-[70px] items-center justify-center rounded-[3px] p-[7px] bg-primary text-white cursor-pointer",
                                children: [
                                    commonTranslations(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSLATIONS"].IMPORT),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileAcceptType"].CSV,
                                        onChange: onFileUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 218,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 216,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Table/Table.tsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Table/Table.tsx",
                lineNumber: 149,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between flex-wrap  overflow-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "datatable-table datatable-one !border-collapse px-4 md:px-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            className: "border-separate px-4",
                            children: table.getHeaderGroups().map((headerGroup)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: "border-t border-stroke dark:border-dark-3",
                                    children: headerGroup.headers.map((header)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "whitespace-nowrap",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex cursor-pointer items-center",
                                                    onClick: header.column.getToggleSortingHandler(),
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: header.column.id == "action" ? "" : "",
                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flexRender"])(header.column.columnDef.header, header.getContext())
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Table/Table.tsx",
                                                        lineNumber: 244,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Table/Table.tsx",
                                                    lineNumber: 240,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 239,
                                                columnNumber: 21
                                            }, this)
                                        }, header.id, false, {
                                            fileName: "[project]/src/components/Table/Table.tsx",
                                            lineNumber: 238,
                                            columnNumber: 19
                                        }, this))
                                }, headerGroup.id, false, {
                                    fileName: "[project]/src/components/Table/Table.tsx",
                                    lineNumber: 233,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/Table/Table.tsx",
                            lineNumber: 231,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: [
                                table.getRowModel().rows.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        colSpan: columns.length,
                                        className: "py-12 text-center",
                                        children: commonTranslations(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$translationConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRANSLATIONS"].NODATAFOUND)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 263,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Table/Table.tsx",
                                    lineNumber: 262,
                                    columnNumber: 15
                                }, this),
                                table.getRowModel().rows.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "border-t border-stroke dark:border-dark-3",
                                        children: row.getVisibleCells().filter((cell)=>showActions || cell.column.id !== "action").map((cell)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: `pr-5 lg:pr-7.5 2xl:pr-11 ${cell.column.id !== "action" ? "max-w-[200px] truncate whitespace-nowrap overflow-hidden text-ellipsis" : ""}`,
                                                children: cell.column.id === "action" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Table$2f$row$2e$actions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RowActions"], {
                                                    onActionEvent: onActionEvent,
                                                    id: row.original.id
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Table/Table.tsx",
                                                    lineNumber: 288,
                                                    columnNumber: 25
                                                }, this) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flexRender"])(cell.column.columnDef.cell, cell.getContext())
                                            }, cell.id, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 279,
                                                columnNumber: 21
                                            }, this))
                                    }, row.id, false, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 270,
                                        columnNumber: 15
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Table/Table.tsx",
                            lineNumber: 260,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Table/Table.tsx",
                    lineNumber: 230,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Table/Table.tsx",
                lineNumber: 229,
                columnNumber: 7
            }, this),
            table && table.getRowModel().rows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-evenly  flex-wrap gap-4 px-7.5 py-7",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>onPagination(false),
                                className: "disabled:pointer-events-none group flex items-center justify-center rounded-[3px] p-[7px] hover:bg-primary",
                                disabled: paginationOptions.pageIndex < 1,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronleft$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__chevronleft$3e$__["chevronleft"],
                                    alt: "search",
                                    height: 18,
                                    width: 18,
                                    priority: true,
                                    unoptimized: true,
                                    className: "invert-icon group-hover:invert"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Table/Table.tsx",
                                    lineNumber: 315,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 310,
                                columnNumber: 13
                            }, this),
                            pagination && pagination.length > 0 && pagination?.map((option, index)=>{
                                if (typeof option === "number") {
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>onPageChange(option - 1, paginationOptions.pageSize),
                                        className: `${paginationOptions.pageIndex === option - 1 ? "bg-primary text-white" : ""} mx-1 rounded px-4 py-2 hover:bg-primary hover:text-white`,
                                        children: option
                                    }, option, false, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 330,
                                        columnNumber: 21
                                    }, this);
                                } else {
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex item-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 350,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 351,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 352,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 353,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Table/Table.tsx",
                                                lineNumber: 354,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, `${option}__${index}`, true, {
                                        fileName: "[project]/src/components/Table/Table.tsx",
                                        lineNumber: 346,
                                        columnNumber: 21
                                    }, this);
                                }
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>onPagination(true),
                                className: "disabled:pointer-events-none group flex items-center justify-center rounded-[3px] p-[7px] hover:bg-primary",
                                disabled: paginationOptions.pageIndex + 1 === Math.ceil((paginationOptions.totalCount ?? 0) / paginationOptions.pageSize),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$icons$2f$chevronright$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__$3c$export__default__as__chevronright$3e$__["chevronright"],
                                    alt: "chevron right",
                                    height: 18,
                                    width: 18,
                                    priority: true,
                                    unoptimized: true,
                                    className: "invert-icon group-hover:invert"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Table/Table.tsx",
                                    lineNumber: 383,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Table/Table.tsx",
                                lineNumber: 372,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Table/Table.tsx",
                        lineNumber: 309,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-medium",
                        children: `Showing ${paginationOptions.pageIndex + 1} of ${Math.ceil((paginationOptions.totalCount ?? 0) / paginationOptions.pageSize)} pages`
                    }, void 0, false, {
                        fileName: "[project]/src/components/Table/Table.tsx",
                        lineNumber: 395,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Table/Table.tsx",
                lineNumber: 308,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Table/Table.tsx",
        lineNumber: 148,
        columnNumber: 5
    }, this);
};
_s(DynamicTable, "iWpb2NMGFaUKL180Ian5nOfCF/I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactTable"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = DynamicTable;
const __TURBOPACK__default__export__ = DynamicTable;
var _c;
__turbopack_context__.k.register(_c, "DynamicTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/api-endpoints.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "apiEndpoints": (()=>apiEndpoints)
});
const apiEndpoints = {
    login: '/auth/login',
    register: '/auth/register',
    page: "&page=",
    search_term: "search_terms=",
    page_size: "&page_size=",
    json: "&json="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/user/useDebounce.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function useDebounce(value, delay) {
    _s();
    const [debounceValue, setDebounceValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDebounce.useEffect": ()=>{
            const handler = setTimeout({
                "useDebounce.useEffect.handler": ()=>{
                    setDebounceValue(value);
                }
            }["useDebounce.useEffect.handler"], delay);
            return ({
                "useDebounce.useEffect": ()=>{
                    clearTimeout(handler);
                }
            })["useDebounce.useEffect"];
        }
    }["useDebounce.useEffect"], [
        value,
        delay
    ]);
    return debounceValue;
}
_s(useDebounce, "Q3hbc0lzckDV/fkfJLNfObsCD54=");
const __TURBOPACK__default__export__ = useDebounce;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/user/useUser.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useUser": (()=>useUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/config.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$api$2d$endpoints$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/api-endpoints.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$user$2f$useDebounce$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/user/useDebounce.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/enumConstants.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use cliennt";
;
;
;
;
;
const useUser = ()=>{
    _s();
    const [userData, setUserData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [totalCount, setTotalCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [searchData, setSearchData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [pageSize, setPageSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$enumConstants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageSizeEnum"].CASE2);
    const [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const debounceSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$user$2f$useDebounce$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(searchData, 1000);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useUser.useEffect": ()=>{
            const listData = {
                "useUser.useEffect.listData": async ()=>{
                    const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].userApi}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$api$2d$endpoints$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiEndpoints"].search_term}${debounceSearch}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$api$2d$endpoints$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiEndpoints"].page}${page}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$api$2d$endpoints$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiEndpoints"].page_size}${pageSize}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$api$2d$endpoints$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiEndpoints"].json}1`);
                    const data = await response.json();
                    setUserData(data.products.map({
                        "useUser.useEffect.listData": (user)=>({
                                id: user.id,
                                brands: user.brands,
                                code: user.code,
                                creator: user.creator
                            })
                    }["useUser.useEffect.listData"]));
                    setTotalCount(data.count);
                }
            }["useUser.useEffect.listData"];
            listData();
        }
    }["useUser.useEffect"], [
        debounceSearch,
        page,
        pageSize
    ]);
    return {
        userData,
        totalCount,
        setUserData,
        searchData,
        setSearchData,
        setPage,
        page,
        pageSize,
        setPageSize
    };
};
_s(useUser, "OC+rSdKRjmRn5p7ScHxAYT56qb4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$user$2f$useDebounce$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/user/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UserPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Table$2f$Table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Table/Table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$user$2f$useUser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/user/useUser.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function UserPage() {
    _s();
    const { userData, totalCount, page, searchData, setSearchData, setPage, pageSize, setPageSize } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$user$2f$useUser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Table$2f$Table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            data: userData,
            showActions: true,
            paginationOptions: {
                pageSize: pageSize,
                pageIndex: page - 1,
                totalCount: totalCount
            },
            onPageChange: (index, pageSize)=>{
                setPage(index + 1);
                setPageSize(pageSize);
            },
            searchValue: searchData,
            onGlobalFilterChange: (value)=>{
                setSearchData(value);
                setPage(1);
            },
            onPageSizeChange: (pageSize)=>{
                setPageSize(pageSize);
                setPage(1);
            },
            handleKeyDown: ()=>{},
            onActionEvent: ()=>{},
            onNavigation: ()=>{},
            onPagination: (pagination)=>{
                if (pagination) {
                    setPage(page + 1);
                } else {
                    setPage(page - 1);
                }
            }
        }, void 0, false, {
            fileName: "[project]/src/app/user/page.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(UserPage, "Z0TUauxNH8OYUsxvomZhP9AdRRA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$user$2f$useUser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"]
    ];
});
_c = UserPage;
var _c;
__turbopack_context__.k.register(_c, "UserPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_b9dbd0d1._.js.map