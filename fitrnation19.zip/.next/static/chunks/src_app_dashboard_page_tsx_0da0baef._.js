(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-apexcharts_dist_react-apexcharts_min_7f75768d.js",
  "static/chunks/_c84486c9._.js"
],
    source: "dynamic"
});
