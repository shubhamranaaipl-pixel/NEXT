export async function getDevicesUsedData(
  timeFrame?: "monthly" | "yearly" | (string & {})
) {
  // Fake delay
  await new Promise((resolve) => setTimeout(resolve, 1000));

  const data = [
    {
      name: "Desktop",
      percentage: 0.65,
      amount: 1625,
    },
    {
      name: "Tablet",
      percentage: 0.1,
      amount: 250,
    },
    {
      name: "Mobile",
      percentage: 0.2,
      amount: 500,
    },
    {
      name: "Unknown",
      percentage: 0.05,
      amount: 125,
    },
  ];

  if (timeFrame === "yearly") {
    data[0].amount = 19500;
    data[1].amount = 3000;
    data[2].amount = 6000;
    data[3].amount = 1500;
  }

  return data;
}

export async function getConversionData(
  timeFrame?: "monthly" | "yearly" | "weekly" | "days" | (string & {})
) {
  // Fake delay
  await new Promise((resolve) => setTimeout(resolve, 1000));

  if (timeFrame === "yearly") {
    return {
      received: [
        { x: 2020, y: 450 },
        { x: 2021, y: 620 },
        { x: 2022, y: 780 },
        { x: 2023, y: 920 },
        { x: 2024, y: 1080 },
      ],
      due: [
        { x: 2020, y: 1480 },
        { x: 2021, y: 1720 },
        { x: 2022, y: 1950 },
        { x: 2023, y: 2300 },
        { x: 2024, y: 1200 },
      ],
    };
  } else if (timeFrame === "weekly") {
    return {
      received: [
        { x: "Mo", y: 65 },
        { x: "Tu", y: 80 },
        { x: "We", y: 55 },
        { x: "Th", y: 70 },
        { x: "Fr", y: 90 },
        { x: "Sa", y: 40 },
        { x: "Su", y: 30 },
      ],
      due: [
        { x: "Mo", y: 45 },
        { x: "Tu", y: 90 },
        { x: "We", y: 75 },
        { x: "Th", y: 80 },
        { x: "Fr", y: 60 },
        { x: "Sa", y: 70 },
        { x: "Su", y: 77 },
      ],
    };
  } else if (timeFrame === "days") {
    return {
      received: [
        { x: "00:00", y: 5 },
        { x: "01:00", y: 8 },
        { x: "02:00", y: 6 },
        { x: "03:00", y: 7 },
        { x: "04:00", y: 9 },
        { x: "05:00", y: 4 },
        { x: "06:00", y: 3 },
        { x: "07:00", y: 10 },
        { x: "08:00", y: 0 },
        { x: "09:00", y: 0 },
        { x: "10:00", y: 0 },
        { x: "11:00", y: 0 },
        { x: "12:00", y: 0 },
        { x: "13:00", y: 0 },
        { x: "14:00", y: 0 },
        { x: "15:00", y: 0 },
        { x: "16:00", y: 0 },
        { x: "17:00", y: 0 },
        { x: "18:00", y: 0 },
        { x: "19:00", y: 0 },
        { x: "20:00", y: 0 },
        { x: "21:00", y: 0 },
        { x: "22:00", y: 0 },
        { x: "23:00", y: 0 },
      ],
      due: [
        { x: "00:00", y: 4 },
        { x: "01:00", y: 7 },
        { x: "02:00", y: 5 },
        { x: "03:00", y: 9 },
        { x: "04:00", y: 3 },
        { x: "05:00", y: 6 },
        { x: "06:00", y: 2 },
        { x: "07:00", y: 11 },
        { x: "08:00", y: 8 },
        { x: "09:00", y: 5 },
        { x: "10:00", y: 12 },
        { x: "11:00", y: 7 },
        { x: "12:00", y: 9 },
        { x: "13:00", y: 4 },
        { x: "14:00", y: 10 },
        { x: "15:00", y: 6 },
        { x: "16:00", y: 3 },
        { x: "17:00", y: 8 },
        { x: "18:00", y: 5 },
        { x: "19:00", y: 11 },
        { x: "20:00", y: 7 },
        { x: "21:00", y: 4 },
        { x: "22:00", y: 6 },
        { x: "23:00", y: 3 },
      ],
    };
  } else {
    return {
      received: [
        { x: "Jan", y: 0 },
        { x: "Feb", y: 20 },
        { x: "Mar", y: 35 },
        { x: "Apr", y: 45 },
        { x: "May", y: 35 },
        { x: "Jun", y: 55 },
        { x: "Jul", y: 65 },
        { x: "Aug", y: 50 },
        { x: "Sep", y: 65 },
        { x: "Oct", y: 75 },
        { x: "Nov", y: 60 },
        { x: "Dec", y: 75 },
      ],
      due: [
        { x: "Jan", y: 15 },
        { x: "Feb", y: 9 },
        { x: "Mar", y: 17 },
        { x: "Apr", y: 32 },
        { x: "May", y: 25 },
        { x: "Jun", y: 68 },
        { x: "Jul", y: 80 },
        { x: "Aug", y: 68 },
        { x: "Sep", y: 84 },
        { x: "Oct", y: 94 },
        { x: "Nov", y: 74 },
        { x: "Dec", y: 62 },
      ],
    };
  }
}

export async function getWeeklySignupsData(timeFrame?: string) {
  // Fake delay
  await new Promise((resolve) => setTimeout(resolve, 1000));
  if (timeFrame === "yearly") {
    return {
      received: [
        { x: 2020, y: 450 },
        { x: 2021, y: 620 },
        { x: 2022, y: 780 },
        { x: 2023, y: 920 },
        { x: 2024, y: 1080 },
      ],
      due: [
        { x: 2020, y: 1480 },
        { x: 2021, y: 1720 },
        { x: 2022, y: 1950 },
        { x: 2023, y: 2300 },
        { x: 2024, y: 1200 },
      ],
    };
  } else if (timeFrame === "weekly") {
    return {
      received: [
        { x: "Mo", y: 65 },
        { x: "Tu", y: 80 },
        { x: "We", y: 55 },
        { x: "Th", y: 70 },
        { x: "Fr", y: 90 },
        { x: "Sa", y: 40 },
        { x: "Su", y: 30 },
      ],
      due: [
        { x: "Mo", y: 45 },
        { x: "Tu", y: 90 },
        { x: "We", y: 75 },
        { x: "Th", y: 80 },
        { x: "Fr", y: 60 },
        { x: "Sa", y: 70 },
        { x: "Su", y: 77 },
      ],
    };
  } else if (timeFrame === "days") {
    return {
      received: [
        { x: "00:00", y: 5 },
        { x: "01:00", y: 8 },
        { x: "02:00", y: 6 },
        { x: "03:00", y: 7 },
        { x: "04:00", y: 9 },
        { x: "05:00", y: 4 },
        { x: "06:00", y: 3 },
        { x: "07:00", y: 10 },
        { x: "08:00", y: 0 },
        { x: "09:00", y: 0 },
        { x: "10:00", y: 0 },
        { x: "11:00", y: 0 },
        { x: "12:00", y: 0 },
        { x: "13:00", y: 0 },
        { x: "14:00", y: 0 },
        { x: "15:00", y: 0 },
        { x: "16:00", y: 0 },
        { x: "17:00", y: 0 },
        { x: "18:00", y: 0 },
        { x: "19:00", y: 0 },
        { x: "20:00", y: 0 },
        { x: "21:00", y: 0 },
        { x: "22:00", y: 0 },
        { x: "23:00", y: 0 },
      ],
      due: [
        { x: "00:00", y: 4 },
        { x: "01:00", y: 7 },
        { x: "02:00", y: 5 },
        { x: "03:00", y: 9 },
        { x: "04:00", y: 3 },
        { x: "05:00", y: 6 },
        { x: "06:00", y: 2 },
        { x: "07:00", y: 11 },
        { x: "08:00", y: 8 },
        { x: "09:00", y: 5 },
        { x: "10:00", y: 12 },
        { x: "11:00", y: 7 },
        { x: "12:00", y: 9 },
        { x: "13:00", y: 4 },
        { x: "14:00", y: 10 },
        { x: "15:00", y: 6 },
        { x: "16:00", y: 3 },
        { x: "17:00", y: 8 },
        { x: "18:00", y: 5 },
        { x: "19:00", y: 11 },
        { x: "20:00", y: 7 },
        { x: "21:00", y: 4 },
        { x: "22:00", y: 6 },
        { x: "23:00", y: 3 },
      ],
    };
  } else {
    return {
      received: [
        { x: "Jan", y: 0 },
        { x: "Feb", y: 20 },
        { x: "Mar", y: 35 },
        { x: "Apr", y: 45 },
        { x: "May", y: 35 },
        { x: "Jun", y: 55 },
        { x: "Jul", y: 65 },
        { x: "Aug", y: 50 },
        { x: "Sep", y: 65 },
        { x: "Oct", y: 75 },
        { x: "Nov", y: 60 },
        { x: "Dec", y: 75 },
      ],
      due: [
        { x: "Jan", y: 15 },
        { x: "Feb", y: 9 },
        { x: "Mar", y: 17 },
        { x: "Apr", y: 32 },
        { x: "May", y: 25 },
        { x: "Jun", y: 68 },
        { x: "Jul", y: 80 },
        { x: "Aug", y: 68 },
        { x: "Sep", y: 84 },
        { x: "Oct", y: 94 },
        { x: "Nov", y: 74 },
        { x: "Dec", y: 62 },
      ],
    };
  }
}
