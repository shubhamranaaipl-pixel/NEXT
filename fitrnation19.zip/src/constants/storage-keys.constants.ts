export const storageKeys = {
    session:'session'
}