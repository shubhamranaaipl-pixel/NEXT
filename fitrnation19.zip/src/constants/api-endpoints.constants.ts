export const apiEndpoints = {
    login: '/auth/login',
    register: '/auth/register',
    page:"&page=",
    search_term:"search_terms=",
    page_size:"&page_size=",
    json:"&json="

}   