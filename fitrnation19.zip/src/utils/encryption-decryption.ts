import crypto from "crypto";

export const processEncryption = (value: string, isDecode?: boolean) => {
  if (value == null || value == undefined || value == "") {
    return value;
  }
  const key = Buffer.from(
    process.env.NEXT_PUBLIC_ENCRYPTION_KEY ?? "",
    "base64"
  );
  const iv = Buffer.from(
    process.env.NEXT_PUBLIC_ENCRYPTION_IV_KEY ?? "",
    "base64"
  );

  if (!isDecode) {
    const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
    let encrypted = cipher.update(value, "utf-8", "base64");
    encrypted += cipher.final("base64");
    return encrypted;
  } else {
    const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
    let decrypted = decipher.update(value, "base64", "utf-8");
    decrypted += decipher.final("utf-8");
    return decrypted;
  }
};