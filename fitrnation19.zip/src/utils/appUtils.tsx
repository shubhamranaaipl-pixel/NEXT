export const formatCurrency = (amount: number, currencySymbol = "£"): string => {
  const formattedAmount = new Intl.NumberFormat("en-GB", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
  return `${currencySymbol}${formattedAmount}`;
};

// Define a type that extracts keys from an interface and maps them.toLocaleDateString() their own values
export type EnumFromInterface<T> = Required<{
  [K in keyof T]: K;
}>;

/**
 * Represents an object with string keys and values that can be either numbers or strings.
 * This interface is used to define the type of the `data` parameter in the `app utils`.
 */
interface OptionsType {
  [key: string]: number | string;
}

type SelectOption = { value: string | number; label: string };

export function getDropdownOptions(
  data: OptionsType,
  value?: (string | number)[]
): SelectOption[] {
  const options: SelectOption[] = [];

  for (const key in data) {
    if (isNaN(Number(key))) {
      const optionValue = data[key];
      if (!value || !value.includes(optionValue)) {
        options.push({
          label: toCamelCase(key), // Use translation key directly
          value: optionValue,
        });
      }
    }
  }

  return options;
}

/**
 *
 * @param inputString u
 * @returns
 */
export function toCamelCase(inputString: string): string {
  const words = inputString.toLowerCase().split("_");
  return words
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}


export function formatDate(dateString: string) {
  const date = new Date(dateString);

  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
    // timeZone: 'UTC',
  }).format(date);
}