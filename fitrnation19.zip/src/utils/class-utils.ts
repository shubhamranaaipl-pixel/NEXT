import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { Dispatch, SetStateAction } from "react";


export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function compactFormat(value: number) {
  const formatter = new Intl.NumberFormat("en", {
    notation: "compact",
    compactDisplay: "short",
  });

  return formatter.format(value);
}


export function standardFormat(value: number) {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export type SetStateActionType<T> = Dispatch<SetStateAction<T>>;
