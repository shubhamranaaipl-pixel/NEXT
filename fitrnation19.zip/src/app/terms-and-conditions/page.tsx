'use client';
import HtmlEditor from "@/components/ui/HtmlEditor/HtmlEditor";
import { useInformation } from "../privacy-policy/useInformation";
import { Fragment } from "react";
import { TRANSLATIONS } from "@/constants/translationConstants";
import { useTranslations } from "next-intl";


const TermAndConditionPage = () => {
    const {
        isHtmlValue,
        handleEditorContent,
        handleCreateInformation
    } = useInformation();
  const commonTranslations=useTranslations(TRANSLATIONS.COMMON)

    return (
        <Fragment>
            <HtmlEditor isDefaultValue={isHtmlValue} onContentChange={handleEditorContent} />
            <div className="block h-fit items-center justify-end w-full mt-10 sm:flex">
                <button className="flex w-full sm:w-60 h-fit items-center justify-center rounded-[3px] p-[7px] bg-primary text-white" onClick={handleCreateInformation}>{commonTranslations(TRANSLATIONS.SUBMIT)}</button>
            </div>
        </Fragment>
    )
}


export default TermAndConditionPage;