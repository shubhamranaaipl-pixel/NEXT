"use client";
import { useEffect, useState } from "react";
import { compactFormat } from "@/utils/class-utils";
import { viewicon, profileicon, producticon, usersicon } from "@/assets/icons/index";
import { DashboardCard } from "./cards";
import { getOverviewData } from "../../fetch";
import { useTranslations } from "next-intl";
import { TRANSLATIONS } from "@/constants/translationConstants";


export function DashboardCardsGroup({
  initialData,
}: {
  initialData: Awaited<ReturnType<typeof getOverviewData>>;
}) {
  const [data, setData] = useState(initialData);
  const dashboardTranslation = useTranslations(TRANSLATIONS.DASHBOARD);

  useEffect(() => {   // Calling this method, if data is changed
    const getData = async () => {
      const fetchedData = await getOverviewData();
      setData(fetchedData);
    };
    getData();
  }, []);

  const { views, profit, products, users } = data;

  return (
    <div className="grid gap-4 sm:grid-cols-2 sm:gap-6 xl:grid-cols-4 2xl:gap-7.5">
      <DashboardCard
        label={dashboardTranslation(TRANSLATIONS.TOTALVIEWS)}
        data={{
          ...views,
          value: compactFormat(views.value),
        }}
        Icon={viewicon}
      />

      <DashboardCard
        label={dashboardTranslation(TRANSLATIONS.TOTALPROFIT)}
        data={{
          ...profit,
          value:  "$" + compactFormat(profit.value),
        }}
        Icon={profileicon}
      />  

      <DashboardCard
        label={dashboardTranslation(TRANSLATIONS.TOTALTRAINER)}
        data={{
          ...products,
          value: compactFormat(products.value),
        }}
        Icon={producticon}
      />

      <DashboardCard
        label={dashboardTranslation(TRANSLATIONS.TOTALUSERS)}
        data={{
          ...users,
          value: compactFormat(users.value),
        }}
        Icon={usersicon}
      />
    </div>
  );
}
