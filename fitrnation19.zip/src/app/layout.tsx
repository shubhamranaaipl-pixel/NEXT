import "@/css/satoshi.css";
import "@/css/simple-datatables.css";
import "dropzone/dist/dropzone.css";
import "flatpickr/dist/flatpickr.min.css";
import "jsvectormap/dist/jsvectormap.css";
import "nouislider/dist/nouislider.css";

import "@/css/style.css";
import type { Metadata } from "next";
import NextTopLoader from "nextjs-toploader";
import type { PropsWithChildren } from "react";
import { Providers } from "./providers";
import { Geist, Geist_Mono } from "next/font/google";
import Header from "@/components/Header/Header";
import { Sidebar } from "@/components/sidebar";
import { SidebarProvider } from "@/components/sidebar/sidebar-context";
import { AuthContextProvider } from "@/context/AuthContext";
import { LoadingContextProvider } from "@/context/LoadingContext";
import { ApolloWrapper } from "@/graphql/ApolloContext";
import { Toaster } from "react-hot-toast";
import { getMessages } from "next-intl/server";
import { NextIntlClientProvider } from "next-intl";
import Loading from "@/components/Loading";
import Layout from "@/components/Layout/Layout";
import { ModalProvider } from "@/context/ModalContext";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    template: "%s | Fitr Nation",
    default: "Fitr Nation",
  },
  description:
    "",
};
// const locale = await getLocale();
// Providing all messages to the client
// side is the easiest way to get started
const messages = await getMessages();
export default function RootLayout({ children }: PropsWithChildren) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <Providers>
          <LoadingContextProvider>
            <ApolloWrapper>
              <AuthContextProvider>
                <Toaster />
                <NextIntlClientProvider messages={messages}>
                  <SidebarProvider>
                    <div className="flex min-h-screen">
                      <Loading />
                      <Sidebar />
                      <div className="w-full bg-gray-2 dark:bg-[#020d1a]">
                        <Header />
                        <main className="mx-auto w-full max-w-screen-2xl overflow-hidden p-4 md:p-6 2xl:p-10">
                          <NextTopLoader color="#904BE6" showSpinner={false} />
                          <Layout>
                            <ModalProvider>
                              {children}
                            </ModalProvider>
                          </Layout>
                        </main>
                      </div>
                    </div>
                  </SidebarProvider>
                </NextIntlClientProvider>
              </AuthContextProvider>
            </ApolloWrapper>
          </LoadingContextProvider>
        </Providers>
      </body>
    </html>
  );
}
