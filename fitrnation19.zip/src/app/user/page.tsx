"use client";
import DynamicTable from "@/components/Table/Table";
import { useUser } from "./useUser";


export default function UserPage() {
  const {
    userData,
    totalCount,
    page,
    searchData,
    setSearchData,
    setPage,
    pageSize,
    setPageSize,
  } = useUser();



  return (
    <>
  
      <DynamicTable
        data={userData}
        showActions={true}
        paginationOptions={{  
          pageSize: pageSize,
          pageIndex: page - 1,
          totalCount: totalCount,
        }}
        onPageChange={(index, pageSize) => {
          setPage(index + 1);
          setPageSize(pageSize);
        }}
        searchValue={searchData}
        onGlobalFilterChange={(value) => {
          setSearchData(value);
          setPage(1);
        }}
        onPageSizeChange={(pageSize) => {
          setPageSize(pageSize);
          setPage(1);
        }}
        handleKeyDown={() => {}}
        onActionEvent={() => {}}
        onNavigation={() => {}}
        onPagination={(pagination: boolean) => {
          if (pagination) {
            setPage(page + 1);
          } else {
            setPage(page - 1);
          }
        }}
      />
    </>
  );
}
