"use cliennt";

import { useState, useEffect } from "react";
import config from "@/config/config";
import { apiEndpoints } from "@/constants/api-endpoints.constants";
import useDebounce from "./useDebounce";
import { PageSizeEnum } from "@/constants/enumConstants";

export interface Products {
  id: number;
  brands: string;
  code: string;
  creator: string;
}

export interface IUser {
  count?: number;
  page?: number;
  page_count: number;
  page_size: number;
  products: Products[];
}

export const useUser = () => {
  const [userData, setUserData] = useState<IUser[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [searchData, setSearchData] = useState<string>("");
  const [pageSize, setPageSize] = useState<number>(PageSizeEnum.CASE2);
  const [page, setPage] = useState<number>(1);

  const debounceSearch = useDebounce(searchData, 1000);
  useEffect(() => {
    const listData = async () => {
      const response = await fetch(
        `${config.userApi}${apiEndpoints.search_term}${debounceSearch}${apiEndpoints.page}${page}${apiEndpoints.page_size}${pageSize}${apiEndpoints.json}1`
      );
      const data = await response.json();

      setUserData(
        data.products.map((user: Products) => ({
          id: user.id,
          brands: user.brands,
          code: user.code,
          creator: user.creator,
        }))
      );
      setTotalCount(data.count);
    };
    listData();
  }, [debounceSearch, page, pageSize]);

  return {
    userData,
    totalCount,
    setUserData,
    searchData,
    setSearchData,
    setPage,
    page,
    pageSize,
    setPageSize,
  };
};
