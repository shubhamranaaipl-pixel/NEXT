import { MessageResponse } from "@/modules/common/models/commonModels";

export interface UserRoleModel {
  id: number;
  name: string;
}

export interface UsersModel {
  id: number;
  full_name: string;
  profile_name: string;
  mobile: string | null;
  email: string;
  role: UserRoleModel[];
  access_token: string;
  refresh_token: string;
  provider: string;
  created_at: string;
}

export class AdminLoginModel {
  adminLogin?: UsersModel;
}

export class RegisterModel {
  register?: UsersModel;
}

export class AdminLogoutModel {
  adminLogout?: MessageResponse;
}

export class AdminSendOtpResponseModel {
  adminSendOtp?: MessageResponse;
}

export class AdminChangePasswordResponseModel {
  changePassword?: MessageResponse;
}

export class AdminForgetPasswordResponseModel {
  forgetPassword?: MessageResponse;
}

export class ForgotResponseModelEntity {
  forgetPassword?: MessageResponse;
}

export class verifyOtpResponseModelEntity {
  verifyOtp?: MessageResponse;
}

export class sendOtpResponseModelEntity {
  sendOtp?: MessageResponse;
}
