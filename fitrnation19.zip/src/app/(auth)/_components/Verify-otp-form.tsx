"use client";

import { Fragment } from "react";
import { Controller } from "react-hook-form";
import { otpFormInputs } from "@/app/(auth)/_form-schema/Auth-form-schema";
import { useAuthState } from "@/app/(auth)/useAuthState";
import ButtonForm from "@/app/(auth)/_components/Button-form";

const OTPInput = () => {
  const {
    isLoading,
    onVerifyOtpSubmit,
    otpControl,
    handleOtpSubmit,
    otpErrors,
    handleInput,
    handleKeyDown,
    inputRefs,
    inputBoxes,
    commonTranslation,
    TRANSLATIONS
  } = useAuthState();


  return (
    <Fragment>
      <h2 className="text-2xl font-semibold mb-2 text-dark dark:text-white">
       {commonTranslation(TRANSLATIONS.ENTEROTP)}
      </h2>
      <form onSubmit={handleOtpSubmit(onVerifyOtpSubmit)}>
        <div className="flex justify-start space-x-10 mb-6">
          {inputBoxes.map((i) => (
            <Controller
              key={i}
              name={`otp${i}` as keyof otpFormInputs}
              control={otpControl}
              defaultValue=""
              render={({ field }) => (
                <input
                  {...field}
                  maxLength={1}
                  type="text"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  ref={(el) => {
                    inputRefs.current[i] = el;
                    field.ref(el); // set react-hook-form ref
                  }}
                  className="w-12 h-12 text-center border border-gray-300 rounded-md text-xl focus:border-primary"
                  onChange={(e) => {
                    handleInput(e, i);
                  }}
                  onBlur={field.onBlur}
                  onKeyDown={(e) => handleKeyDown(e, i)}
                />
              )}
            />
          ))}
        </div>

        {Object.values(otpErrors).some((error) => error?.message) &&
          (otpErrors.otp0 && (
            <p className="text-red-500 text-sm mb-2">{otpErrors.otp0.message}</p>
          )
            ||
            otpErrors.otp1 && (
              <p className="text-red-500 text-sm mb-2">{otpErrors.otp1.message}</p>
            ) ||
            otpErrors.otp2 && (
              <p className="text-red-500 text-sm mb-2">{otpErrors.otp2.message}</p>
            ) ||
            otpErrors.otp3 && (
              <p className="text-red-500 text-sm mb-2">{otpErrors.otp3.message}</p>
            )
          )


        }
        <ButtonForm buttonText={commonTranslation(TRANSLATIONS.VERIFY)} isLoading={isLoading} />
      </form>
    </Fragment>
  );
};

export default OTPInput;
