"use client";
import Input from "@/components/Input/Input";
import { Controller } from "react-hook-form";
import { useAuthState } from "@/app/(auth)/useAuthState";
import ButtonForm from "@/app/(auth)/_components/Button-form";

const LoginForm = () => {
  const {
    isLoading,
    onLoginSubmit,
    loginControl,
    handleLoginSubmit,
    loginErrors,
    handleNavigation,
    commonTranslation,
    TRANSLATIONS
  } = useAuthState();

  return (
    <form onSubmit={handleLoginSubmit(onLoginSubmit)}>
      <Controller
        name="email"
        control={loginControl}
        defaultValue=""
        render={({ field }) => (
          <Input
            {...field}
            type="input"
            handleChange={field.onChange}
            onBlur={field.onBlur}
            label={commonTranslation(TRANSLATIONS.EMAIL)}
            className="mb-4 [&_input]:py-[15px]"
            placeholder={commonTranslation(TRANSLATIONS.ENTERYOUREMAILADDRESS)}
            error={loginErrors.email ? loginErrors.email.message : ''}
          />
        )}
      />
      <Controller
        name="password"
        control={loginControl}
        defaultValue=""
        render={({ field }) => (
          <Input
            {...field}
            type="password"
            label={commonTranslation(TRANSLATIONS.PASSWORD)}
            handleChange={field.onChange}
            onBlur={field.onBlur}
            className="mb-5 [&_input]:py-[15px]"
            placeholder={commonTranslation(TRANSLATIONS.ENTERYOURPASSWORD)}
            error={loginErrors.password ? loginErrors.password.message : ''}
          />
        )}
      />
      <div className="mb-6 flex justify-end gap-2 py-2 font-medium">
        <div
          onClick={() => handleNavigation("/forgot-password")}
          className="hover:text-primary dark:text-white dark:hover:text-primary cursor-pointer"
        >
          {commonTranslation(TRANSLATIONS.FORGETPASSWORD)}?
        </div>
      </div>
      <ButtonForm buttonText={commonTranslation(TRANSLATIONS.SIGNIN)} isLoading={isLoading} />
    </form>
  );
};

export default LoginForm;
