

interface ButtonFormProps {
    isLoading: boolean;
    buttonText: string;
}

const ButtonForm: React.FC<ButtonFormProps> = ({ isLoading, buttonText }) => {
    return (
        <div className="mb-4.5">
            <button
                disabled={isLoading}
                type="submit"
                className={`flex w-full items-center justify-center gap-2 rounded-lg p-4 font-medium text-white transition hover:bg-opacity-90 ${isLoading ? "bg-secondary" : "bg-primary"
                    }`}
            >
                {buttonText}
            </button>
        </div>
    );
}

export default ButtonForm;