"use client";

import Input from "@/components/Input/Input";
import { Controller } from "react-hook-form";
import { useAuthState } from "@/app/(auth)/useAuthState";
import ButtonForm from "@/app/(auth)/_components/Button-form";

const ChangePasswordFormPage = () => {
  const {
    isLoading,
    onChangePasswordSubmit,
    changePasswordControl,
    handleChangePasswordSubmit,
    changePasswordErrors,
    commonTranslation,
    TRANSLATIONS
  } = useAuthState();

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2 text-dark dark:text-white">
          {commonTranslation(TRANSLATIONS.CHANGEYOURPASSWORD)}
        </h2>
      </div>
      <form onSubmit={handleChangePasswordSubmit(onChangePasswordSubmit)}>
        <Controller
          name="old_password"
          control={changePasswordControl}
          defaultValue=""
          render={({ field }) => (
            <Input
              {...field}
              type="password"
              handleChange={field.onChange}
              onBlur={field.onBlur}
              label={commonTranslation(TRANSLATIONS.OLDPASSWORD)}
              className="mb-4 [&_input]:py-[15px]"
              placeholder={commonTranslation(TRANSLATIONS.ENTERYOUROLDPASSWORD)}
              error={changePasswordErrors.old_password ? changePasswordErrors.old_password.message : ''}
            />
          )}
        />
        <Controller
          name="new_password"
          control={changePasswordControl}
          defaultValue=""
          render={({ field }) => (
            <Input
              {...field}
              type="password"
              handleChange={field.onChange}
              onBlur={field.onBlur}
              label={commonTranslation(TRANSLATIONS.NEWPASSWORD)}
              className="mb-4 [&_input]:py-[15px]"
              placeholder={commonTranslation(TRANSLATIONS.ENTERNEWPASSWORD)}
              error={changePasswordErrors.new_password ? changePasswordErrors.new_password.message : ''}
            />
          )}
        />
        <Controller
          name="confirm_password"
          control={changePasswordControl}
          defaultValue=""
          render={({ field }) => (
            <Input
              {...field}
              type="password"
              handleChange={field.onChange}
              onBlur={field.onBlur}
              label={commonTranslation(TRANSLATIONS.CONFIRMPASSWORD)}
              className="mb-4 [&_input]:py-[15px]"
              placeholder={commonTranslation(TRANSLATIONS.ENTERYOURCONFIRMPASSWORD)}
              error={changePasswordErrors.confirm_password ? changePasswordErrors.confirm_password.message : ''}
            />
          )}
        />
        <ButtonForm buttonText={commonTranslation(TRANSLATIONS.CHANGEPASSWORD)} isLoading={isLoading} />
      </form>
    </div>
  );
};

export default ChangePasswordFormPage;
