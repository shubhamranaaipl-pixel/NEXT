import {
  ApolloClient,
  ApolloError,
  ApolloQueryResult,
  DocumentNode,
  FetchResult,
  OperationVariables,
  TypedDocumentNode,
} from "@apollo/client";
import { LocalStorageKeysEnum } from "@/constants/enumConstants";
import { UNAUTH_EVENT } from "@/constants/serviceConstants";
import { dispatchCustomEvent } from "@/services/eventBus";
import { GraphQLError, GraphQLFormattedError } from "graphql";
import { Error } from "@/modules/common/models/graphQLModel";
import { showErrorToast } from "@/utils/toastUtils";
export class ApolloService {
  /**
   *
   * @param client
   * @param query
   * @param successCallBack
   * @param errorcallback
   */
  queryApollo(
    client: ApolloClient<object>,
    query: DocumentNode | TypedDocumentNode<unknown, OperationVariables>,
    successCallBack: (_response: ApolloQueryResult<unknown>) => void,
    errorcallback: (
      _response:
        | (ApolloError | GraphQLError | GraphQLFormattedError)
        | undefined
    ) => void
  ): void {
    client
      .query({
        query,
      })
      .then((res: ApolloQueryResult<unknown>) => {
        const unauthenticated = this.handleUnauthorizedUser(client, res);
        if (unauthenticated) {
          errorcallback(
            res.error ? res.error : (res.errors && res.errors[0]) ?? undefined
          );
        } else {
          successCallBack(res);
          
        }
      })
      .catch((err) => {
        if (err?.graphQLErrors?.[0]) {
          this. handleApiErrorsToast(err?.graphQLErrors?.[0]);
        }

        errorcallback(err.error);
        this.handleUnauthorizedUser(client, err);
      });
  }
  handleUnauthorizedUser = (
    client: ApolloClient<object>,
    response: ApolloQueryResult<unknown> | FetchResult<unknown> | any
  ): boolean => {
   
    let unauthenticated = false;
    try {
      const errorResponseModel = response?.errors?.[0] as Error;

      if (errorResponseModel?.extensions?.response?.statusCode === 401) {
        unauthenticated = true;
      }

      if (unauthenticated) {
        // TODO need to handle unauth case
        localStorage.removeItem(LocalStorageKeysEnum.TOKEN_DATA);
        localStorage.removeItem(LocalStorageKeysEnum.ROLE);
        dispatchCustomEvent(UNAUTH_EVENT, {});
      }
    } catch (e) {
      console.error(e);
    }

    try {
      const errorResponseModel = response?.graphQLErrors?.[0] as Error;

      if (errorResponseModel?.extensions?.response?.statusCode === 401) {
        unauthenticated = true;
      }

      if (unauthenticated) {
        // TODO need to handle unauth case
        localStorage.removeItem(LocalStorageKeysEnum.TOKEN_DATA);
        localStorage.removeItem(LocalStorageKeysEnum.ROLE);
        dispatchCustomEvent(UNAUTH_EVENT, {});
      }
    } catch (e) {
      console.error(e);
    }

    return unauthenticated;
  };

  /**
   *
   * @param client
   * @param query
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
  queryApolloWithVariables(
    client: ApolloClient<object>,
    query: DocumentNode | TypedDocumentNode<unknown, OperationVariables>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: ApolloQueryResult<unknown>) => void,
    errorcallback: (
      _response:
        | (ApolloError | GraphQLError | GraphQLFormattedError)
        | undefined
    ) => void
  ): void {
    client
      .query({
        query,
        variables,
      })
      .then((res: ApolloQueryResult<unknown>) => {
        const unauthenticated = this.handleUnauthorizedUser(client, res);
        if (unauthenticated) {
          errorcallback(
            res.error ? res.error : (res.errors && res.errors[0]) ?? undefined
          );
        } else {
          successCallBack(res);
          
        }
      })
      .catch((err) => {
        if (err?.graphQLErrors?.[0]) {
          this. handleApiErrorsToast(err?.graphQLErrors?.[0]);
        }
        errorcallback(err.error);
        this.handleUnauthorizedUser(client, err);
      });
  }

 handleApiErrorsToast = (error: unknown): void => {
    const errorModelResponse = error as Error;
    showErrorToast(`${errorModelResponse.extensions?.response?.message}`);
};

  /**
   * used for mutation
   * @param client
   * @param mutation
   * @param variables
   * @param successCallBack
   * @param errorcallback
   */
  mutateApollo(
    client: ApolloClient<object>,
    mutation: DocumentNode | TypedDocumentNode<unknown, OperationVariables>,
    variables: OperationVariables | undefined,
    successCallBack: (_response: FetchResult<unknown>) => void,
    errorcallback: (
      _response:
        | (GraphQLError | GraphQLFormattedError | ApolloError)
        | undefined
    ) => void
  ): void {
    client
      .mutate({
        mutation,
        variables,
      })
      .then((res: FetchResult<unknown>) => {
        const unauthenticated = this.handleUnauthorizedUser(client, res);
        if (unauthenticated) {
          errorcallback(res.errors ? res.errors[0] : undefined);
        } else {
          successCallBack(res);
          
        }
      })
      .catch((err) => {
        if (err?.graphQLErrors?.[0]) {
          this. handleApiErrorsToast(err?.graphQLErrors?.[0]);
        }
        errorcallback(err);
        this.handleUnauthorizedUser(client, err);
      });
  }

  /**
   *
   * @param client
   * @param mutation
   * @param successCallBack
   * @param errorcallback
   */
  mutateApolloWithoutVariables(
    client: ApolloClient<object>,
    mutation: DocumentNode | TypedDocumentNode<unknown, OperationVariables>,
    successCallBack: (_response: ApolloQueryResult<unknown>) => void,
    errorcallback: (
      _response:
        | (ApolloError | GraphQLError | GraphQLFormattedError)
        | undefined
    ) => void
  ): void {
    client
      .mutate({
        mutation,
      })
      .then((res: FetchResult<unknown>) => {
        const unauthenticated = this.handleUnauthorizedUser(client, res);
        if (unauthenticated) {
          errorcallback(res.errors ? res.errors[0] : undefined);
        } else {
          successCallBack(res as ApolloQueryResult<unknown>);
          
        }
      })
      .catch((err) => {
        if (err?.graphQLErrors?.[0]) {
          this. handleApiErrorsToast(err?.graphQLErrors?.[0]);
        }
        errorcallback(err);
        this.handleUnauthorizedUser(client, err);
      });
  }
}
