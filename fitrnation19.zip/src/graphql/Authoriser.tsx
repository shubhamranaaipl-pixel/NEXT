import { ApolloClient, HttpLink, InMemoryCache } from "@apollo/client";
import config from "@/config/config";
import { LocalStorageKeysEnum } from "@/constants/enumConstants";
import gql from "graphql-tag";
import { compareAsc } from "date-fns";
import { jwtDecode } from "jwt-decode";

interface TokenData {
  accessToken: string;
  refreshToken: string;
}

/**
 * Auth Refresh Token
 * @param refresh
 * @returns
 */
const refreshAuthToken = async (refresh: string, devideID?: string): Promise<string> => {
  try {
    const graphQLUrl = config.graphQlUrl ? `${config.graphQlUrl}` : "";

    const httpLink = new HttpLink({
      uri: graphQLUrl,
      fetch: async (uri, options) => {
        const updatedOptions = {
          ...options,
          headers: {
            ...options?.headers,
            Authorization: `Bearer ${refresh}`,
          },
        };
        return fetch(uri, updatedOptions);
      },
    });
    const cache = new InMemoryCache();
    const client = new ApolloClient({
      link: httpLink,
      cache,
    });

    // In this case, our refreshToken function is being called simultaneously.
    // However, client.mutate() executes sequentially because it uses await.
    // We handle the unauthenticated case by checking in the catch block.
    // We retrieve the token data from local storage and compare the refresh token to see if it has changed.
    // If the refresh token is different, it means a new one has already been saved.
    // In that scenario, we return the new access token.
    const newToken = await client
      .mutate({
        mutation: gql`
         mutation refreshTokens($deviceId: String!) {
          refreshTokens(device_id: $deviceId) {
            access_token
            refresh_token
          }
        }
      `,
        variables: { deviceId: devideID }
      })
      .then(async (res) => {
        const tokenDataRefresh = {
          accessToken: res.data.refreshTokens.access_token,
          refreshToken: res.data.refreshTokens.refresh_token,
        };

        localStorage.setItem(
          LocalStorageKeysEnum.TOKEN_DATA,
          JSON.stringify(tokenDataRefresh)
        );

        return tokenDataRefresh.accessToken;
      })
      .catch(async () => {
        const tokenData: TokenData = JSON.parse(
          localStorage.getItem(LocalStorageKeysEnum.TOKEN_DATA) || ""
        );

        if (
          tokenData &&
          tokenData.refreshToken.toLowerCase() !== refresh.toLowerCase()
        ) {
          return tokenData.accessToken;
        }

        return "";
      });

    return newToken;
  } catch (error) {
    if (error instanceof Error) {
    }
    return "";
  }
};

/**
 * Get Authorization
 * @returns
 */
export default async function Authorization(): Promise<string | null> {
  const token = localStorage.getItem(LocalStorageKeysEnum.TOKEN_DATA);
  const device_id = sessionStorage.getItem(LocalStorageKeysEnum.DEVICE_ID);
  // get current tokens
  let tokenData: TokenData | undefined = undefined;

  if (token) {
    tokenData = JSON.parse(token);
  }
  // if no tokens, return null
  if (!tokenData) {
    return null;
  }
  // decode auth token
  const { accessToken } = tokenData;
  const decoded = jwtDecode(accessToken);
  // check if expired
  const gracePeriod = 2 * 60; // 2 minutes grace period for logging in just before it expires
  const decodedDate = new Date(((decoded.exp ?? 0) - gracePeriod) * 1000);

  const expired = compareAsc(decodedDate, new Date()) === -1;

  if (expired) {
    const refreshTokenData = tokenData.refreshToken;

    const newAuthToken = await refreshAuthToken(refreshTokenData, device_id ?? undefined);

    if (newAuthToken === "") {

      localStorage.removeItem(LocalStorageKeysEnum.TOKEN_DATA);
      localStorage.removeItem(LocalStorageKeysEnum.ROLE);
    }
    return newAuthToken;
  }

  return accessToken;
}
