"use client";

import { MANUAL_LOADING_HIDE, MANUAL_LOADING_SHOW } from "@/constants/serviceConstants";
import { eventBus } from "@/services/eventBus";
import React, {
  createContext,
  ReactNode,
  useContext,
  useState,
  useCallback,
  useEffect,
} from "react";

interface LoadingContextType {
  isLoading: boolean;
  addRequest: (id: string) => void;
  removeRequest: (id: string) => void;
  cancelRequest: (id: string) => void;
  showLoader: () => void;
  hideLoader: () => void;
}

const LoadingContext = createContext<LoadingContextType | undefined>(undefined);

const LoadingContextProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingCount, setLoadingCount] = useState<number>(0);
  const [requestControllers, setRequestControllers] = useState<
    Map<string, AbortController>
  >(new Map());

  useEffect(() => {
    if (loadingCount > 0) {
      setIsLoading(true);
    } else {

      setIsLoading(false);

    }
  }, [loadingCount]);

  const addRequest = useCallback((id: string) => {
    const controller = new AbortController();
    setRequestControllers((prev) => new Map(prev).set(id, controller));
    setLoadingCount((prev) => prev + 1);
  }, []);

  const removeRequest = useCallback((id: string) => {
    setRequestControllers((prev) => {
      const updated = new Map(prev);
      updated.delete(id);
      return updated;
    });
    setLoadingCount((prev) => Math.max(prev - 1, 0));
  }, []);


  const cancelRequest = useCallback(
    (id: string) => {
      const controller = requestControllers.get(id);
      if (controller) {
        controller.abort();
        removeRequest(id);
      }
    },
    [requestControllers, removeRequest]
  );

  const showLoader = useCallback(() => {
    setIsLoading(true);
  }, []);

  const hideLoader = useCallback(() => {
    setIsLoading(false);
  }, []);

  useEffect(() => {
    const handleLoadingEvent = (event: Event) => {
      if (event instanceof CustomEvent) {
        switch (event.type) {
          case MANUAL_LOADING_SHOW:
            showLoader();
            break;
          case MANUAL_LOADING_HIDE:
            hideLoader();
            break;
        }
      }
    };
 
    eventBus.addEventListener(MANUAL_LOADING_SHOW, handleLoadingEvent as EventListener);
    eventBus.addEventListener(MANUAL_LOADING_HIDE, handleLoadingEvent as EventListener);
 
    return () => {
      eventBus.removeEventListener(
        MANUAL_LOADING_SHOW,
        handleLoadingEvent as EventListener
      );
      eventBus.removeEventListener(
        MANUAL_LOADING_HIDE,
        handleLoadingEvent as EventListener
      );
    };
  }, [showLoader,hideLoader]);
  return (
    <LoadingContext.Provider
      value={{
        isLoading,
        addRequest,
        removeRequest,
        cancelRequest,
        showLoader,
        hideLoader,
      }}  
    >
      {children}
    </LoadingContext.Provider>
  );
};

const useLoading = (): LoadingContextType => {
  const context = useContext(LoadingContext);
  if (!context) {
    throw new Error("useLoading must be used within a LoadingContextProvider");
  }
  return context;
};

export { LoadingContextProvider, useLoading };
