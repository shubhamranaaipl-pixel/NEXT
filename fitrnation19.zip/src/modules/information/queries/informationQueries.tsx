import gql from "graphql-tag";

export const adminGetInformation = gql`
  query adminGetInformationPage($get_information_page_input: AdminGetInformationPageInput!) {
    adminGetInformationPage(get_information_page_input: $get_information_page_input) {
      id
      title
      description
      slug
      status {
        id
        name
      }
      sort_order
    }
  }
`;
