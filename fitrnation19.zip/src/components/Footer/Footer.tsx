import React from "react";
const Footer: React.FC = () => {
  return (
    <footer className="text-gray-600 body-font">
      Footer Component
    </footer>
  );
};
export default Footer;
