import { ROUTES } from "@/constants/routes.constants";
import { home, inbox,user } from "@/assets/icons";
import { TRANSLATIONS } from "@/constants/translationConstants";

interface SubMenuItem {
  title: string;
  url: string;
}

interface MenuItem {
  title: string;
  url?: string;
  icon?: string;
  badge?: number;
  items: SubMenuItem[];
}

interface MenuSection {
  label: string;
  items: MenuItem[];
}

export const NAV_DATA: MenuSection[] = [
  {
    label: TRANSLATIONS.MAINMENU,
    items: [
      {
        title: TRANSLATIONS.DASHBOARDTITLE,
        url: ROUTES.DASHBOARD,
        icon: home,
        items: [],
      },
      {
        title:TRANSLATIONS.USERSTITLE,
        url:ROUTES.USER,
        icon:user,
        items:[]
      } 
    ],
  },
  {
    label: TRANSLATIONS.SUPPORT,
    items: [
      {
        title: TRANSLATIONS.TERM,
        url: ROUTES.TERMS,
        icon: inbox,
        items: [],
      },
      {
        title: TRANSLATIONS.PRIVACY,
        url: ROUTES.PRIVACY,
        icon: inbox,
        items: [],
      },
    ],
  },
];
