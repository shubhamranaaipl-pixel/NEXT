import logo from "@/assets/logos/logo.png";
import Image from "next/image";

export function Logo() {
  return (
    <div className="relative w-full mx-auto h-auto flex justify-center items-center">
      <Image
        src={logo}
        alt="NextAdmin logo"
        role="presentation"
        quality={100}
        priority
      />
    </div>
  );
}
