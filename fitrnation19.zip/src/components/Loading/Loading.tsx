"use client";
import { useLoading } from "@/context/LoadingContext"; // Import custom hook for loading state
import { useState, useEffect } from "react";
import "./Loading.css";
import { useAuthContext } from "@/context/AuthContext";

const Loading: React.FC = () => {
  // Use the custom hook to get the loading state
  const { isLoading } = useLoading();
  const { isAuthenticated } = useAuthContext();
  const [isVisible, setIsVisible] = useState(isLoading); // State to control visibility
  useEffect(() => {
    if (isLoading) {
      setIsVisible(true); // Show loader immediately when loading starts
    } else {
      const timeoutId = setTimeout(() => {
        setIsVisible(false); // Hide loader after the fade-out transition
      }, 100); // Match the duration of the CSS transition

      return () => clearTimeout(timeoutId); // Cleanup timeout if component unmounts
    }
  }, [isLoading]);

  

  return (
    isVisible && (
      <div className={`loader-wrapper ${isAuthenticated ? "loading" : ""}`}>
        <div className="loader"></div>
      </div>
    )
  );
}

export default Loading;
