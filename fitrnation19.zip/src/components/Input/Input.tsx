import { TRANSLATIONS } from "@/constants/translationConstants";
import { ImageModel } from "@/modules/common/models/commonModels";
import { ImageApiProvider, VideoApiProvider } from "@/modules/common/providers/ImageApiProvider";
import { cn } from "@/utils/class-utils";
import { showErrorToast, showSuccessToast } from "@/utils/toastUtils";
import { useTranslations } from "next-intl";
import Link from "next/link";
import { type HTMLInputTypeAttribute, useId } from "react";

interface UploadImageResponse {
  id: number,
  success: boolean,
  message: string,
  url: string
}

export enum FileAcceptType {
  IMAGE = "image/*",
  VIDEO = "video/*",
  IMAGE_AND_VIDEO = "image/*,video/*",
  CSV = ".xlsx, .csv, text/csv"
}

type InputGroupProps = {
  id?: string | number;
  className?: string;
  label: string;
  placeholder: string;
  type: HTMLInputTypeAttribute;
  fileStyleVariant?: "style1" | "style2";
  required?: boolean;
  disabled?: boolean;
  active?: boolean;
  handleChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
  value?: string | number;
  name?: string;
  icon?: React.ReactNode;
  error?: string;
  onUploadSuccess?: (file: ImageModel) => void;
  onUploadError?: (error: unknown, file: File) => void;
  accept?: FileAcceptType;
  mediaValue?: ImageModel;
};

const Input: React.FC<InputGroupProps> = ({
  // id,
  className,
  label,
  type,
  placeholder,
  required,
  disabled,
  active,
  handleChange,
  icon,
  error,
  onBlur,
  onUploadSuccess,
  accept,
  ...props
}) => {
  const id = useId();

  const errorTranslation = useTranslations(TRANSLATIONS.ERRORSMESSAGE);
  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (type === "file" && e.target.files?.[0]) {
      const file = e.target.files?.[0];

      if (file) {
        switch (accept) {
          case FileAcceptType.IMAGE:
            const image: UploadImageResponse = await ImageApiProvider(file);
            if (image?.success) {
              const obj = {
                id: image?.id,
                url: image?.url,
                name: "",
              }
              showSuccessToast(image?.message ?? '')
              onUploadSuccess?.(obj);
            } else {
              showErrorToast(image?.message ?? '')
            }
            break;
          case FileAcceptType.VIDEO:
            const video: UploadImageResponse = await VideoApiProvider(file);
            if (video?.success) {
              const obj = {
                id: video?.id,
                url: video?.url,
                name: "",
              }
              showSuccessToast(video?.message ?? '')
              onUploadSuccess?.(obj);
            } else {
              showErrorToast(video?.message ?? '')
            }
            break;
        }
      }
    }

    handleChange?.(e);
  };

  return (
    <div className={className}>
      <label
        htmlFor={id}
        className="text-body-sm font-medium text-dark dark:text-white"
      >
        {label}
        {required && <span className="ml-1 select-none text-red">*</span>}
      </label>

      <div
        className={cn(
          "relative mt-3 [&_svg]:absolute [&_svg]:right-4.5 [&_svg]:top-1/2 [&_svg]:-translate-y-1/2",
          {
            "flex gap-2": icon,
          }
        )}
      >
        <input
          // autoComplete="off"
          id={id}
          type={type}
          name={props.name}
          placeholder={placeholder}
          onChange={handleInputChange}
          onBlur={onBlur}
          value={type !== "file" ? props.value ?? "" : undefined}
          accept={type === "file" ? accept : undefined}
          className={
            "w-full rounded-lg border-[1.5px] border-stroke bg-transparent outline-none transition focus:border-primary disabled:cursor-default disabled:bg-gray-2 data-[active=true]:border-primary dark:border-dark-3 dark:bg-dark-2 dark:focus:border-primary dark:disabled:bg-dark dark:data-[active=true]:border-primary" +
            (type === "file"
              ? ` ${getFileStyles(props.fileStyleVariant || "style1")}`
              : " px-5.5 py-3 text-dark placeholder:text-dark-6 dark:text-white")
          }
          required={props.mediaValue ? false : required}
          disabled={disabled}
          data-active={active}
        />

        {icon}
      </div>
      {type === "file" && props.mediaValue && props.mediaValue?.url && (
        <div className="mt-2 text-body-xs text-dark-5 dark:text-white">
          Selected file: <Link className="text-primary" href={props.mediaValue.url} target="_blank" rel="noopener noreferrer">{props.mediaValue.name || 'View'}</Link>
        </div>
      )}
      {error && <span className="mt-2 text-sm text-red">{errorTranslation(error)}</span>}
    </div>
  );
};

export default Input;

function getFileStyles(variant: "style1" | "style2") {
  switch (variant) {
    case "style1":
      return `file:mr-5 file:border-collapse file:cursor-pointer file:border-0 file:border-r file:border-solid file:border-stroke file:bg-[#E2E8F0] file:px-6.5 file:py-[13px] file:text-body-sm file:font-medium file:text-dark-5 file:hover:bg-primary file:hover:bg-opacity-10 dark:file:border-dark-3 dark:file:bg-white/30 dark:file:text-white`;
    default:
      return `file:mr-4 file:rounded file:border-[0.5px] file:border-stroke file:bg-stroke file:px-2.5 file:py-1 file:text-body-xs file:font-medium file:text-dark-5 file:focus:border-primary dark:file:border-dark-3 dark:file:bg-white/30 dark:file:text-white px-3 py-[9px]`;
  }
}
