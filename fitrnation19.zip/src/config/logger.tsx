import log from 'loglevel';

const isProduction = process.env.NODE_ENV === 'production';

if (isProduction) {
  log.setLevel('silent'); // Disable logging in production
} else {
  log.setLevel('debug'); // Set log level for development
}

export default log;