"use client";

import MovieCards from "../Cards/page";
import { useTrending } from "./useTrending";
import style from "@/component/Trending/trending.module.scss"
export default function TrendingMovies() {
  const { trendingMovies } = useTrending();
  return (
    <div className={style.trending_container}>
      <h1  
       className={style.trending_container_heading}
      >Trending Movies</h1>
     
      <div         className={style.trending_container_movies}>
      <MovieCards 

      movieData={trendingMovies} />
      </div>
    </div>
  );
}
