"use client ";
import { useState, useEffect } from "react";
import { UrlEndPoints } from "@/constant/apiEndPointConstant";
import { config } from "@/config/config";
import { ApiKey } from "@/constant/apiKeyConstant";

import { IMovie } from "@/modules/movies/models/IMovie";

export const useTrending = () => {
  const [trendingMovies, setTrendingMovie] = useState<IMovie[]>([]);

  useEffect(() => {
    const fetchTrendingMovie = async () => {
      const response = await fetch(
        `${config.movie_url}${UrlEndPoints.TREANDING_MOVIE}${ApiKey.API_KEY}`
      );
      const movieData = await response.json();
      setTrendingMovie(movieData.results);
    };
    fetchTrendingMovie();
  }, []);
  return {
    trendingMovies,
    setTrendingMovie
  };
};
