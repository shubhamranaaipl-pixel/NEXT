"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
export const useCard=()=>{
  const [isFav,setIsFav]=useState(false);
    const router=useRouter();
  

    const addFavorate=(id:number)=>{
        console.log("The id is",id);
       setIsFav(true);
    }

    
    const handleDetail=(id:number)=>{
      router.push(`/detailPage/${id}`)
    }
    return{
       handleDetail,
       addFavorate,
       isFav
    }
}