"use client";
import Image from "next/image";
import { config } from "@/config/config";
import style from "@/component/Cards/card.module.scss";
import { useCard } from "./useCard";
import { AiFillHeart, AiOutlineHeart } from "react-icons/ai";

export default function MovieCards(props) {
  const { handleDetail, isFav, addFavorate } = useCard();
  return (
    <>
      {props.movieData?.map((movieItem) => (
        <div className={style.card_container} key={movieItem.id}>
          <div onClick={() => handleDetail(movieItem.id)}>
            <Image
              src={`${config.image_url}${movieItem?.poster_path}`}
              alt="Movie Image"
              width={150}
              height={150}
            />
          </div>
          <button
            onClick={()=>addFavorate(movieItem.id)}
            className={style.card_container_fav_button}
          >
            {isFav ? (
              <AiFillHeart size={22} color="red" />
            ) : (
              <AiOutlineHeart size={22} />
            )}
          </button>

          <h2 className={style.card_container_title}>{movieItem.title}</h2>
        </div>
      ))}
    </>
  );
}
