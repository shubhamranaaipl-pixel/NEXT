"use client";

import { config } from "@/config/config";
import { UrlEndPoints } from "@/constant/apiEndPointConstant";
import { ApiKey } from "@/constant/apiKeyConstant";
import { useEffect, useState } from "react";
import { IMovie } from "@/modules/movies/models/IMovie";
export const useUpComing = () => {
  const [upComingMovies, setUpComingMovies] = useState<IMovie[]>([]);

  useEffect(() => {
    const fetchUpComingMovies = async () => {
      const response = await fetch(
        `${config.movie_url}${UrlEndPoints.UPCOMING_MOVIE}${ApiKey.API_KEY}`
      );
      const movieData = await response.json();
      setUpComingMovies(movieData.results);
    };
    fetchUpComingMovies();
  }, []);
  return {
    upComingMovies,
  };
};
