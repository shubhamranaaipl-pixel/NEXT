"use client";

import MovieCards from "../Cards/page";
import { useUpComing } from "./useUpComing";
import style from "@/component/UpComing/upcoming.module.scss";

export default function UpComingMovie() {
  const { upComingMovies } = useUpComing();
  return (
    <div className={style.upcoming_container}>
      <h1
      className={style.upcoming_container_heading}
      >UpComing Movies</h1>
      <div className={style.upcoming_container_movies}>
      <MovieCards movieData={upComingMovies} />
      </div>
    </div>
  );
}
