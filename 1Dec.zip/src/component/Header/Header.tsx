"use client";
import { imageConstant } from "@/constant/imageConstant";
import Image from "next/image";
import style from "@/component/Header/header.module.scss";
import { useHeader } from "./useHeader";

export default function Header() {
const {searchData,handleInput,handleSearch}=useHeader();
 
  return (
    <header className={style.header_container}>
      <Image
        className={style.header_container_image}
        src={imageConstant.mainlogo}
        alt="Logo Image Not Found"
        width={60}
        height={60}
      />
      <ul className={style.header_container_navlists}>
        <li>Movies</li>
        <li>Tv Shows</li>
        <li>More</li>
      </ul>
       <div className={style.header_container_searchbar}><input
      className={style.header_container_searchbar_inputfield}
        type="text"
        placeholder="Search"
        value={searchData}
        onChange={handleInput}
       
      />
       <button
       onClick={handleSearch} 
       className={style.header_container_searchbar_button}>Search</button></div>
      
    </header>
  );
}
