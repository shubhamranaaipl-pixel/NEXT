"use client ";
 
import { useState } from "react";
import { useRouter } from "next/navigation";

export const useHeader = () => {
  const [searchData, setSearchData] = useState<string>("");

  const router=useRouter();

  const handleInput = (e) => {
    setSearchData(e.target.value);
  };

  const handleSearch = async () => {
   router.push(`/searchPage/${searchData}`)


  };

  return {
    searchData,
    setSearchData,
    handleInput,
    handleSearch,
  };
};
