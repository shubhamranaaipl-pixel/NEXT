"use client";

import { useEffect, useState } from "react";
import { config } from "@/config/config";
import { ApiKey } from "@/constant/apiKeyConstant";
import { UrlEndPoints } from "@/constant/apiEndPointConstant";
import { IMovie } from "@/modules/movies/models/IMovie";
export const useTopRated = () => {
  const [topRatedMovie, setTopRatedMovie] = useState<IMovie[]>();

  useEffect(() => {
    const fetchTopRatedMovie = async () => {
      const response = await fetch(
        `${config.movie_url}${UrlEndPoints.TOPRATED_MOVIE}${ApiKey.API_KEY}`
      );
      const movieData = await response.json();
      setTopRatedMovie(movieData.results);
    };
    fetchTopRatedMovie();
  }, []);

  return {
    topRatedMovie,
  };
};
