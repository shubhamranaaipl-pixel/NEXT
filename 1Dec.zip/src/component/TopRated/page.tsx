"use client";
import { useTopRated } from "./useTopRated";
import MovieCards from "../Cards/page";
import style from "@/component/TopRated/toprated.module.scss";

export default function TopRated() {
  const { topRatedMovie } = useTopRated();

  return (
    <div className={style.toprated_container}>
      <h1 className={style.toprated_container_heading}>Top Rated</h1>
      <div className={style.toprated_container_movies}>
        <MovieCards movieData={topRatedMovie} />
      </div>
    </div>
  );
}
