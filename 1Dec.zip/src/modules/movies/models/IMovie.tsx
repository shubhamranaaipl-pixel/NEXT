
export interface IMovie {
  id: number;
  title: string;
  poster_path: string;
  release_date: string;
  original_language: string;
  media_type?: string;
  overview?:string;
  isFav?:boolean;
}