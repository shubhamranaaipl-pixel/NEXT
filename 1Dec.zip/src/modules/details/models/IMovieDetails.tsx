export interface IMovieDetails{
    backdrop_path:string;
    overview:string;
    original_title:string;
}