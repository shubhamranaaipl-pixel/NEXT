
import TopRated from "@/component/TopRated/page";
import TrendingMovies from "@/component/Trending/page";
import UpComingMovie from "@/component/UpComing/page";

export default function Home() {
  return (
     <>
    
     <TrendingMovies/>
     <TopRated/>
     <UpComingMovie/>
     </>
  );
}
