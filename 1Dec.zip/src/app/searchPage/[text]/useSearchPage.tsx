"use client";

import { useEffect, useState } from "react";
import { IMovie } from "@/modules/movies/models/IMovie";
import { config } from "@/config/config";
import { ApiEndPoints, UrlEndPoints } from "@/constant/apiEndPointConstant";
import { ApiKey } from "@/constant/apiKeyConstant";
import { useParams } from "next/navigation";


export const useSearchPage=()=>{

    const [searchData,setSearchData]=useState<IMovie[]>([])
    const {text}=useParams();
    useEffect(()=>{
    const  fetchSearchMovie=async()=>{
        const response =await fetch(`${config.movie_url}${UrlEndPoints.SEARCH_MOVIE}${ApiKey.API_KEY}${ApiEndPoints.SEARCH_DATA}${text}`);
        const movieData=await response.json();
        setSearchData(movieData.results);
    }
    fetchSearchMovie();
    },[text])
    return{
      searchData
    }
}