"use client";
import { useSearchPage } from "./useSearchPage";
import Image from "next/image";
import { config } from "@/config/config";
import style from "@/app/searchPage/[text]/searchPage.module.scss";



export default function SearchPage(){
    const {searchData}=useSearchPage();
    
    return (
        <div className={style.searchPage_container}>
            {searchData.map((movieItem)=>
             <div key={movieItem.id}
              className={style.searchPage_container_movie_container}
             >

                <Image
                src={`${config.image_url}${movieItem.poster_path}`}
                alt="Movie Image is not found"
                width={150}
                height={150}
                />
                <div  className={style.searchPage_container_movie_container_content}>
                    <h2 className={style.searchPage_container_movie_container_content_title}>{movieItem.title}</h2>
                     <p  className={style.searchPage_container_movie_container_content_realse_date}>{movieItem.release_date}</p>
                     <p className={style.searchPage_container_movie_container_content_overview}>{movieItem.overview}</p>
                </div>

             </div>
            )}
        
        </div>
    )
}