"use client";
import { useDetail } from "./useDetail";
import Image from "next/image";
import { config } from "@/config/config";
import style from "@/app/detailPage/[id]/detail.module.scss"

export default function DetailPage(){
    const {movieDetails}=useDetail();

    return(
        <div className={style.detail_container}>
         <Image 
          src={`${config.image_url}${movieDetails?.backdrop_path}`}
          alt="Movie Image are not Found"
           width={500}
           height={500}
         />
         <div className={style.detail_container_content}>
         <h2 className={style.detail_container_content_title}>{movieDetails?.original_title}</h2>
         <h3 className={style.detail_container_content_overview_heading}>Overview</h3>
         <p className={style.detail_container_content_overview_paragraph}>{movieDetails?.overview}</p>
        <button className={style.detail_container_content_button}> What is Your Vibe?</button>
        </div>
      
        </div> 
    )
}