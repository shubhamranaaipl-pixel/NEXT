"use client ";
import { config } from "@/config/config";
import { DetailEndPoints } from "@/constant/apiEndPointConstant";
import { ApiKey } from "@/constant/apiKeyConstant";
import { useParams } from "next/navigation";
import { IMovieDetails } from "@/modules/details/models/IMovieDetails";
import { useEffect, useState } from "react";
export const useDetail=()=>{
const {id}=useParams();
const [movieDetails,setMovieDetails]=useState<IMovieDetails>();

 useEffect(()=>{
    const getDetails=async()=>{
        const response =await fetch(`${config.movie_url}${DetailEndPoints.MOVIES}${id}${DetailEndPoints.API_KEY}${ApiKey.API_KEY}`);
        const movieDetails=await response.json();
        setMovieDetails(movieDetails);
    }
    getDetails();
 },[id])
    return {
     movieDetails
    }
}