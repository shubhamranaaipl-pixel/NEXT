export const ApiEndPoints={
    SEARCH_DATA:"&query=",  
}

export const UrlEndPoints={
    TREANDING_MOVIE:"trending/movie/week?api_key=",
    TOPRATED_MOVIE:"movie/top_rated?api_key=",
    UPCOMING_MOVIE:"movie/upcoming?api_key=",
    SEARCH_MOVIE:"search/movie?api_key="
}

export const DetailEndPoints={
    MOVIES:"movie/",
    API_KEY:"?api_key=",

}