export const imageConstant={
    mainlogo:"/images/logo.jpg",
    movie_image:"/images/movie_image.webp"
}