module.exports = [
"[project]/.next-internal/server/app/searchPage/[text]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_searchPage_%5Btext%5D_page_actions_95a7fc5e.js.map