(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_71e330a9._.js",
  "static/chunks/src_febb22e7._.js",
  "static/chunks/src_component_Cards_card_module_scss_module_933a3329.css"
],
    source: "dynamic"
});
