(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_ai_index_mjs_9504e8ee._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/src_9c57d63f._.js",
  "static/chunks/src_component_aa8af189._.css"
],
    source: "dynamic"
});
