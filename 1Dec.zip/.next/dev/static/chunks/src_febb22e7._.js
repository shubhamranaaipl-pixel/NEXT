(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/config/config.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const config = {
    movie_url: ("TURBOPACK compile-time value", "https://api.themoviedb.org/3/") || "",
    image_url: ("TURBOPACK compile-time value", "https://media.themoviedb.org/t/p/w220_and_h330_face/") || ""
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/component/Cards/card.module.scss [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "card_container": "card-module-scss-module__dtUhNW__card_container",
  "card_container_title": "card-module-scss-module__dtUhNW__card_container_title",
});
}),
"[project]/src/component/Cards/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MovieCards
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/config.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Cards$2f$card$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/component/Cards/card.module.scss [app-client] (css module)");
(()=>{
    const e = new Error("Cannot find module './useCard'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function MovieCards(props) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "7bfe6eaecd1ced04d5d39a749643f27aed53b91de8dd9541ca97fb3f06e68848") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7bfe6eaecd1ced04d5d39a749643f27aed53b91de8dd9541ca97fb3f06e68848";
    }
    const { hanleDetails } = useCard();
    let t0;
    if ($[1] !== hanleDetails || $[2] !== props.movieData) {
        t0 = props.movieData?.map({
            "MovieCards[(anonymous)()]": (movieItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    onClick: {
                        "MovieCards[(anonymous)() > <div>.onClick]": ()=>hanleDetails(movieItem.id)
                    }["MovieCards[(anonymous)() > <div>.onClick]"],
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Cards$2f$card$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card_container,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"].image_url}${movieItem?.poster_path}`,
                            alt: "Movie Image",
                            width: 150,
                            height: 150
                        }, void 0, false, {
                            fileName: "[project]/src/component/Cards/page.tsx",
                            lineNumber: 24,
                            columnNumber: 107
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$component$2f$Cards$2f$card$2e$module$2e$scss__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card_container_title,
                            children: movieItem.title
                        }, void 0, false, {
                            fileName: "[project]/src/component/Cards/page.tsx",
                            lineNumber: 24,
                            columnNumber: 212
                        }, this)
                    ]
                }, movieItem.id, true, {
                    fileName: "[project]/src/component/Cards/page.tsx",
                    lineNumber: 22,
                    columnNumber: 49
                }, this)
        }["MovieCards[(anonymous)()]"]);
        $[1] = hanleDetails;
        $[2] = props.movieData;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    let t1;
    if ($[4] !== t0) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: t0
        }, void 0, false);
        $[4] = t0;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    return t1;
}
_s(MovieCards, "kyuctUevPoddGpbvXJ/ssKFL1XU=", false, function() {
    return [
        useCard
    ];
});
_c = MovieCards;
var _c;
__turbopack_context__.k.register(_c, "MovieCards");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_febb22e7._.js.map