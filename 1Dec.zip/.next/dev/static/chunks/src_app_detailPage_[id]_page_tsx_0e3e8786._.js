(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_fb531209._.js",
  "static/chunks/src_app_detailPage_[id]_detail_module_scss_module_735869b1.css"
],
    source: "dynamic"
});
