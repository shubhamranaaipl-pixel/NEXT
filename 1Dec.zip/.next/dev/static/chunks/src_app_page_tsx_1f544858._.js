(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_3b12edef._.js",
  "static/chunks/src_component_aa8af189._.css"
],
    source: "dynamic"
});
