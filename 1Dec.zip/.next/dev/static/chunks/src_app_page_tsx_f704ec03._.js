(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_8fb2b249._.js",
  "static/chunks/src_9c57d63f._.js",
  "static/chunks/src_component_aa8af189._.css"
],
    source: "dynamic"
});
