(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_c1d7935c._.js",
  "static/chunks/src_2a2c5005._.js",
  "static/chunks/src_fe8dd3e5._.css"
],
    source: "dynamic"
});
