export interface IConfig{
    movie_url:string;
    image_url:string;
}


export const config:IConfig={
    movie_url:process.env.NEXT_PUBLIC_MOVIE_API||"",
    image_url:process.env.NEXT_PUBLIC_IMAGE_API||"",
}