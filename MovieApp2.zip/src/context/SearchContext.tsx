"use client";

import {
  createContext,
  ReactNode,
  useState,
  useContext,
  useEffect,
} from "react";
import { useRouter } from "next/navigation";
import useDebounce from "@/hooks/useDebounce";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { ApiEndPoints } from "@/constants/apiendpoint";
import { UrlEndPoints } from "@/constants/apiendpoint";

export const SearchContext = createContext<undefined>(undefined);

const SearchContextProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const router = useRouter();
  const [inputData, setInputData] = useState<string>("");
  const debounceSearch = useDebounce(inputData, 1000);

  const handleData = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputData(e.target.value);
  };

  useEffect(() => {
    const fetchSearchData = async () => {
      const response = await fetch(
        `${config.movie_url}${UrlEndPoints.SEARCH_MOVIE}${ApiKey.API_KEY}${ApiEndPoints.SEARCH_DATA}${debounceSearch}`
      );
      const serachOutput = await response.json();
      localStorage.setItem("searchData", JSON.stringify(serachOutput.results));
    };
    fetchSearchData();
  }, [debounceSearch]);

  const searchData = () => {
    router.push("/searchPage");
  };

  return (
    <SearchContext.Provider value={{ inputData, handleData, searchData }}>
      {children}
    </SearchContext.Provider>
  );
};
const useSearch = () => {
  const context = useContext(SearchContext);
  if (!context) {
    throw new Error("Context Not Found");
  }
  return context;
};

export { useSearch, SearchContextProvider };
