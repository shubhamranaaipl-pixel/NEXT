"use client";

import { config } from "@/config/config";
import { DetailEndPoints } from "@/constants/apiendpoint";
import { ApiKey } from "@/constants/apikeyconstant";
import {createContext,ReactNode, useContext} from "react";


export const DetailContext=createContext<undefined>(undefined);

const DetailContextProvider:React.FC<{ children: ReactNode }>=({
    children,
    
})=>{
  
    const handleDetailPage=async(id:number)=>{
        const response=await fetch(`${config.movie_url}${DetailEndPoints.MOVIES}${id}${DetailEndPoints.API_KEY}${ApiKey.API_KEY}`);
        const movieDetail=await response.json();
        localStorage.setItem("movieDetails",JSON.stringify(movieDetail));
  
    }
    return(

        <DetailContext.Provider value={{handleDetailPage}}>
         {children}
        </DetailContext.Provider>
    )

    
}
const useDetailMovie=()=>{
    const context=useContext(DetailContext);
    if(!context){
        throw new Error("The Data is not found");
    }
    return context;
}
export {DetailContextProvider,useDetailMovie};
