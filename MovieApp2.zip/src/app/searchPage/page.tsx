"use client";
import { config } from "@/config/config";
import { useSearchPage } from "./useSearchPage";
import Image from "next/image";

export default function SearchPage(){
   const {searchOutput}=useSearchPage();
   
  return (
   <>
    <h1>Search Page</h1>
    {searchOutput.map((searchData)=>
      <div key={searchData.id} >
        <Image 
         src={`${config.image_url}${searchData.poster_path}`}
         alt="Movie Image is not Find"
         width={150}
         height={150}
        />
       <p>{searchData.title}</p>
       <p>{searchData.original_language}</p>

      </div>
    )}
   </>
    
  )
}