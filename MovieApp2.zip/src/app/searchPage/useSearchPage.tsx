"use client";
import { IMovie } from "@/modules/movies/models/IMovie";
import { useState, useEffect } from "react";
export const useSearchPage = () => {
  const [searchOutput, setSearchOutputData] = useState<IMovie[]>([]);

  const searchDataFind = () => {
    const movieData = localStorage.getItem("searchData");
    const searchData = movieData ? JSON.parse(movieData) : [];
    setSearchOutputData(searchData);
  };

  useEffect(() => {
    const callFunction = () => {
      searchDataFind();
    };

    callFunction();
  }, []);

  return {
    searchOutput,
  };
};
