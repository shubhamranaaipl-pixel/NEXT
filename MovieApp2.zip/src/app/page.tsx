"use client"
import TreandingMovie from "@/component/Trending/Trending";
import TopRatedMovie from "@/component/TopRated/TopRated";
import UpComing from "@/component/UpComing/UpComing";
import Header from "@/component/Header/Header";

export default function Home() {
  return (
    <>
    <Header/>
    <TreandingMovie/>
    <TopRatedMovie/>
    <UpComing/>
    </>
  );
}
