"use client";

export default function DetailPage(){
    return(
        <>
        <h1>Hello From the Detail Page</h1>
        </>
    )
}   