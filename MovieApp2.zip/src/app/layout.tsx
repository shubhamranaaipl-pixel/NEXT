"use client";
import { DetailContextProvider } from "@/context/DetailContext";
import { SearchContextProvider } from "@/context/SearchContext";
import "@/style/global.scss";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>    
        <DetailContextProvider>
      <SearchContextProvider>
         {children}
      </SearchContextProvider>  
      </DetailContextProvider>   
      </body>
    </html>
  );
}
