"use client";
import { useState } from "react";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { ApiEndPoints } from "@/constants/apiendpoint";
import { UrlEndPoints } from "@/constants/apiendpoint";


export const useHeader = () => {
  const [inputData, setInputData] = useState<string>("");


  const handleData = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputData(e.target.value);
  };
 
  const searchData=async()=>{
   const response=await fetch(`${config.movie_url}${UrlEndPoints.SEARCH_MOVIE}${ApiKey.API_KEY}${ApiEndPoints.SEARCH_DATA}${inputData}`);
   const serachOutput=await response.json();
   console.log("The OutPut Daata is ",serachOutput.results);
 
  }

  return {
    handleData,
    inputData,
    searchData
  };
};
