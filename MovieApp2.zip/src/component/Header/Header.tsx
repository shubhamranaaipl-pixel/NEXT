"use client";
import { imageConstant } from "@/constants/imageconstant";
import { useSearch } from "@/context/SearchContext";
import Image from "next/image";
import style from "@/component/Header/header.module.scss";

export default function Header() {
  const {handleData,inputData,searchData}=useSearch();
 
  return (
    <header className={style.header_container}>
      <Image
        className={style.header_container_image}
        src={imageConstant.mainlogo}
        alt="Logo Image Not Found"
        width={60}
        height={60}
      />
      <ul className={style.header_container_navlists}>
        <li>Movies</li>
        <li>Tv Shows</li>
        <li>More</li>
      </ul>
       <div className={style.header_container_searchbar}><input
      className={style.header_container_searchbar_inputfield}
        type="text"
        placeholder="Search"
        value={inputData}
        onChange={handleData}
      />
       <button onClick={searchData} className={style.header_container_searchbar_button}>Search</button></div>
      
    </header>
  );
}
