"use client";
import { useUpComing } from "./useUpComing";
import Image from "next/image";
import { config } from "@/config/config";
import style from "@/component/UpComing/upcoming.module.scss"
export default function UpComing() {
  const { upComingMovie } = useUpComing();
  return (
    <>
      <h1 className={style.heading}>UpComing Movie</h1>
      <main className={style.upcoming_container}>
      {upComingMovie.map((movieItem) => (
        <div className={style.upcoming_container_movie_container}
         key={movieItem.id}>
          <Image
            src={`${config.image_url}${movieItem.poster_path}`}
            alt="Movie Image is Not Find"
            width={150}
            height={150}
          />
          <div  className={style.upcoming_container_movie_container_content}>
          <h2 className={style.upcoming_container_movie_container_content_title}>{movieItem.title}</h2> 
          </div>
        </div>
      ))}
      </main>
    </>
  );
}
