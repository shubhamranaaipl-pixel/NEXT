"use client";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { useState, useEffect } from "react";
import { IMovie } from "@/modules/movies/models/IMovie";
import { UrlEndPoints } from "@/constants/apiendpoint";

export const useUpComing = () => {
  const [upComingMovie, setUpComingMovie] = useState<IMovie[]>([]);

  const upComingMovieData = async () => {
    const response = await fetch(`${config.movie_url}${UrlEndPoints.UPCOMING_MOVIE}${ApiKey.API_KEY}`);
    const movieData = await response.json();
    setUpComingMovie(movieData.results);
  };

  useEffect(() => {
    const callFetchFunction = () => {
      upComingMovieData();
    };
    callFetchFunction();
  }, []);
  return {
    upComingMovie,
  };
};
