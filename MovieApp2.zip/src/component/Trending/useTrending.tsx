"use client";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { useState, useEffect } from "react";
import { IMovie } from "@/modules/movies/models/IMovie";
import { UrlEndPoints } from "@/constants/apiendpoint";

export const useTrending = () => {
  const [trendingMovie, setTrendingMovie] = useState<IMovie[]>([]);

  const trendingMovieData = async () => {
    const response = await fetch(`${config.movie_url}${UrlEndPoints.TREANDING_MOVIE}${ApiKey.API_KEY}`);
    const movieData = await response.json();
    setTrendingMovie(movieData.results);
  };

  useEffect(() => {
    const callFetchFunction = () => {
      trendingMovieData();
    };
    callFetchFunction();
  }, []);

  return {
    trendingMovie,
  };
};
