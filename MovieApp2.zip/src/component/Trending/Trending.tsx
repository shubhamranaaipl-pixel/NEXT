"use client";
import { useTrending } from "./useTrending";
import Image from "next/image";
import { config } from "@/config/config";
import style from "@/component/Trending/trending.module.scss";


export default function TreandingMovie() {

  const { trendingMovie } = useTrending();

  return (
    <>
     <h1 className={style.heading}>Trending</h1>
    <main className={style.trending_container}>
    
      {trendingMovie.map((movieItem) => (
        <div className={style.trending_container_movie_container}
         key={movieItem.id}>
          <Image
          className={style.trending_container_movie_container_image}
            src={`${config.image_url}${movieItem.poster_path}`}
            alt=" Movie Image  Not Found"
            width={150}
            height={150}
          />
          <div className={style.trending_container_movie_container_content}>
          <h2 className={style.trending_container_movie_container_content_title}>{movieItem.title}</h2>
          <p className={style.trending_container_movie_container_content_media_type}>Media Types:{movieItem.media_type}</p>
          </div>
        </div>
      ))}
    </main>
    </>
   
  );
}
