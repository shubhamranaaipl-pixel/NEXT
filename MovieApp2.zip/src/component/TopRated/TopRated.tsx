"use client";

import Image from "next/image";
import { config } from "@/config/config";
import style from "@/component/TopRated/topRated.module.scss";
import { useTopRated } from "./useTopRated";
import { useRouter } from "next/navigation";

export default function TopRatedMovie() {
  const router=useRouter();
  const { topRatedMovie,handleDetailPage} = useTopRated();
  
const onCardClick=async(id:number)=>{
  handleDetailPage(id);
  router.push("/searchPage");
  
}
  return (
    <>
      <h1 className={style.heading}>Top Rated Movies</h1>
      <main className={style.toprated_container}>
      {topRatedMovie.map((movieItem) => (
        <div
        onClick={()=>onCardClick(movieItem.id)}
          className={style.toprated_container_movie_container}
          key={movieItem.id}
        >
          <Image
            src={`${config.image_url}${movieItem.poster_path}`}
            alt=" Movie Image  Not Found"
            width={150}
            height={150}
          />
          <div className={style.toprated_container_movie_container_content}>
            <h2
              className={style.toprated_container_movie_container_content_title}
            >
              {movieItem.title}
            </h2>
            
          </div>
        </div>
      ))}
      </main>
    </>
  );
}
