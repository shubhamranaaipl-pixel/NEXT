"use client";
import { useState, useEffect } from "react";
import { config } from "@/config/config";
import { ApiKey } from "@/constants/apikeyconstant";
import { IMovie } from "@/modules/movies/models/IMovie";
import { UrlEndPoints } from "@/constants/apiendpoint";
import { useDetailMovie } from "@/context/DetailContext";


export const useTopRated = () => {
  const [topRatedMovie, setTopRatedMovie] = useState<IMovie[]>([]);
  const {handleDetailPage}=useDetailMovie();

  const topratedMovieData = async () => {
    const response = await fetch(`${config.movie_url}${UrlEndPoints.TOPRATED_MOVIE}${ApiKey.API_KEY}`);
    const movieData = await response.json();
    setTopRatedMovie(movieData.results);
  };

  
  
  useEffect(() => {
    const callFetchFunction = () => {
      topratedMovieData();
    };
    callFetchFunction();
  }, []);

  return {
    topRatedMovie,
    handleDetailPage
  
  };
};
