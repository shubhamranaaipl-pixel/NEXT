(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_71e330a9._.js",
  "static/chunks/src_1b1d83a1._.js",
  "static/chunks/src_component_41a06a62._.css"
],
    source: "dynamic"
});
