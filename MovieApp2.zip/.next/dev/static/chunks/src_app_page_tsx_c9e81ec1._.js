(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_71e330a9._.js",
  "static/chunks/src_f1c91b97._.js"
],
    source: "dynamic"
});
