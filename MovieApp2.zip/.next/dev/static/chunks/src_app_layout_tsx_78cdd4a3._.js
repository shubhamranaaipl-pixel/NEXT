(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2ccae6dd._.js",
  "static/chunks/src_style_global_scss_16f9244f.css"
],
    source: "dynamic"
});
