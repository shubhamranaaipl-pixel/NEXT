module.exports = [
"[project]/.next-internal/server/app/searchPage/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_searchPage_page_actions_95f7de4d.js.map